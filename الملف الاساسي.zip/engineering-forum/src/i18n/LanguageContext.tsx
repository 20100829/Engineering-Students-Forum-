import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language } from '../types';
import { translations } from './translations';

interface LanguageContextType {
  currentLang: Language;
  setLanguage: (lang: Language) => void;
  t: typeof translations.ar;
  isRTL: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentLang, setCurrentLang] = useState<Language>(() => {
    const saved = localStorage.getItem('eng_forum_lang') as Language;
    return saved === 'ar' || saved === 'en' || saved === 'fr' ? saved : 'ar';
  });

  const isRTL = currentLang === 'ar';

  useEffect(() => {
    localStorage.setItem('eng_forum_lang', currentLang);
    document.documentElement.lang = currentLang;
    document.documentElement.dir = isRTL ? 'rtl' : 'ltr';
  }, [currentLang, isRTL]);

  const setLanguage = (lang: Language) => {
    setCurrentLang(lang);
  };

  const t = translations[currentLang] || translations.ar;

  return (
    <LanguageContext.Provider value={{ currentLang, setLanguage, t, isRTL }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
