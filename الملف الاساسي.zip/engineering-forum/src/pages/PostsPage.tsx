import React, { useState } from 'react';
import { 
  PlusCircle, 
  Search, 
  Filter, 
  MessageSquare, 
  Heart, 
  Bookmark, 
  Share2, 
  FileText, 
  Sparkles,
  Layers,
  ChevronDown
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { useData } from '../context/DataContext';
import { EngineeringDiscipline, PostType, Post } from '../types';
import { ModeratorBadge } from '../components/common/ModeratorBadge';

interface PostsPageProps {
  initialDiscipline?: EngineeringDiscipline | 'all';
  onNavigate: (page: string, params?: any) => void;
  onOpenCreatePost: () => void;
  onOpenPdfViewer: (resource: any) => void;
  onOpenReport: (item: any) => void;
}

export const PostsPage: React.FC<PostsPageProps> = ({
  initialDiscipline = 'all',
  onNavigate,
  onOpenCreatePost,
  onOpenPdfViewer,
  onOpenReport
}) => {
  const { t, isRTL } = useLanguage();
  const { posts, toggleLikePost, toggleSavePost, savedPostIds } = useData();

  const [selectedDiscipline, setSelectedDiscipline] = useState<EngineeringDiscipline | 'all'>(initialDiscipline);
  const [selectedType, setSelectedType] = useState<PostType | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredPosts = posts.filter(post => {
    const matchDiscipline = selectedDiscipline === 'all' || post.discipline === selectedDiscipline;
    const matchType = selectedType === 'all' || post.type === selectedType;
    const matchQuery = !searchQuery || 
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
      post.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchDiscipline && matchType && matchQuery;
  });

  return (
    <div className="space-y-6 pb-16">
      
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
            {t.nav.posts}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            مناقشات علمية، شروحات دارات، أسئلة تقنية وتبادل للخبرات الهندسية التطبيقية.
          </p>
        </div>

        <button
          onClick={onOpenCreatePost}
          className="flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 text-white font-bold text-xs sm:text-sm shadow-lg shadow-sky-600/30 transition hover:scale-[1.02] cursor-pointer self-start sm:self-auto"
        >
          <PlusCircle className="w-4 h-4" />
          <span>{t.nav.newPost}</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        
        {/* Search */}
        <div className="relative">
          <Search className={`absolute top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 ${isRTL ? 'right-3' : 'left-3'}`} />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث في النقاشات والوسوم..."
            className={`w-full h-10 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-sky-500 ${
              isRTL ? 'pr-9 pl-3' : 'pl-9 pr-3'
            }`}
          />
        </div>

        {/* Discipline filter */}
        <div>
          <select
            value={selectedDiscipline}
            onChange={(e) => setSelectedDiscipline(e.target.value as any)}
            className="w-full h-10 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 px-3 text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:border-sky-500"
          >
            <option value="all">جميع التخصصات الهندسية (All Disciplines)</option>
            {Object.entries(t.disciplines).map(([k, name]) => (
              <option key={k} value={k}>{name}</option>
            ))}
          </select>
        </div>

        {/* Content Type filter */}
        <div>
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value as any)}
            className="w-full h-10 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 px-3 text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:border-sky-500"
          >
            <option value="all">{t.posts.allTypes}</option>
            <option value="tutorial">{t.posts.typeTutorial}</option>
            <option value="question">{t.posts.typeQuestion}</option>
            <option value="article">{t.posts.typeArticle}</option>
            <option value="schematic">{t.posts.typeSchematic}</option>
            <option value="project_showcase">{t.posts.typeProjectShowcase}</option>
          </select>
        </div>
      </div>

      {/* Posts List */}
      <div className="space-y-4">
        {filteredPosts.length === 0 ? (
          <div className="p-12 text-center rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
            <Layers className="w-10 h-10 text-slate-400 mx-auto opacity-50" />
            <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300">
              {t.home.noPosts}
            </h3>
            <p className="text-xs text-slate-400">
              جرّب تغيير معايير التصفية أو كن أول من يطرح نقاشاً في هذا التخصص.
            </p>
          </div>
        ) : (
          filteredPosts.map(post => {
            const isSaved = savedPostIds.includes(post.id);
            return (
              <div
                key={post.id}
                className="rounded-3xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 shadow-sm hover:border-sky-500/30 transition-all p-5 sm:p-6"
              >
                {/* Author row */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-600 to-indigo-600 text-white font-bold text-sm flex items-center justify-center">
                      {post.authorName.charAt(0)}
                    </div>
                    <div>
                      <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
                        <span className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">
                          {post.authorName.replace(/\s*\(مشرف.*?\)/, '')}
                        </span>
                        <ModeratorBadge 
                          authorId={post.authorId} 
                          authorName={post.authorName} 
                          isModerator={post.isModerator} 
                          moderatorTitle={post.moderatorTitle} 
                        />
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-sky-500/10 text-sky-500">
                          {t.roles[post.authorRole]}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400 font-mono">
                        {t.disciplines[post.discipline]} • {new Date(post.createdAt).toLocaleDateString('ar-EG')}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => onOpenReport({ id: post.id, type: 'post', title: post.title })}
                    className="text-slate-400 hover:text-rose-400 text-xs p-1"
                  >
                    •••
                  </button>
                </div>

                {/* Title & Preview */}
                <div 
                  onClick={() => onNavigate('post_detail', post.id)}
                  className="cursor-pointer group"
                >
                  <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white group-hover:text-sky-500 transition mb-2">
                    {post.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed line-clamp-3 mb-3">
                    {post.content}
                  </p>
                </div>

                {/* Image */}
                {post.images && post.images.length > 0 && (
                  <div 
                    onClick={() => onNavigate('post_detail', post.id)}
                    className="mb-3 rounded-2xl overflow-hidden max-h-72 border border-slate-200 dark:border-slate-800 cursor-pointer"
                  >
                    <img src={post.images[0]} alt={post.title} className="w-full h-full object-cover" />
                  </div>
                )}

                {/* PDF */}
                {post.pdfUrl && (
                  <div className="mb-3 p-3 rounded-2xl bg-sky-500/5 border border-sky-500/20 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <FileText className="w-5 h-5 text-sky-500" />
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                        {post.pdfTitle || 'مخطط هندسي مرفق.pdf'}
                      </span>
                    </div>
                    <button
                      onClick={() => onOpenPdfViewer({
                        id: post.id,
                        title: post.pdfTitle || post.title,
                        description: post.content,
                        discipline: post.discipline,
                        authorOrSource: post.authorName,
                        fileSize: '3.1 MB',
                        downloadsCount: 154
                      })}
                      className="px-3 py-1 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold"
                    >
                      معاينة PDF
                    </button>
                  </div>
                )}

                {/* Tags */}
                <div className="flex flex-wrap gap-1.5 mb-4">
                  {post.tags.map(tag => (
                    <span
                      key={tag}
                      className="px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-[10px] font-medium"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800/80 text-xs text-slate-500">
                  <div className="flex items-center gap-4">
                    <button
                      onClick={() => toggleLikePost(post.id)}
                      className="flex items-center gap-1.5 hover:text-rose-500 cursor-pointer"
                    >
                      <Heart className="w-4 h-4 text-rose-500 fill-current" />
                      <span className="font-bold">{post.likesCount}</span>
                    </button>
                    <button
                      onClick={() => onNavigate('post_detail', post.id)}
                      className="flex items-center gap-1.5 hover:text-sky-500 cursor-pointer"
                    >
                      <MessageSquare className="w-4 h-4" />
                      <span className="font-bold">{post.commentsCount}</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => toggleSavePost(post.id)}
                      className={`p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 ${isSaved ? 'text-amber-400' : ''}`}
                    >
                      <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
                    </button>
                    <button
                      onClick={() => {
                        navigator.clipboard?.writeText(window.location.origin + '/#post-' + post.id);
                        alert('تم نسخ رابط المنشور الهندسي');
                      }}
                      className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
                    >
                      <Share2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
