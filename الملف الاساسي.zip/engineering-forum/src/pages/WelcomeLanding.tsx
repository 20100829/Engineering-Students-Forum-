import React from 'react';
import { 
  Zap, 
  Cpu, 
  BookOpen, 
  GraduationCap, 
  Users, 
  ShieldCheck, 
  ArrowLeft, 
  ArrowRight, 
  CheckCircle2, 
  Sparkles,
  HelpCircle,
  Award,
  Layers,
  ChevronRight
} from 'lucide-react';
import { Logo } from '../components/common/Logo';
import { useLanguage } from '../i18n/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { EngineeringDiscipline } from '../types';

interface WelcomeLandingProps {
  onNavigate: (page: string, params?: any) => void;
}

export const WelcomeLanding: React.FC<WelcomeLandingProps> = ({ onNavigate }) => {
  const { t, currentLang, isRTL } = useLanguage();
  const { isAuthenticated } = useAuth();

  const ArrowIcon = isRTL ? ArrowLeft : ArrowRight;

  const disciplines: { key: EngineeringDiscipline; label: string; icon: string; desc: string }[] = [
    { key: 'electrical', label: t.disciplines.electrical, icon: '⚡', desc: 'الدوائر الكهربائية، محطات القدرة، المحولات والشبكات الذكية' },
    { key: 'electronics', label: t.disciplines.electronics, icon: '🔌', desc: 'تصميم الـ PCB، النظم المدمجة، المتحكمات الدقيقة والمجسات' },
    { key: 'automation', label: t.disciplines.automation, icon: '⚙️', desc: 'برمجة الـ PLC، نظم SCADA، والمشغلات الصناعية' },
    { key: 'robotics_ai', label: t.disciplines.robotics_ai, icon: '🤖', desc: 'الروبوتات المتنقلة، رؤية الحاسوب ونظام ROS2' },
    { key: 'renewable_energy', label: t.disciplines.renewable_energy, icon: '☀️', desc: 'الطاقة الشمسية الكهروضوئية، توربينات الرياح وبنوك الطاقة' },
    { key: 'mechanical', label: t.disciplines.mechanical, icon: '🔩', desc: 'النمذجة ثلاثية الأبعاد CAD وميكانيكا المواد والتصنيع' },
    { key: 'civil', label: t.disciplines.civil, icon: '🏗️', desc: 'هندسة المنشآت الخرسانية والمعدنية والتحليل الإنشائي' },
    { key: 'computer_sci', label: t.disciplines.computer_sci, icon: '💻', desc: 'البرمجيات المدمجة، الخوارزميات وتطوير النظم الهندسية' },
  ];

  const membershipTiers = [
    {
      role: 'high_school_student',
      title: 'تلميذ ثانوي',
      desc: 'بيئة آمنة لاكتشاف الشغف الهندسي ومشاريع الإلكترونيات الأولية والتحضير للجامعة.',
      badge: 'الجيل الصاعد',
      color: 'from-emerald-500/20 to-teal-500/10 border-emerald-500/30 text-emerald-400'
    },
    {
      role: 'university_student',
      title: 'طالب جامعي',
      desc: 'مذكرات التخرج، فرق عمل للمسابقات، مناقشة المسائل المعقدة، والتحضير لسوق العمل.',
      badge: 'مهندس المستقبل',
      color: 'from-sky-500/20 to-blue-500/10 border-sky-500/30 text-sky-400'
    },
    {
      role: 'teacher',
      title: 'أستاذ / معلّم',
      desc: 'نشر السلاسل والدروس، الإشراف الأكاديمي المعتمد على المشاريع، وتوجيه الطلاب.',
      badge: 'إشراف أكاديمي',
      color: 'from-purple-500/20 to-indigo-500/10 border-purple-500/30 text-purple-400'
    },
    {
      role: 'expert_engineer',
      title: 'مهندس / خبير',
      desc: 'نقل الخبرات الميدانية الصناعية، تقييم النماذج الأولية، وتقديم استشارات هندسية.',
      badge: 'خبرة صناعية',
      color: 'from-amber-500/20 to-yellow-500/10 border-amber-500/30 text-amber-400'
    }
  ];

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 bg-grid-pattern relative overflow-hidden">
      
      {/* Ambient background glows */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-sky-500/10 blur-[130px] rounded-full pointer-events-none" />
      <div className="absolute top-1/3 -right-40 w-[600px] h-[600px] bg-blue-600/10 blur-[150px] rounded-full pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-[500px] h-[500px] bg-amber-500/5 blur-[140px] rounded-full pointer-events-none" />

      {/* Hero Section */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-20">
        
        {/* Top Emblem and Badge */}
        <div className="flex flex-col items-center text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-slate-900/80 border border-sky-500/30 text-sky-400 text-xs font-semibold backdrop-blur-md shadow-lg shadow-sky-500/10 animate-in fade-in">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>{t.hero.badge}</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
          </div>

          <div className="my-2">
            <Logo size="xl" showText={false} />
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white max-w-4xl leading-tight">
            {t.app.name}
          </h1>

          <div className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-sky-400 via-blue-300 to-amber-300 bg-clip-text text-transparent">
            {t.app.motto}
          </div>

          <p className="text-slate-400 text-sm sm:text-base max-w-2xl leading-relaxed">
            {t.hero.subtitle}
          </p>

          {/* Action CTAs */}
          <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
            <button
              onClick={() => onNavigate(isAuthenticated ? 'home' : 'register')}
              className="flex items-center gap-2.5 px-7 py-3.5 rounded-2xl bg-gradient-to-r from-sky-500 via-blue-600 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-bold text-sm shadow-xl shadow-sky-600/30 hover:scale-[1.02] active:scale-95 transition-all cursor-pointer"
            >
              <span>{isAuthenticated ? 'الدخول للمنصة والمناقشات' : t.hero.joinNow}</span>
              <ArrowIcon className="w-4 h-4" />
            </button>

            <button
              onClick={() => onNavigate('projects')}
              className="flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-slate-900/80 hover:bg-slate-800 text-slate-200 border border-slate-700/80 font-semibold text-sm transition cursor-pointer backdrop-blur-md"
            >
              <Cpu className="w-4 h-4 text-sky-400" />
              <span>{t.hero.browseProjects}</span>
            </button>
          </div>

          {/* Real Community Statistics Bar */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full max-w-4xl pt-10">
            {[
              { val: '+1,500', label: t.hero.statsMembers, icon: Users, color: 'text-sky-400' },
              { val: '+240', label: t.hero.statsProjects, icon: Cpu, color: 'text-emerald-400' },
              { val: '+850', label: t.hero.statsResources, icon: BookOpen, color: 'text-purple-400' },
              { val: '+65', label: t.hero.statsQuizzes, icon: HelpCircle, color: 'text-amber-400' },
            ].map((stat, i) => {
              const Icon = stat.icon;
              return (
                <div key={i} className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 backdrop-blur-sm text-center">
                  <div className={`w-8 h-8 mx-auto mb-2 rounded-xl bg-slate-800/80 flex items-center justify-center ${stat.color}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="text-xl sm:text-2xl font-black text-white font-mono">{stat.val}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5 font-medium">{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 4 Membership Tiers Showcase */}
        <div className="mt-24">
          <div className="text-center space-y-2 mb-10">
            <h2 className="text-2xl sm:text-3xl font-black text-white">
              مجتمع متكامل يجمع جميع أطراف المنظومة الهندسية
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto">
              صلاحيات مخصصة لكل نوع عضوية لضمان سلامة المحتوى وجودة التوجيه الأكاديمي.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {membershipTiers.map((tier, idx) => (
              <div 
                key={idx}
                className={`p-5 rounded-3xl bg-gradient-to-b ${tier.color} border backdrop-blur-md flex flex-col justify-between transition hover:-translate-y-1 duration-300 shadow-lg`}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-900/80 border border-slate-700/60 font-mono">
                      {tier.badge}
                    </span>
                    <ShieldCheck className="w-4 h-4 opacity-75" />
                  </div>
                  <h3 className="text-base font-bold text-white mb-2">{tier.title}</h3>
                  <p className="text-xs text-slate-300/90 leading-relaxed">{tier.desc}</p>
                </div>
                <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs font-semibold">
                  <span>انضم بهذا الدور</span>
                  <ChevronRight className={`w-3.5 h-3.5 ${isRTL ? 'rotate-180' : ''}`} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Disciplines Grid */}
        <div className="mt-24">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
            <div>
              <span className="text-xs font-bold text-sky-400 uppercase tracking-wider">
                التخصصات العلمية والتقنية
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-white mt-1">
                تغطية شاملة لكل فروع الهندسة
              </h2>
            </div>
            <button
              onClick={() => onNavigate('explore')}
              className="text-xs text-sky-400 hover:text-sky-300 font-bold flex items-center gap-1 self-start sm:self-auto cursor-pointer"
            >
              <span>استكشاف كل المجموعات</span>
              <ArrowIcon className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {disciplines.map(d => (
              <div
                key={d.key}
                onClick={() => onNavigate('posts', { discipline: d.key })}
                className="group p-5 rounded-2xl bg-slate-900/60 hover:bg-slate-900 border border-slate-800/80 hover:border-sky-500/40 transition-all duration-300 cursor-pointer backdrop-blur-sm"
              >
                <div className="text-3xl mb-3 transform transition group-hover:scale-110">{d.icon}</div>
                <h3 className="text-sm font-bold text-white group-hover:text-sky-400 transition mb-1">
                  {d.label}
                </h3>
                <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                  {d.desc}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Features / Capabilities Grid */}
        <div className="mt-24 p-8 sm:p-12 rounded-3xl bg-gradient-to-br from-slate-900 via-[#0b1426] to-sky-950/40 border border-sky-500/20 shadow-2xl relative">
          <div className="max-w-2xl mb-8">
            <h2 className="text-2xl sm:text-3xl font-black text-white mb-2">
              أدوات متطورة مصممة للمهندس العصري
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              من توثيق النماذج والمخططات، إلى محاكي الاختبارات وبناء السيرة الذاتية المهنية.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <div className="w-10 h-10 rounded-xl bg-sky-500/10 text-sky-400 flex items-center justify-center font-bold">
                <Cpu className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white">معرض المشاريع والاختراعات</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                قوائم المكونات (BOM)، مخططات التوصيل، مراحل الإنجاز، وإمكانية دعوة مشرف أكاديمي.
              </p>
            </div>

            <div className="space-y-2">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold">
                <BookOpen className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white">مكتبة رقمية وعارض PDF مدمج</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                مراجع مفتوحة ومذكرات تخرج موثقة ومخططات ومحاضرات قابلة للمعاينة والتحميل مجاناً.
              </p>
            </div>

            <div className="space-y-2">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center font-bold">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white">حماية خصوصية صارمة للقاصرين</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                حجب أرقام الهواتف والعناوين الشخصية تلقائياً، مع نظام إشراف هجين يضمن بيئة علمية نقية.
              </p>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
