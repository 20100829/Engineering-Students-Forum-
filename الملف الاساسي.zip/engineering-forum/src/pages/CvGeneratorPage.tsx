import React, { useState } from 'react';
import { 
  Printer, 
  Download, 
  Sparkles, 
  ShieldCheck, 
  FileText, 
  Eye, 
  Check, 
  GraduationCap, 
  Cpu, 
  Award,
  ArrowLeft,
  ArrowRight
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';

export const CvGeneratorPage: React.FC = () => {
  const { t, isRTL } = useLanguage();
  const { currentUser } = useAuth();
  const { projects } = useData();

  const [template, setTemplate] = useState<'modern' | 'academic'>('modern');
  const [includePhone, setIncludePhone] = useState(false);
  const [phone, setPhone] = useState('+213 555 010 203');
  const [address, setAddress] = useState('الجزائر العاصمة');
  const [customBio, setCustomBio] = useState(currentUser?.bio || 'مهندس وباحث في الأنظمة الذكية والدوائر الإلكترونية.');
  const [includedProjects, setIncludedProjects] = useState<string[]>(projects.map(p => p.id).slice(0, 2));

  const handlePrint = () => {
    window.print();
  };

  if (!currentUser) return null;

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-20">
      
      {/* Top Banner (hidden during print) */}
      <div className="no-print p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-emerald-950 via-slate-900 to-sky-950 border border-emerald-500/20 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold">
            <FileText className="w-3.5 h-3.5" />
            <span>محرك السيرة الذاتية الهندسية</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-white">{t.cv.title}</h1>
          <p className="text-xs text-slate-300">{t.cv.subtitle}</p>
        </div>

        <button
          onClick={handlePrint}
          className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 text-white font-bold text-xs sm:text-sm shadow-xl shadow-emerald-600/30 transition hover:scale-[1.02] cursor-pointer shrink-0"
        >
          <Printer className="w-4 h-4" />
          <span>{t.cv.exportPdf}</span>
        </button>
      </div>

      {/* Configuration Controls (hidden during print) */}
      <div className="no-print grid grid-cols-1 md:grid-cols-3 gap-4 p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm text-xs">
        
        {/* Template Style */}
        <div>
          <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1.5">
            {t.cv.template}
          </label>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setTemplate('modern')}
              className={`p-2.5 rounded-xl border text-center font-bold transition ${
                template === 'modern'
                  ? 'bg-sky-500 text-white border-sky-400'
                  : 'border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              {t.cv.templateModern}
            </button>
            <button
              type="button"
              onClick={() => setTemplate('academic')}
              className={`p-2.5 rounded-xl border text-center font-bold transition ${
                template === 'academic'
                  ? 'bg-sky-500 text-white border-sky-400'
                  : 'border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              {t.cv.templateClassic}
            </button>
          </div>
        </div>

        {/* Privacy Toggles */}
        <div className="space-y-2">
          <label className="block font-bold text-slate-700 dark:text-slate-300">
            إعدادات الخصوصية وحماية البيانات
          </label>
          <label className="flex items-center gap-2 text-slate-600 dark:text-slate-400 cursor-pointer">
            <input
              type="checkbox"
              checked={includePhone}
              onChange={(e) => setIncludePhone(e.target.checked)}
              className="rounded text-sky-500"
            />
            <span>تضمين رقم الهاتف في السيرة الذاتية</span>
          </label>
          {includePhone && (
            <input
              type="text"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono text-xs"
            />
          )}
        </div>

        {/* Sensitive Data Notice */}
        <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 text-[11px] leading-relaxed flex items-start gap-2">
          <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
          <p>{t.cv.privacyNote}</p>
        </div>
      </div>

      {/* CV LIVE PREVIEW SHEET (What prints to PDF) */}
      <div className="cv-paper rounded-2xl bg-white text-slate-900 shadow-2xl p-8 sm:p-14 border border-slate-200 min-h-[900px] leading-relaxed select-text font-sans">
        
        {/* Header */}
        <div className={`pb-6 mb-6 border-b-2 ${template === 'modern' ? 'border-sky-600' : 'border-slate-900'}`}>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-black text-slate-950 tracking-tight">
                {currentUser.displayName}
              </h1>
              <p className="text-sm font-bold text-sky-700 mt-0.5">
                {t.roles[currentUser.role]} • {t.disciplines[currentUser.discipline]}
              </p>
            </div>

            <div className="text-xs text-slate-600 font-mono space-y-1 sm:text-left">
              <p>Email: {currentUser.email}</p>
              {includePhone && <p>Tel: {phone}</p>}
              <p>Forum: @{currentUser.username}</p>
            </div>
          </div>
        </div>

        {/* Bio / Summary */}
        <div className="mb-6">
          <h2 className="text-xs font-black uppercase tracking-wider text-slate-400 mb-2">
            الملخص المهني والأكاديمي (Professional Summary)
          </h2>
          <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
            {customBio}
          </p>
        </div>

        {/* Education */}
        <div className="mb-6">
          <h2 className="text-xs font-black uppercase tracking-wider text-slate-400 mb-2">
            المسار الدراسي والتكوين الهندسي (Education)
          </h2>
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold text-slate-900">{currentUser.educationLevel}</h3>
              <p className="text-[11px] text-slate-500">{currentUser.institution || 'جامعة الهندسة والتكنولوجيا'}</p>
            </div>
            <span className="text-[10px] font-mono text-slate-400">2022 - الآن</span>
          </div>
        </div>

        {/* Skills */}
        <div className="mb-6">
          <h2 className="text-xs font-black uppercase tracking-wider text-slate-400 mb-2">
            المهارات التقنية والبرمجية (Technical Skills)
          </h2>
          <div className="flex flex-wrap gap-2">
            {currentUser.skills.map((s, i) => (
              <span key={i} className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-800 text-xs font-bold font-mono border border-slate-200">
                {s}
              </span>
            ))}
          </div>
        </div>

        {/* Featured Engineering Projects */}
        <div className="mb-6">
          <h2 className="text-xs font-black uppercase tracking-wider text-slate-400 mb-2">
            المشاريع والابتكارات التطبيقية (Selected Projects)
          </h2>
          <div className="space-y-3">
            {projects.slice(0, 2).map((proj) => (
              <div key={proj.id} className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                <div className="flex items-center justify-between text-xs font-bold text-slate-900 mb-1">
                  <span>{proj.title}</span>
                  <span className="text-[10px] font-mono text-sky-700">{proj.stage.toUpperCase()}</span>
                </div>
                <p className="text-[11px] text-slate-600 mb-2">{proj.tagline}</p>
                <div className="flex flex-wrap gap-1">
                  {proj.componentsList.slice(0, 3).map((c, i) => (
                    <span key={i} className="text-[9px] px-1.5 py-0.5 rounded bg-white text-slate-600 border font-mono">
                      {c.name}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Achievements / Credentials */}
        {currentUser.achievements.length > 0 && (
          <div className="mb-6">
            <h2 className="text-xs font-black uppercase tracking-wider text-slate-400 mb-2">
              الجوائز والشهادات التقديرية (Honors & Awards)
            </h2>
            <ul className="text-xs text-slate-700 list-disc list-inside space-y-1">
              {currentUser.achievements.map((ach, i) => (
                <li key={i}>{ach}</li>
              ))}
            </ul>
          </div>
        )}

        {/* Footer */}
        <div className="mt-12 pt-4 border-t border-slate-200 text-center text-[9px] text-slate-400 flex items-center justify-between font-mono">
          <span>GENERATED VIA ENGINEERING STUDENTS FORUM</span>
          <span>VERIFIED ID: {currentUser.id.toUpperCase()}</span>
        </div>
      </div>

    </div>
  );
};
