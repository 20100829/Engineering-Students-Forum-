import React, { useState } from 'react';
import { 
  ArrowLeft, 
  ArrowRight, 
  Heart, 
  Bookmark, 
  Share2, 
  MessageSquare, 
  Send, 
  FileText, 
  ShieldAlert, 
  CornerDownLeft,
  User
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { ModeratorBadge } from '../components/common/ModeratorBadge';

interface PostDetailPageProps {
  postId: string;
  onNavigate: (page: string, params?: any) => void;
  onOpenPdfViewer: (resource: any) => void;
  onOpenReport: (item: any) => void;
}

export const PostDetailPage: React.FC<PostDetailPageProps> = ({
  postId,
  onNavigate,
  onOpenPdfViewer,
  onOpenReport
}) => {
  const { t, isRTL } = useLanguage();
  const { currentUser } = useAuth();
  const { posts, toggleLikePost, toggleSavePost, savedPostIds, addComment } = useData();

  const [commentText, setCommentText] = useState('');
  const [replyingToId, setReplyingToId] = useState<string | null>(null);

  const post = posts.find(p => p.id === postId) || posts[0];
  const ArrowIcon = isRTL ? ArrowRight : ArrowLeft;

  // Local comments state for instant simulation
  const [commentsList, setCommentsList] = useState([
    {
      id: 'c1',
      authorName: 'د. كريم بن منصور',
      authorRole: 'teacher',
      text: 'شرح هندسي دقيق وموفق. يُفضل دائماً حساب تيار القصر الأقصى (Isc) في لوحات التوزيع الرئيسية للتأكد من قدرة قواطع الدائرة (Circuit Breakers) على قطع التيار دون انفجار القوس الكهربائي.',
      time: 'منذ يوم',
      likes: 12
    },
    {
      id: 'c2',
      authorName: 'م. رشيد السليماني',
      authorRole: 'expert_engineer',
      text: 'في التطبيقات الصناعية الفعلية، نعتمد أيضاً على مرحلات الحماية الرقمية (Digital Protection Relays) مثل سلسلة SEL أو MiCOM لتوثيق سجل الأحداث بدقة أجزاء الثانية.',
      time: 'منذ 18 ساعة',
      likes: 8
    },
    {
      id: 'c3',
      authorName: 'فضيلي فاتح',
      authorRole: 'expert_engineer',
      text: 'توجيه هندسي دقيق. من منظور هندسة البرمجيات المدمجة، نوصي بربط إشارات التغذية الراجعة (Feedback Loops) بمقاطعات عتادية ذات أولوية مرتفعة لضمان إيقاف النظام في زمن قياسي عند الطوارئ.',
      time: 'منذ 5 ساعات',
      likes: 15
    }
  ]);

  if (!post) {
    return (
      <div className="p-12 text-center">
        <p className="text-slate-400">المنشور غير متوفر أو تم حذفه.</p>
        <button onClick={() => onNavigate('posts')} className="mt-4 text-sky-400 underline">
          العودة للمنشورات
        </button>
      </div>
    );
  }

  const isSaved = savedPostIds.includes(post.id);

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim() || !currentUser) return;

    const newComment = {
      id: `c_${Date.now()}`,
      authorName: currentUser.displayName,
      authorRole: currentUser.role,
      text: commentText.trim(),
      time: 'الآن',
      likes: 0
    };

    setCommentsList([...commentsList, newComment]);
    addComment(post.id, commentText.trim(), { id: currentUser.id, name: currentUser.displayName, role: currentUser.role });
    setCommentText('');
    setReplyingToId(null);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20">
      
      {/* Back button */}
      <button
        onClick={() => onNavigate('posts')}
        className="flex items-center gap-2 text-xs font-bold text-slate-500 hover:text-sky-500 transition cursor-pointer"
      >
        <ArrowIcon className="w-4 h-4" />
        <span>العودة لقائمة المنشورات الهندسية</span>
      </button>

      {/* Main Post Card */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm">
        
        {/* Author details */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-sky-600 to-indigo-600 text-white font-bold text-base flex items-center justify-center">
              {post.authorName.charAt(0)}
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-bold text-sm sm:text-base text-slate-900 dark:text-white">
                  {post.authorName.replace(/\s*\(مشرف.*?\)/, '')}
                </span>
                <ModeratorBadge 
                  authorId={post.authorId} 
                  authorName={post.authorName} 
                  isModerator={post.isModerator} 
                  moderatorTitle={post.moderatorTitle} 
                  variant="detailed"
                  size="sm"
                />
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-sky-500/10 text-sky-500 border border-sky-500/20">
                  {t.roles[post.authorRole]}
                </span>
              </div>
              <span className="text-xs text-slate-400 font-mono">
                {t.disciplines[post.discipline]} • {new Date(post.createdAt).toLocaleDateString('ar-EG')}
              </span>
            </div>
          </div>

          <button
            onClick={() => onOpenReport({ id: post.id, type: 'post', title: post.title })}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-400 hover:text-rose-500 transition text-xs"
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">إبلاغ</span>
          </button>
        </div>

        {/* Title */}
        <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mb-4 leading-tight">
          {post.title}
        </h1>

        {/* Body Text */}
        <div className="text-xs sm:text-sm text-slate-700 dark:text-slate-200 leading-relaxed space-y-4 whitespace-pre-line mb-6 font-normal">
          {post.content}
        </div>

        {/* Image Attachment */}
        {post.images && post.images.length > 0 && (
          <div className="mb-6 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800">
            <img src={post.images[0]} alt={post.title} className="w-full object-cover" />
          </div>
        )}

        {/* Attached PDF button */}
        {post.pdfUrl && (
          <div className="mb-6 p-4 rounded-2xl bg-sky-500/10 border border-sky-500/30 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <FileText className="w-6 h-6 text-sky-400" />
              <div>
                <p className="text-xs font-bold text-slate-900 dark:text-white">
                  {post.pdfTitle || 'مخطط هندسي توضيحي.pdf'}
                </p>
                <span className="text-[10px] text-slate-400">وثيقة هندسية مصادقة • 2.4 MB</span>
              </div>
            </div>
            <button
              onClick={() => onOpenPdfViewer({
                id: post.id,
                title: post.pdfTitle || post.title,
                description: post.content,
                discipline: post.discipline,
                authorOrSource: post.authorName,
                fileSize: '2.4 MB',
                downloadsCount: 120
              })}
              className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold shadow-md shadow-sky-600/30 transition cursor-pointer"
            >
              فتح وقراءة المرجع
            </button>
          </div>
        )}

        {/* Tags */}
        <div className="flex flex-wrap gap-2 mb-6">
          {post.tags.map(tag => (
            <span
              key={tag}
              className="px-3 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-medium"
            >
              #{tag}
            </span>
          ))}
        </div>

        {/* Interactions Row */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-500">
          <div className="flex items-center gap-4">
            <button
              onClick={() => toggleLikePost(post.id)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:text-rose-500 transition cursor-pointer"
            >
              <Heart className="w-4 h-4 text-rose-500 fill-current" />
              <span className="font-bold">{post.likesCount} إعجاب</span>
            </button>
            <div className="flex items-center gap-1.5">
              <MessageSquare className="w-4 h-4 text-sky-500" />
              <span className="font-bold">{commentsList.length} تعليقات</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => toggleSavePost(post.id)}
              className={`p-2 rounded-xl border border-slate-200 dark:border-slate-800 transition ${
                isSaved ? 'text-amber-400 bg-amber-400/10 border-amber-400/30' : 'hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
              title="حفظ"
            >
              <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
            </button>
            <button
              onClick={() => {
                navigator.clipboard?.writeText(window.location.href);
                alert('تم نسخ رابط المنشور بنجاح');
              }}
              className="p-2 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              title="مشاركة"
            >
              <Share2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Comments Section */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm space-y-6">
        <h3 className="text-base font-bold text-slate-900 dark:text-white">
          {t.posts.comments} ({commentsList.length})
        </h3>

        {/* Comment input form */}
        {currentUser ? (
          <form onSubmit={handleCommentSubmit} className="space-y-3">
            <textarea
              rows={3}
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder={t.posts.writeComment}
              className="w-full px-4 py-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-sky-500 resize-none"
              required
            />
            <div className="flex items-center justify-between">
              <span className="text-[11px] text-slate-400">
                حافظ على الاحترام المتبادل والملاحظات الهندسية البنّاءة.
              </span>
              <button
                type="submit"
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold shadow-md shadow-sky-600/30 transition cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{t.posts.send}</span>
              </button>
            </div>
          </form>
        ) : (
          <div className="p-4 rounded-2xl bg-slate-100 dark:bg-slate-800 text-center text-xs">
            يرجى تسجيل الدخول للمشاركة في النقاش الهندسي.
          </div>
        )}

        {/* Comments Feed */}
        <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-800">
          {commentsList.map(comment => (
            <div
              key={comment.id}
              className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60 space-y-2"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-sky-600 text-white font-bold text-xs flex items-center justify-center">
                    {comment.authorName.charAt(0)}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-slate-900 dark:text-white">
                        {comment.authorName.replace(/\s*\(مشرف.*?\)/, '')}
                      </span>
                      <ModeratorBadge 
                        authorName={comment.authorName} 
                        size="xs" 
                      />
                    </div>
                    <span className="text-[10px] text-slate-400 block font-mono">
                      {comment.time}
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => onOpenReport({ id: comment.id, type: 'comment', title: comment.text })}
                  className="text-slate-400 hover:text-rose-400 text-xs"
                >
                  إبلاغ
                </button>
              </div>

              <p className="text-xs text-slate-700 dark:text-slate-200 leading-relaxed pr-10">
                {comment.text}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
