import React, { useState } from 'react';
import { 
  Lock, 
  Mail, 
  User, 
  BookOpen, 
  GraduationCap, 
  ArrowLeft, 
  ArrowRight, 
  ShieldCheck, 
  AlertCircle,
  Building,
  CheckCircle2,
  Sparkles
} from 'lucide-react';
import { Logo } from '../components/common/Logo';
import { useLanguage } from '../i18n/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { UserRole, EngineeringDiscipline } from '../types';

interface AuthPagesProps {
  initialMode?: 'login' | 'register' | 'forgot_password';
  onNavigate: (page: string) => void;
}

export const AuthPages: React.FC<AuthPagesProps> = ({ initialMode = 'login', onNavigate }) => {
  const { t, isRTL } = useLanguage();
  const { login, register, requestPasswordReset } = useAuth();

  const [mode, setMode] = useState<'login' | 'register' | 'forgot_password'>(initialMode);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [loading, setLoading] = useState(false);

  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [role, setRole] = useState<UserRole>('university_student');
  const [discipline, setDiscipline] = useState<EngineeringDiscipline>('electrical');
  const [educationLevel, setEducationLevel] = useState('');
  const [institution, setInstitution] = useState('');

  const ArrowIcon = isRTL ? ArrowLeft : ArrowRight;

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setLoading(true);
    try {
      const res = await login(email, password);
      if (res.success) {
        onNavigate('home');
      } else {
        setErrorMsg(res.error || 'بيانات الدخول غير صحيحة');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (password !== confirmPassword) {
      setErrorMsg('كلمتا المرور غير متطابقتين');
      return;
    }

    if (!displayName || !username || !email) {
      setErrorMsg('يرجى ملء كافة الحقول الإلزامية');
      return;
    }

    setLoading(true);
    try {
      const res = await register({
        username: username.toLowerCase().trim(),
        displayName: displayName.trim(),
        email: email.trim(),
        password,
        role,
        discipline,
        educationLevel: educationLevel.trim() || t.roles[role],
        institution: institution.trim() || undefined
      });

      if (res.success) {
        setSuccessMsg('أُنشئ الحساب. افتح رسالة تأكيد البريد الإلكتروني ثم سجّل الدخول.');
        setTimeout(() => onNavigate('login'), 2500);
      } else {
        setErrorMsg(res.error || 'تعذر إنشاء الحساب');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleResetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setLoading(true);
    try {
      const sent = await requestPasswordReset(email);
      setSuccessMsg(sent ? 'إذا كان البريد مسجلًا، فستصلك رسالة إعادة تعيين كلمة المرور.' : 'تعذر إرسال الرسالة. تحقق من إعداد Firebase والبريد ثم حاول مجددًا.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 bg-grid-pattern flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative">
      
      {/* Decorative Aura */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-sky-500/10 blur-[100px] pointer-events-none rounded-full" />

      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <div className="inline-block cursor-pointer mb-2" onClick={() => onNavigate('welcome')}>
          <Logo size="lg" showText={false} />
        </div>
        <h2 className="text-2xl font-black text-white">
          {mode === 'login' && t.auth.welcomeBack}
          {mode === 'register' && t.auth.createAccount}
          {mode === 'forgot_password' && t.auth.resetTitle}
        </h2>
        <p className="mt-1 text-xs text-slate-400">
          {mode === 'login' && t.auth.loginSubtitle}
          {mode === 'register' && t.auth.registerSubtitle}
          {mode === 'forgot_password' && t.auth.resetSubtitle}
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-xl px-4">
        <div className="bg-slate-900/90 border border-slate-800 backdrop-blur-xl py-8 px-6 sm:px-10 shadow-2xl rounded-3xl">
          
          {/* Status Banners */}
          {errorMsg && (
            <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="mb-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* LOGIN FORM */}
          {mode === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t.auth.email}
                </label>
                <div className="relative">
                  <Mail className={`absolute top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 ${isRTL ? 'right-3' : 'left-3'}`} />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="student@polytech.edu"
                    className={`w-full h-11 rounded-xl bg-slate-800/80 border border-slate-700 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 ${
                      isRTL ? 'pr-9 pl-4' : 'pl-9 pr-4'
                    }`}
                    required
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-semibold text-slate-300">
                    {t.auth.password}
                  </label>
                  <button
                    type="button"
                    onClick={() => { setMode('forgot_password'); setErrorMsg(''); }}
                    className="text-[11px] text-sky-400 hover:underline cursor-pointer"
                  >
                    {t.auth.forgotPassword}
                  </button>
                </div>
                <div className="relative">
                  <Lock className={`absolute top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 ${isRTL ? 'right-3' : 'left-3'}`} />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className={`w-full h-11 rounded-xl bg-slate-800/80 border border-slate-700 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 ${
                      isRTL ? 'pr-9 pl-4' : 'pl-9 pr-4'
                    }`}
                    required
                  />
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full flex items-center justify-center gap-2 h-11 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-bold text-sm shadow-lg shadow-sky-600/30 transition cursor-pointer disabled:opacity-50"
                >
                  <span>{loading ? t.common.loading : t.nav.login}</span>
                  <ArrowIcon className="w-4 h-4" />
                </button>
              </div>

              <div className="text-center pt-3 border-t border-slate-800">
                <p className="text-xs text-slate-400">
                  {t.auth.noAccount}{' '}
                  <button
                    type="button"
                    onClick={() => { setMode('register'); setErrorMsg(''); }}
                    className="text-sky-400 font-bold hover:underline cursor-pointer"
                  >
                    {t.auth.createAccount}
                  </button>
                </p>
              </div>
            </form>
          )}

          {/* REGISTER FORM */}
          {mode === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              
              {/* Membership Tier (4 user categories) */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  {t.auth.role} <span className="text-sky-400">*</span>
                </label>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {[
                    { id: 'high_school_student', label: t.roles.high_school_student },
                    { id: 'university_student', label: t.roles.university_student },
                    { id: 'teacher', label: t.roles.teacher },
                    { id: 'expert_engineer', label: t.roles.expert_engineer },
                  ].map(item => (
                    <button
                      type="button"
                      key={item.id}
                      onClick={() => setRole(item.id as UserRole)}
                      className={`p-2.5 rounded-xl border text-center font-semibold transition ${
                        role === item.id
                          ? 'bg-sky-500 text-white border-sky-400 shadow-md shadow-sky-500/20'
                          : 'border-slate-800 bg-slate-800/40 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Names */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {t.auth.displayName} <span className="text-sky-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="مثال: أنس العلمي"
                    className="w-full h-10 rounded-xl bg-slate-800/80 border border-slate-700 px-3 text-xs sm:text-sm text-white focus:outline-none focus:border-sky-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {t.auth.username} <span className="text-sky-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="anas_elec"
                    className="w-full h-10 rounded-xl bg-slate-800/80 border border-slate-700 px-3 text-xs sm:text-sm text-white focus:outline-none focus:border-sky-500 font-mono"
                    required
                  />
                </div>
              </div>

              {/* Email */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t.auth.email} <span className="text-sky-400">*</span>
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@institution.edu"
                  className="w-full h-10 rounded-xl bg-slate-800/80 border border-slate-700 px-3 text-xs sm:text-sm text-white focus:outline-none focus:border-sky-500"
                  required
                />
              </div>

              {/* Discipline & Academic Level */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {t.auth.discipline}
                  </label>
                  <select
                    value={discipline}
                    onChange={(e) => setDiscipline(e.target.value as EngineeringDiscipline)}
                    className="w-full h-10 rounded-xl bg-slate-800/80 border border-slate-700 px-3 text-xs text-white focus:outline-none focus:border-sky-500"
                  >
                    {Object.entries(t.disciplines).map(([k, name]) => (
                      <option key={k} value={k}>
                        {name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {t.auth.educationLevel}
                  </label>
                  <input
                    type="text"
                    value={educationLevel}
                    onChange={(e) => setEducationLevel(e.target.value)}
                    placeholder="ثانوي / ماستر / دكتوراه"
                    className="w-full h-10 rounded-xl bg-slate-800/80 border border-slate-700 px-3 text-xs text-white focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              {/* Institution (Optional) */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t.auth.institution}
                </label>
                <div className="relative">
                  <Building className={`absolute top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 ${isRTL ? 'right-3' : 'left-3'}`} />
                  <input
                    type="text"
                    value={institution}
                    onChange={(e) => setInstitution(e.target.value)}
                    placeholder="المدرسة العليا للتكنولوجيا / ثانوية التقنية..."
                    className={`w-full h-10 rounded-xl bg-slate-800/80 border border-slate-700 text-xs text-white focus:outline-none focus:border-sky-500 ${
                      isRTL ? 'pr-9 pl-3' : 'pl-9 pr-3'
                    }`}
                  />
                </div>
              </div>

              {/* Passwords */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {t.auth.password} <span className="text-sky-400">*</span>
                  </label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full h-10 rounded-xl bg-slate-800/80 border border-slate-700 px-3 text-xs text-white focus:outline-none focus:border-sky-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {t.auth.confirmPassword} <span className="text-sky-400">*</span>
                  </label>
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full h-10 rounded-xl bg-slate-800/80 border border-slate-700 px-3 text-xs text-white focus:outline-none focus:border-sky-500"
                    required
                  />
                </div>
              </div>

              {/* Privacy Notice */}
              <div className="p-3 rounded-xl bg-sky-500/10 border border-sky-500/20 text-sky-400 text-[11px] flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
                <p>
                  معلوماتك الشخصية والمؤسسة التعليمية تظل خاصة ولا تظهر علناً في الملف الشخصي إلا بعد موافقتك الصريحة.
                </p>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full flex items-center justify-center gap-2 h-11 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-bold text-sm shadow-lg shadow-sky-600/30 transition cursor-pointer disabled:opacity-50"
                >
                  <span>{loading ? t.common.loading : t.auth.createAccount}</span>
                  <ArrowIcon className="w-4 h-4" />
                </button>
              </div>

              <div className="text-center pt-3 border-t border-slate-800">
                <p className="text-xs text-slate-400">
                  {t.auth.haveAccount}{' '}
                  <button
                    type="button"
                    onClick={() => { setMode('login'); setErrorMsg(''); }}
                    className="text-sky-400 font-bold hover:underline cursor-pointer"
                  >
                    {t.nav.login}
                  </button>
                </p>
              </div>
            </form>
          )}

          {/* FORGOT PASSWORD FORM */}
          {mode === 'forgot_password' && (
            <form onSubmit={handleResetSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {t.auth.email}
                </label>
                <div className="relative">
                  <Mail className={`absolute top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 ${isRTL ? 'right-3' : 'left-3'}`} />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@domain.edu"
                    className={`w-full h-11 rounded-xl bg-slate-800/80 border border-slate-700 text-xs sm:text-sm text-white focus:outline-none focus:border-sky-500 ${
                      isRTL ? 'pr-9 pl-4' : 'pl-9 pr-4'
                    }`}
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full h-11 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-sky-600/30 transition cursor-pointer"
              >
                {loading ? t.common.loading : t.auth.sendResetLink}
              </button>

              <div className="text-center pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => { setMode('login'); setErrorMsg(''); setSuccessMsg(''); }}
                  className="text-xs text-slate-400 hover:text-white"
                >
                  {t.auth.backToLogin}
                </button>
              </div>
            </form>
          )}

        </div>
      </div>
    </div>
  );
};
