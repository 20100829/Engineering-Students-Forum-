import React, { useState } from 'react';
import { 
  ArrowLeft, 
  ArrowRight, 
  Users, 
  Shield, 
  MessageSquare, 
  PlusCircle, 
  FileText, 
  Cpu, 
  Check, 
  Tag 
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { useData } from '../context/DataContext';
import { ModeratorBadge } from '../components/common/ModeratorBadge';

interface GroupDetailPageProps {
  groupId: string;
  onNavigate: (page: string, params?: any) => void;
  onOpenCreatePost: () => void;
}

export const GroupDetailPage: React.FC<GroupDetailPageProps> = ({
  groupId,
  onNavigate,
  onOpenCreatePost
}) => {
  const { t, currentLang, isRTL } = useLanguage();
  const { groups, posts, projects, joinedGroupIds, toggleJoinGroup } = useData();

  const [activeTab, setActiveTab] = useState<'discussions' | 'projects' | 'about'>('discussions');

  const group = groups.find(g => g.id === groupId) || groups[0];
  const ArrowIcon = isRTL ? ArrowRight : ArrowLeft;

  if (!group) return null;

  const isJoined = joinedGroupIds.includes(group.id);
  const groupPosts = posts.filter(p => p.discipline === group.discipline);
  const groupProjects = projects.filter(p => p.discipline === group.discipline);

  const groupTitle = currentLang === 'ar' ? group.name : currentLang === 'fr' ? group.nameFr : group.nameEn;

  return (
    <div className="space-y-6 pb-20">
      
      {/* Back button */}
      <button
        onClick={() => onNavigate('groups')}
        className="flex items-center gap-2 text-xs font-bold text-slate-500 hover:text-sky-500 transition cursor-pointer"
      >
        <ArrowIcon className="w-4 h-4" />
        <span>العودة لقائمة المجموعات التخصصية</span>
      </button>

      {/* Hero Header Card */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
        <div className="h-48 sm:h-64 relative">
          <img
            src={group.coverImage}
            alt={group.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/40 to-transparent" />
          <div className="absolute bottom-6 right-6 left-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div className="space-y-1">
              <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-sky-500 text-white inline-block">
                {t.disciplines[group.discipline]}
              </span>
              <h1 className="text-2xl sm:text-3xl font-black text-white">{groupTitle}</h1>
              <div className="text-xs text-slate-300 font-mono flex flex-wrap items-center gap-2">
                <span className="flex items-center gap-1">
                  <Users className="w-3.5 h-3.5" />
                  <span>{group.memberCount} عضواً</span>
                </span>
                <span>•</span>
                <span className="flex items-center gap-1.5">
                  <span>المشرف: {group.moderatorName.replace(/\s*\(مشرف.*?\)/, '')}</span>
                  <ModeratorBadge 
                    authorId={group.moderatorId} 
                    authorName={group.moderatorName} 
                    size="xs" 
                  />
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => toggleJoinGroup(group.id)}
                className={`px-5 py-2.5 rounded-2xl text-xs font-bold transition shadow-lg cursor-pointer ${
                  isJoined
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                    : 'bg-sky-600 hover:bg-sky-500 text-white shadow-sky-600/30'
                }`}
              >
                {isJoined ? 'عضو منضم ✓' : 'انضمام إلى المجموعة'}
              </button>
              <button
                onClick={onOpenCreatePost}
                className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold backdrop-blur-md transition"
              >
                <PlusCircle className="w-4 h-4" />
                <span>نشر موضوع</span>
              </button>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center px-6 border-b border-slate-100 dark:border-slate-800 text-xs font-bold gap-6">
          <button
            onClick={() => setActiveTab('discussions')}
            className={`py-3.5 border-b-2 transition ${
              activeTab === 'discussions'
                ? 'border-sky-500 text-sky-500'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-white'
            }`}
          >
            المناقشات والدروس ({groupPosts.length})
          </button>
          <button
            onClick={() => setActiveTab('projects')}
            className={`py-3.5 border-b-2 transition ${
              activeTab === 'projects'
                ? 'border-sky-500 text-sky-500'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-white'
            }`}
          >
            مشاريع المجموعة ({groupProjects.length})
          </button>
          <button
            onClick={() => setActiveTab('about')}
            className={`py-3.5 border-b-2 transition ${
              activeTab === 'about'
                ? 'border-sky-500 text-sky-500'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-white'
            }`}
          >
            عن المجموعة والميثاق
          </button>
        </div>
      </div>

      {/* Tab Content */}
      {activeTab === 'discussions' && (
        <div className="space-y-4">
          {groupPosts.length === 0 ? (
            <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 text-xs text-slate-400">
              لا توجد منشورات خاصة بهذه المجموعة حالياً. كن أول من يشارك!
            </div>
          ) : (
            groupPosts.map(post => (
              <div
                key={post.id}
                onClick={() => onNavigate('post_detail', post.id)}
                className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-sky-500/40 transition cursor-pointer shadow-sm space-y-2"
              >
                <div className="flex flex-wrap items-center justify-between text-xs gap-2">
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-slate-900 dark:text-white">
                      {post.authorName.replace(/\s*\(مشرف.*?\)/, '')}
                    </span>
                    <ModeratorBadge 
                      authorId={post.authorId} 
                      authorName={post.authorName} 
                      isModerator={post.isModerator} 
                      moderatorTitle={post.moderatorTitle} 
                      size="xs" 
                    />
                  </div>
                  <span className="text-slate-400 font-mono text-[11px]">{new Date(post.createdAt).toLocaleDateString('ar-EG')}</span>
                </div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white hover:text-sky-500 transition">
                  {post.title}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                  {post.content}
                </p>
                <div className="flex items-center gap-4 text-xs text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800/60">
                  <span>♥ {post.likesCount} إعجاب</span>
                  <span>💬 {post.commentsCount} تعليق</span>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {activeTab === 'projects' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {groupProjects.length === 0 ? (
            <div className="sm:col-span-2 p-8 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 text-xs text-slate-400">
              لم يتم ربط مشاريع بهذا التخصص بعد.
            </div>
          ) : (
            groupProjects.map(proj => (
              <div
                key={proj.id}
                onClick={() => onNavigate('project_detail', proj.id)}
                className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500/40 transition cursor-pointer space-y-2"
              >
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400">
                  {proj.stage}
                </span>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white line-clamp-1">
                  {proj.title}
                </h4>
                <p className="text-xs text-slate-400 line-clamp-2">{proj.tagline}</p>
              </div>
            ))
          )}
        </div>
      )}

      {activeTab === 'about' && (
        <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-6">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-2">الوصف والرسالة الهندسية</h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              {group.description}
            </p>
          </div>

          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-2">ميثاق وقواعد المجموعة</h3>
            <ul className="text-xs text-slate-500 dark:text-slate-400 space-y-2 list-disc list-inside">
              <li>الالتزام بالاحترام الأكاديمي والمهني ومساعدة المبتدئين وتلاميذ الثانوي.</li>
              <li>توثيق مصادر المعادلات والمخططات الهندسية بدقة.</li>
              <li>يُمنع منعاً باتاً نشر أرقام الهواتف أو وسائل التواصل الخارجية في التعليقات لحماية خصوصية الطلبة.</li>
              <li>طرح الأسئلة بوضوح مع إرفاق المخططات أو رسائل الخطأ بدقة.</li>
            </ul>
          </div>
        </div>
      )}

    </div>
  );
};
