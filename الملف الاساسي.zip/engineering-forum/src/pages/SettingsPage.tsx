import React, { useState } from 'react';
import { 
  Sliders, 
  Globe, 
  Moon, 
  Sun, 
  Lock, 
  ShieldCheck, 
  Trash2, 
  Download, 
  Check, 
  AlertTriangle 
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { useTheme } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';
import { Language } from '../types';

interface SettingsPageProps {
  onNavigate: (page: string) => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({ onNavigate }) => {
  const { currentLang, setLanguage, t } = useLanguage();
  const { theme, toggleTheme, isDark } = useTheme();
  const { currentUser, deleteAccount, updateProfile } = useAuth();

  const [directMsgPref, setDirectMsgPref] = useState<'everyone' | 'verified_only' | 'nobody'>(
    currentUser?.privacy.allowDirectMessages || 'verified_only'
  );

  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleteError, setDeleteError] = useState('');

  const handleMsgPrefChange = (val: 'everyone' | 'verified_only' | 'nobody') => {
    setDirectMsgPref(val);
    if (currentUser) {
      updateProfile({
        privacy: {
          ...currentUser.privacy,
          allowDirectMessages: val
        }
      });
    }
  };

  const handleExportData = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(currentUser, null, 2));
    const dlAnchorElem = document.createElement('a');
    dlAnchorElem.setAttribute("href", dataStr);
    dlAnchorElem.setAttribute("download", `my_engineering_forum_data.json`);
    dlAnchorElem.click();
  };

  const handleDeleteAccount = async () => {
    const deleted = await deleteAccount();
    if (deleted) onNavigate('welcome');
    else setDeleteError('تعذر حذف الحساب. قد تحتاج إلى تسجيل الدخول مجددًا لتأكيد هويتك قبل الحذف.');
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-20">
      
      <div className="pb-4 border-b border-slate-200 dark:border-slate-800">
        <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
          {t.nav.settings}
        </h1>
        <p className="text-xs text-slate-400 mt-0.5">
          إدارة تفضيلات العرض، اللغة، الخصوصية، وحماية الحساب.
        </p>
      </div>

      {/* Language Section */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center gap-2">
          <Globe className="w-5 h-5 text-sky-500" />
          <h2 className="text-sm font-bold text-slate-900 dark:text-white">
            لغة واجهة المنصة (Interface Language)
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {[
            { key: 'ar', label: 'العربية (RTL)' },
            { key: 'en', label: 'English (LTR)' },
            { key: 'fr', label: 'Français (LTR)' },
          ].map(lang => (
            <button
              key={lang.key}
              type="button"
              onClick={() => setLanguage(lang.key as Language)}
              className={`p-3.5 rounded-2xl border text-center font-bold text-xs transition cursor-pointer flex items-center justify-between ${
                currentLang === lang.key
                  ? 'bg-sky-500 text-white border-sky-500 shadow-md shadow-sky-500/20'
                  : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
              }`}
            >
              <span>{lang.label}</span>
              {currentLang === lang.key && <Check className="w-4 h-4" />}
            </button>
          ))}
        </div>
      </div>

      {/* Theme Section */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center gap-2">
          {isDark ? <Moon className="w-5 h-5 text-sky-400" /> : <Sun className="w-5 h-5 text-amber-500" />}
          <h2 className="text-sm font-bold text-slate-900 dark:text-white">
            مظهر الواجهة (Theme)
          </h2>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => !isDark && toggleTheme()}
            className={`p-3.5 rounded-2xl border text-center font-bold text-xs transition cursor-pointer ${
              isDark
                ? 'bg-sky-500 text-white border-sky-500'
                : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            الوضع الداكن التقني (Dark)
          </button>
          <button
            type="button"
            onClick={() => isDark && toggleTheme()}
            className={`p-3.5 rounded-2xl border text-center font-bold text-xs transition cursor-pointer ${
              !isDark
                ? 'bg-sky-500 text-white border-sky-500'
                : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            الوضع الفاتح (Light)
          </button>
        </div>
      </div>

      {/* Privacy and Minor Protection */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-emerald-400" />
          <h2 className="text-sm font-bold text-slate-900 dark:text-white">
            الخصوصية والتواصل الآمن
          </h2>
        </div>

        <div className="space-y-3 text-xs">
          <div>
            <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
              من يمكنه إرسال رسائل خاصة إليك؟
            </label>
            <select
              value={directMsgPref}
              onChange={(e) => handleMsgPrefChange(e.target.value as any)}
              className="w-full h-10 px-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white"
            >
              <option value="verified_only">الأعضاء الموثقون والأساتذة فقط (موصى به لحماية التلاميذ)</option>
              <option value="everyone">جميع أعضاء المنتدى</option>
              <option value="nobody">تعطيل الرسائل المباشرة تماماً</option>
            </select>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-[11px] text-slate-400 space-y-1">
            <p className="font-semibold text-slate-700 dark:text-slate-200">ميثاق حماية القاصرين:</p>
            <p>لا يتم كشف رقم الهاتف أو العنوان الجغرافي أو اسم المؤسسة للعامة، لضمان سلامتكم وأمانكم الرقمي.</p>
          </div>
        </div>
      </div>

      {/* Data Management & Account Deletion */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <h2 className="text-sm font-bold text-slate-900 dark:text-white">
          إدارة البيانات وتصدير الحساب
        </h2>

        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={handleExportData}
            className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold transition"
          >
            <Download className="w-4 h-4 text-sky-400" />
            <span>طلب نسخة احتياطية من بياناتي (JSON)</span>
          </button>

          <button
            onClick={() => setShowDeleteConfirm(!showDeleteConfirm)}
            className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-rose-500/10 text-rose-500 hover:bg-rose-500/20 border border-rose-500/30 text-xs font-semibold transition"
          >
            <Trash2 className="w-4 h-4" />
            <span>حذف الحساب نهائياً</span>
          </button>
        </div>

        {showDeleteConfirm && (
          <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 space-y-3">
            <div className="flex items-center gap-2 text-rose-400 font-bold text-xs">
              <AlertTriangle className="w-4 h-4" />
              <span>هل أنت متأكد من رغبتك في حذف الحساب؟</span>
            </div>
            <p className="text-[11px] text-slate-400">
              سيُحذف حساب الدخول وملفك الشخصي. المنشورات والمشاريع المنشورة لا تُحذف تلقائيًا في هذه النسخة.
            </p>
            {deleteError && <p className="text-[11px] text-rose-400">{deleteError}</p>}
            <div className="flex items-center gap-2">
              <button
                onClick={handleDeleteAccount}
                className="px-4 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold"
              >
                تأكيد الحذف النهائي
              </button>
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-1.5 rounded-xl border border-slate-700 text-xs text-slate-400 hover:text-white"
              >
                إلغاء
              </button>
            </div>
          </div>
        )}
      </div>

    </div>
  );
};
