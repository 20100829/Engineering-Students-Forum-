import React, { useState, useEffect } from 'react';
import { 
  Clock, 
  HelpCircle, 
  CheckCircle2, 
  XCircle, 
  ArrowLeft, 
  ArrowRight, 
  Award, 
  RotateCcw,
  Sparkles,
  AlertTriangle
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { Quiz, QuizAttempt } from '../types';

interface QuizPlayerPageProps {
  quizId: string;
  onNavigate: (page: string, params?: any) => void;
}

export const QuizPlayerPage: React.FC<QuizPlayerPageProps> = ({ quizId, onNavigate }) => {
  const { t, isRTL } = useLanguage();
  const { currentUser } = useAuth();
  const { quizzes, submitQuizAttempt } = useData();

  const quiz = quizzes.find(q => q.id === quizId) || quizzes[0];
  const ArrowIcon = isRTL ? ArrowRight : ArrowLeft;

  const [currentIndex, setCurrentIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<string, any>>({});
  const [secondsRemaining, setSecondsRemaining] = useState((quiz?.durationMinutes || 15) * 60);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [finalScore, setFinalScore] = useState<QuizAttempt | null>(null);

  // Countdown timer
  useEffect(() => {
    if (isSubmitted) return;
    if (secondsRemaining <= 0) {
      handleSubmit();
      return;
    }
    const timer = setInterval(() => {
      setSecondsRemaining(prev => prev - 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [secondsRemaining, isSubmitted]);

  if (!quiz) return null;

  const currentQuestion = quiz.questions[currentIndex];
  const minutes = Math.floor(secondsRemaining / 60);
  const seconds = secondsRemaining % 60;

  const handleSelectAnswer = (ans: any) => {
    if (isSubmitted) return;
    setUserAnswers({
      ...userAnswers,
      [currentQuestion.id]: ans
    });
  };

  const handleSubmit = () => {
    if (isSubmitted) return;

    let score = 0;
    quiz.questions.forEach(q => {
      const uAns = userAnswers[q.id];
      if (q.type === 'multiple_choice') {
        if (Number(uAns) === Number(q.correctAnswer)) score++;
      } else if (q.type === 'true_false') {
        if (Number(uAns) === Number(q.correctAnswer)) score++;
      } else if (q.type === 'short_answer') {
        if (typeof uAns === 'string' && uAns.trim().toLowerCase().includes(String(q.correctAnswer).toLowerCase())) {
          score++;
        }
      }
    });

    const total = quiz.questions.length;
    const percentage = Math.round((score / total) * 100);

    const attempt = submitQuizAttempt({
      quizId: quiz.id,
      quizTitle: quiz.title,
      userId: currentUser?.id || 'guest',
      score,
      totalQuestions: total,
      percentage,
      timeSpentMinutes: Math.round(((quiz.durationMinutes * 60) - secondsRemaining) / 60),
      answers: userAnswers
    });

    setFinalScore(attempt);
    setIsSubmitted(true);
  };

  const handleRetake = () => {
    setUserAnswers({});
    setCurrentIndex(0);
    setSecondsRemaining(quiz.durationMinutes * 60);
    setIsSubmitted(false);
    setFinalScore(null);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-20">
      
      {/* Top Header Bar */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
        <button
          onClick={() => onNavigate('quizzes')}
          className="flex items-center gap-2 text-xs font-bold text-slate-500 hover:text-white transition cursor-pointer"
        >
          <ArrowIcon className="w-4 h-4" />
          <span>الخروج من الاختبار</span>
        </button>

        {/* Live Timer */}
        {!isSubmitted && (
          <div className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl font-mono text-xs font-bold border ${
            secondsRemaining < 120 
              ? 'bg-rose-500/10 text-rose-400 border-rose-500/30 animate-pulse' 
              : 'bg-slate-800/80 text-amber-400 border-slate-700'
          }`}>
            <Clock className="w-3.5 h-3.5" />
            <span>
              {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
            </span>
          </div>
        )}
      </div>

      {/* RESULT DASHBOARD (Shown strictly after completion!) */}
      {isSubmitted && finalScore ? (
        <div className="space-y-6 animate-in fade-in duration-300">
          <div className="rounded-3xl bg-gradient-to-br from-slate-900 via-[#0d1629] to-sky-950 p-8 border border-sky-500/30 text-center space-y-4 shadow-2xl">
            <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-amber-500 to-yellow-300 text-slate-950 flex items-center justify-center mx-auto shadow-lg shadow-amber-500/30">
              <Award className="w-8 h-8" />
            </div>

            <div>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                {t.quizzes.yourScore}
              </h2>
              <div className="text-4xl sm:text-5xl font-black text-amber-400 font-mono my-2">
                {finalScore.score} / {finalScore.totalQuestions}
              </div>
              <p className="text-xs sm:text-sm text-slate-300">
                نسبة النجاح: <strong className="font-mono text-emerald-400 text-base">{finalScore.percentage}%</strong>
              </p>
            </div>

            <p className="text-xs text-sky-400 max-w-md mx-auto leading-relaxed">
              {t.quizzes.reviewNotice}
            </p>

            <div className="flex items-center justify-center gap-4 pt-3">
              <button
                onClick={handleRetake}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold border border-slate-700 transition"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{t.quizzes.tryAgain}</span>
              </button>
              <button
                onClick={() => onNavigate('quizzes')}
                className="px-6 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition shadow-md shadow-sky-600/30"
              >
                العودة للتحديات
              </button>
            </div>
          </div>

          {/* Detailed Question by Question Review */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              المراجعة التفصيلية والتفسيرات الهندسية:
            </h3>

            {quiz.questions.map((q, idx) => {
              const uAns = userAnswers[q.id];
              let isCorrect = false;

              if (q.type === 'multiple_choice' || q.type === 'true_false') {
                isCorrect = Number(uAns) === Number(q.correctAnswer);
              } else if (q.type === 'short_answer') {
                isCorrect = typeof uAns === 'string' && uAns.trim().toLowerCase().includes(String(q.correctAnswer).toLowerCase());
              }

              return (
                <div
                  key={q.id}
                  className={`p-6 rounded-3xl border transition ${
                    isCorrect 
                      ? 'bg-emerald-500/5 border-emerald-500/30' 
                      : 'bg-rose-500/5 border-rose-500/30'
                  }`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-mono font-bold text-slate-400">سؤال {idx + 1}</span>
                    <span className={`text-xs font-bold flex items-center gap-1 ${
                      isCorrect ? 'text-emerald-400' : 'text-rose-400'
                    }`}>
                      {isCorrect ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                      <span>{isCorrect ? 'إجابة صحيحة' : 'إجابة خاطئة'}</span>
                    </span>
                  </div>

                  <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-3">
                    {q.question}
                  </h4>

                  {/* Options display with correct indicator */}
                  {q.options && (
                    <div className="space-y-1.5 mb-3">
                      {q.options.map((opt, oIdx) => {
                        const isChosen = Number(uAns) === oIdx;
                        const isActualCorrect = Number(q.correctAnswer) === oIdx;

                        return (
                          <div
                            key={oIdx}
                            className={`p-2.5 rounded-xl text-xs flex items-center justify-between border ${
                              isActualCorrect
                                ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300 font-bold'
                                : isChosen
                                  ? 'bg-rose-500/15 border-rose-500/40 text-rose-300 font-medium'
                                  : 'bg-slate-100 dark:bg-slate-800/40 border-transparent text-slate-400'
                            }`}
                          >
                            <span>{opt}</span>
                            {isActualCorrect && <span className="text-[10px] text-emerald-400 font-mono">الإجابة المعتمدة ✓</span>}
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Explanation Note */}
                  <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-sky-300 space-y-1">
                    <span className="font-bold text-[11px] uppercase tracking-wide text-amber-400 block">
                      {t.quizzes.explanation}:
                    </span>
                    <p className="leading-relaxed">{q.explanation}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        /* ACTIVE TEST RUNNER */
        <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm space-y-6">
          
          {/* Question Index Progress */}
          <div className="flex items-center justify-between text-xs text-slate-400 pb-3 border-b border-slate-100 dark:border-slate-800">
            <span className="font-mono">السؤال {currentIndex + 1} من {quiz.questions.length}</span>
            <div className="flex gap-1.5">
              {quiz.questions.map((_, i) => (
                <div
                  key={i}
                  className={`w-6 h-1.5 rounded-full transition-all ${
                    i === currentIndex
                      ? 'bg-amber-400 w-8'
                      : userAnswers[quiz.questions[i].id] !== undefined
                        ? 'bg-sky-500'
                        : 'bg-slate-200 dark:bg-slate-800'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Question Text */}
          <div className="space-y-3">
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-sky-500/10 text-sky-400 uppercase font-mono">
              {currentQuestion.type === 'multiple_choice' ? 'اختيار من متعدد' : currentQuestion.type === 'true_false' ? 'صح أو خطأ' : 'سؤال تقني قصير'}
            </span>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white leading-relaxed">
              {currentQuestion.question}
            </h2>
          </div>

          {/* Options / Input Form */}
          <div className="space-y-2.5 pt-2">
            {currentQuestion.options ? (
              currentQuestion.options.map((option, optIdx) => {
                const isSelected = userAnswers[currentQuestion.id] === optIdx;
                return (
                  <button
                    key={optIdx}
                    type="button"
                    onClick={() => handleSelectAnswer(optIdx)}
                    className={`w-full p-4 rounded-2xl border text-right transition cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'bg-sky-500/15 border-sky-500 text-sky-400 font-bold shadow-md shadow-sky-500/10'
                        : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700/80 text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <span className="text-xs sm:text-sm">{option}</span>
                    <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                      isSelected ? 'border-sky-400 bg-sky-400 text-slate-950 font-bold text-[10px]' : 'border-slate-500'
                    }`}>
                      {isSelected ? '✓' : ''}
                    </div>
                  </button>
                );
              })
            ) : (
              <div>
                <input
                  type="text"
                  value={userAnswers[currentQuestion.id] || ''}
                  onChange={(e) => handleSelectAnswer(e.target.value)}
                  placeholder="اكتب إجابتك التقنية المحددة هنا..."
                  className="w-full px-4 py-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:border-sky-500"
                />
              </div>
            )}
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center justify-between pt-6 border-t border-slate-100 dark:border-slate-800">
            <button
              onClick={() => setCurrentIndex(i => Math.max(i - 1, 0))}
              disabled={currentIndex === 0}
              className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-400 hover:text-white disabled:opacity-30 text-xs font-semibold cursor-pointer"
            >
              {t.quizzes.prevQuestion}
            </button>

            {currentIndex < quiz.questions.length - 1 ? (
              <button
                onClick={() => setCurrentIndex(i => i + 1)}
                className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition shadow-md shadow-sky-600/30 cursor-pointer"
              >
                <span>{t.quizzes.nextQuestion}</span>
                <ArrowIcon className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                className="flex items-center gap-1.5 px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 text-slate-950 text-xs font-black transition shadow-lg shadow-amber-500/30 cursor-pointer"
              >
                <span>{t.quizzes.submitAnswers}</span>
                <CheckCircle2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
