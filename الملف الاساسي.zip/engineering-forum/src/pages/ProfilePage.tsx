import React, { useState } from 'react';
import { 
  User, 
  GraduationCap, 
  Cpu, 
  Award, 
  ShieldCheck, 
  FileText, 
  Lock, 
  Edit3, 
  Mail, 
  Building, 
  Sparkles,
  CheckCircle2,
  Bookmark
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { ModeratorBadge, isSpaceManager, getModeratorDetails } from '../components/common/ModeratorBadge';

interface ProfilePageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({ onNavigate }) => {
  const { t } = useLanguage();
  const { currentUser, updateProfile } = useAuth();
  const { projects, courses, userCourseProgress } = useData();

  const [isEditing, setIsEditing] = useState(false);
  const [bioInput, setBioInput] = useState(currentUser?.bio || '');
  const [skillInput, setSkillInput] = useState('');
  const [skillsList, setSkillsList] = useState(currentUser?.skills || []);
  const [showInstitution, setShowInstitution] = useState(currentUser?.privacy.showInstitution || false);

  if (!currentUser) return null;

  const userProjects = projects.filter(p => p.creatorId === currentUser.id);

  const handleAddSkill = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (skillInput.trim() && !skillsList.includes(skillInput.trim())) {
        const next = [...skillsList, skillInput.trim()];
        setSkillsList(next);
        setSkillInput('');
      }
    }
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    setSkillsList(skillsList.filter(s => s !== skillToRemove));
  };

  const handleSaveProfile = () => {
    updateProfile({
      bio: bioInput.trim(),
      skills: skillsList,
      privacy: {
        ...currentUser.privacy,
        showInstitution
      }
    });
    setIsEditing(false);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20">
      
      {/* Profile Card Header */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
        
        {/* Cover with blueprint circuit styling */}
        <div className="h-36 sm:h-44 bg-gradient-to-r from-sky-950 via-[#0a152d] to-slate-950 relative border-b border-sky-500/20">
          <div className="absolute inset-0 bg-grid-pattern opacity-40" />
          <div className="absolute top-4 left-4 flex items-center gap-2">
            <button
              onClick={() => onNavigate('cv')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold backdrop-blur-md transition cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5 text-emerald-400" />
              <span>{t.cv.title} (PDF)</span>
            </button>
            <button
              onClick={() => setIsEditing(!isEditing)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold backdrop-blur-md transition cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5 text-sky-400" />
              <span>{isEditing ? 'إلغاء التعديل' : 'تعديل الملف'}</span>
            </button>
          </div>
        </div>

        {/* User Avatar & Basics */}
        <div className="px-6 sm:px-8 pb-8 pt-0 relative">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 -mt-16 sm:-mt-20 mb-6">
            <div className="flex items-end gap-4">
              <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-gradient-to-tr from-sky-600 to-indigo-600 text-white font-black text-3xl flex items-center justify-center border-4 border-white dark:border-slate-900 shadow-2xl shrink-0">
                {currentUser.displayName.charAt(0)}
              </div>
              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
                    {currentUser.displayName}
                  </h1>
                  <ModeratorBadge 
                    authorId={currentUser.id} 
                    authorName={currentUser.displayName} 
                    isModerator={currentUser.isModerator} 
                    moderatorTitle={currentUser.moderatorTitle} 
                    variant="detailed"
                    size="md"
                  />
                  {currentUser.isVerified && (
                    <span title="عضو موثق">
                      <ShieldCheck className="w-5 h-5 text-emerald-400" />
                    </span>
                  )}
                </div>
                <p className="text-xs text-sky-500 font-mono">@{currentUser.username}</p>
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  {isSpaceManager(currentUser.id, currentUser.displayName, currentUser.isModerator) && (
                    <span className="text-[11px] font-bold px-3 py-0.5 rounded-full bg-gradient-to-r from-emerald-500/20 to-teal-500/20 text-emerald-600 dark:text-emerald-300 border border-emerald-500/30 flex items-center gap-1.5 shadow-sm">
                      <Award className="w-3.5 h-3.5 text-emerald-500" />
                      <span>{getModeratorDetails(currentUser.id, currentUser.displayName, currentUser.moderatorTitle).title}</span>
                    </span>
                  )}
                  <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-sky-500/10 text-sky-500 border border-sky-500/20">
                    {t.roles[currentUser.role]}
                  </span>
                  <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/20">
                    {t.disciplines[currentUser.discipline]}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Bio & Academic Info */}
          {isEditing ? (
            <div className="space-y-4 p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  النبذة التعريفية (Bio)
                </label>
                <textarea
                  rows={3}
                  value={bioInput}
                  onChange={(e) => setBioInput(e.target.value)}
                  className="w-full p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  المهارات التقنية (اضغط Enter للإضافة)
                </label>
                <div className="flex flex-wrap gap-1.5 p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                  {skillsList.map(s => (
                    <span key={s} className="px-2.5 py-1 rounded-lg bg-sky-500/10 text-sky-400 text-xs flex items-center gap-1 font-mono">
                      {s}
                      <button type="button" onClick={() => handleRemoveSkill(s)} className="hover:text-rose-400">&times;</button>
                    </span>
                  ))}
                  <input
                    type="text"
                    value={skillInput}
                    onChange={(e) => setSkillInput(e.target.value)}
                    onKeyDown={handleAddSkill}
                    placeholder="مهارة: MATLAB, PLC, C++..."
                    className="bg-transparent text-xs text-slate-900 dark:text-white p-1 focus:outline-none flex-1 min-w-[120px]"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="showInst"
                  checked={showInstitution}
                  onChange={(e) => setShowInstitution(e.target.checked)}
                  className="rounded text-sky-500"
                />
                <label htmlFor="showInst" className="text-xs text-slate-600 dark:text-slate-300">
                  إظهار المؤسسة التعليمية للعامة في الملف الشخصي
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white"
                >
                  إلغاء
                </button>
                <button
                  onClick={handleSaveProfile}
                  className="px-5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold shadow-md shadow-sky-600/30"
                >
                  حفظ التعديلات
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                {currentUser.bio || 'لم يتم إضافة نبذة تعريفية بعد.'}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <GraduationCap className="w-4 h-4 text-purple-400" />
                  <span>المستوى: <strong className="text-slate-700 dark:text-slate-300">{currentUser.educationLevel}</strong></span>
                </div>

                {currentUser.institution && (currentUser.privacy.showInstitution || currentUser.role === 'teacher') && (
                  <div className="flex items-center gap-2">
                    <Building className="w-4 h-4 text-sky-400" />
                    <span>المؤسسة: <strong className="text-slate-700 dark:text-slate-300">{currentUser.institution}</strong></span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Skills Section */}
          <div className="mt-6 pt-6 border-t border-slate-100 dark:border-slate-800">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">
              المهارات والقدرات الهندسية المعتمدة
            </h3>
            <div className="flex flex-wrap gap-2">
              {currentUser.skills.length === 0 ? (
                <span className="text-xs text-slate-400 italic">أضف مهاراتك من زر تعديل الملف.</span>
              ) : (
                currentUser.skills.map(skill => (
                  <span
                    key={skill}
                    className="px-3 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-semibold font-mono border border-slate-200 dark:border-slate-700"
                  >
                    {skill}
                  </span>
                ))
              )}
            </div>
          </div>

          {/* Achievements / Credentials */}
          <div className="mt-6 pt-6 border-t border-slate-100 dark:border-slate-800">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-3">
              الشهادات والإنجازات العلمية
            </h3>
            <div className="space-y-2">
              {currentUser.achievements.map((ach, i) => (
                <div key={i} className="flex items-center gap-2.5 p-3 rounded-2xl bg-amber-500/5 border border-amber-500/20 text-xs text-amber-300">
                  <Award className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>{ach}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* User's Projects Showcase */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-4 shadow-sm">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <Cpu className="w-5 h-5 text-emerald-400" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              المشاريع والابتكارات المسجلة باسمك ({userProjects.length})
            </h3>
          </div>
          <button
            onClick={() => onNavigate('create_project')}
            className="text-xs text-sky-500 hover:underline font-bold"
          >
            + إضافة مشروع جديد
          </button>
        </div>

        {userProjects.length === 0 ? (
          <p className="text-xs text-slate-400 py-4">لم توثق أي مشروع هندسي بعد.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {userProjects.map(p => (
              <div
                key={p.id}
                onClick={() => onNavigate('project_detail', p.id)}
                className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 hover:border-emerald-500/40 transition cursor-pointer space-y-2"
              >
                <div className="flex items-center justify-between text-[10px] font-bold text-emerald-400">
                  <span>{p.stage}</span>
                  <span className="font-mono">♥ {p.likesCount}</span>
                </div>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white line-clamp-1">
                  {p.title}
                </h4>
                <p className="text-[11px] text-slate-400 line-clamp-2">{p.tagline}</p>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};
