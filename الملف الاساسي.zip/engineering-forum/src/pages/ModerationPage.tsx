import React from 'react';
import { ShieldAlert, CheckCircle2, XCircle, ArrowLeft, ArrowRight, ShieldCheck } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';

export const ModerationPage: React.FC = () => {
  const { t, isRTL } = useLanguage();
  const { canModerate, isAdmin } = useAuth();
  const { reports, resolveReport, posts } = useData();

  const ArrowIcon = isRTL ? ArrowRight : ArrowLeft;

  if (!canModerate && !isAdmin) {
    return (
      <div className="max-w-md mx-auto p-8 rounded-3xl bg-slate-900 border border-slate-800 text-center text-xs text-slate-400 my-12">
        هذا القسم مخصص للأساتذة والمشرفين لمراجعة المحتوى وتدقيق معايير الأمان وسلامة الطلاب.
      </div>
    );
  }

  const pendingReports = reports.filter(r => r.status === 'pending');

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20">
      
      <div className="pb-4 border-b border-slate-200 dark:border-slate-800">
        <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
          <ShieldAlert className="w-6 h-6 text-rose-500" />
          <span>{t.nav.moderation}</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          مراجعة البلاغات، التحقق من احترام معايير النشر الهندسي وحماية خصوصية التلاميذ.
        </p>
      </div>

      <div className="space-y-4">
        {pendingReports.length === 0 ? (
          <div className="p-12 text-center rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
            <ShieldCheck className="w-12 h-12 text-emerald-400 mx-auto" />
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">
              قائمة البلاغات نظيفة تماماً!
            </h3>
            <p className="text-xs text-slate-400">
              تمت معالجة جميع البلاغات ولا توجد أي مخالفات معلقة حالياً.
            </p>
          </div>
        ) : (
          pendingReports.map(rep => (
            <div
              key={rep.id}
              className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3"
            >
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-rose-500 bg-rose-500/10 px-2.5 py-0.5 rounded-full border border-rose-500/20">
                  نوع البلاغ: {rep.targetType}
                </span>
                <span className="text-slate-400 font-mono text-[11px]">
                  {new Date(rep.createdAt).toLocaleDateString('ar-EG')}
                </span>
              </div>

              <div>
                <p className="text-sm font-bold text-slate-900 dark:text-white leading-snug">
                  {rep.reason}
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  المُبلِغ: <strong className="text-slate-700 dark:text-slate-300">{rep.reporterName}</strong> • كود العنصر: <span className="font-mono">{rep.targetId}</span>
                </p>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  onClick={() => resolveReport(rep.id, 'dismissed')}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs text-slate-500 dark:text-slate-400 hover:text-white"
                >
                  {t.admin.dismissReport}
                </button>
                <button
                  onClick={() => resolveReport(rep.id, 'resolved')}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-md shadow-rose-600/30"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>معالجة واتخاذ إجراء</span>
                </button>
              </div>
            </div>
          ))
        )}
      </div>

    </div>
  );
};
