import React, { useState } from 'react';
import { 
  GraduationCap, 
  Search, 
  Clock, 
  Star, 
  Users, 
  CheckCircle2, 
  ArrowRight, 
  ArrowLeft,
  Sparkles
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { useData } from '../context/DataContext';
import { EngineeringDiscipline } from '../types';

interface CoursesPageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const CoursesPage: React.FC<CoursesPageProps> = ({ onNavigate }) => {
  const { t, isRTL } = useLanguage();
  const { courses, userCourseProgress } = useData();

  const [selectedDiscipline, setSelectedDiscipline] = useState<EngineeringDiscipline | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const ArrowIcon = isRTL ? ArrowLeft : ArrowRight;

  const filteredCourses = courses.filter(c => {
    const matchDiscipline = selectedDiscipline === 'all' || c.discipline === selectedDiscipline;
    const matchQuery = !searchQuery ||
      c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchDiscipline && matchQuery;
  });

  return (
    <div className="space-y-6 pb-20">
      
      {/* Header Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-purple-950 via-slate-900 to-sky-950 border border-purple-500/20 shadow-xl relative overflow-hidden">
        <div className="relative z-10 max-w-2xl space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/30 text-purple-400 text-xs font-semibold">
            <GraduationCap className="w-3.5 h-3.5" />
            <span>المسارات التدريبية الأكاديمية</span>
          </div>
          <h1 className="text-xl sm:text-3xl font-black text-white">
            {t.courses.title}
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            {t.courses.subtitle}
          </p>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="flex flex-col sm:flex-row gap-3 p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="relative flex-1">
          <Search className={`absolute top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 ${isRTL ? 'right-3' : 'left-3'}`} />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث عن دورة أو مهارة هندسية..."
            className={`w-full h-10 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-purple-500 ${
              isRTL ? 'pr-9 pl-3' : 'pl-9 pr-3'
            }`}
          />
        </div>

        <select
          value={selectedDiscipline}
          onChange={(e) => setSelectedDiscipline(e.target.value as any)}
          className="h-10 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 px-3 text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:border-purple-500"
        >
          <option value="all">جميع التخصصات التدريبية</option>
          {Object.entries(t.disciplines).map(([k, name]) => (
            <option key={k} value={k}>{name}</option>
          ))}
        </select>
      </div>

      {/* Courses Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredCourses.map(course => {
          const progress = userCourseProgress[course.id]?.progressPercent || 0;

          return (
            <div
              key={course.id}
              className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm hover:shadow-lg transition-all flex flex-col justify-between"
            >
              <div>
                {/* Cover image */}
                <div 
                  onClick={() => onNavigate('course_detail', course.id)}
                  className="h-44 relative overflow-hidden cursor-pointer group"
                >
                  <img
                    src={course.coverImage}
                    alt={course.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
                  <div className="absolute top-3 right-3 flex items-center gap-1.5">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-purple-600 text-white shadow-md">
                      {t.disciplines[course.discipline]}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-900/80 text-amber-400 border border-slate-700">
                      {course.level === 'beginner' ? t.courses.levelBeginner : course.level === 'intermediate' ? t.courses.levelIntermediate : t.courses.levelAdvanced}
                    </span>
                  </div>
                </div>

                {/* Info */}
                <div className="p-6 space-y-3">
                  <div 
                    onClick={() => onNavigate('course_detail', course.id)}
                    className="cursor-pointer"
                  >
                    <h3 className="text-base font-bold text-slate-900 dark:text-white hover:text-purple-400 transition leading-snug">
                      {course.title}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                      {course.description}
                    </p>
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
                    <span>المحاضر: <strong className="text-slate-700 dark:text-slate-300">{course.instructorName}</strong></span>
                    <span className="text-amber-400 font-bold flex items-center gap-1">
                      <Star className="w-3.5 h-3.5 fill-current" />
                      {course.rating}
                    </span>
                  </div>

                  {/* Progress bar if started */}
                  {progress > 0 && (
                    <div className="space-y-1 pt-1">
                      <div className="flex items-center justify-between text-[10px] font-mono text-slate-400">
                        <span>{t.courses.progress}</span>
                        <span className="text-sky-400 font-bold">{progress}%</span>
                      </div>
                      <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                        <div 
                          className="h-full bg-gradient-to-r from-sky-500 to-purple-600 rounded-full transition-all duration-500"
                          style={{ width: `${progress}%` }}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Bottom Actions */}
              <div className="p-6 pt-0 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between mt-2">
                <span className="text-xs text-slate-400 font-mono">
                  📚 {course.lessons.length} {t.courses.lessonsCount}
                </span>

                <button
                  onClick={() => onNavigate('course_detail', course.id)}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-md shadow-purple-600/30 transition cursor-pointer"
                >
                  <span>{progress > 0 ? t.courses.continueCourse : t.courses.startCourse}</span>
                  <ArrowIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
