import React, { useState } from 'react';
import { 
  ArrowLeft, 
  ArrowRight, 
  PlayCircle, 
  CheckCircle2, 
  Circle, 
  FileText, 
  Award, 
  User, 
  Clock, 
  BookOpen,
  Sparkles
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { useData } from '../context/DataContext';

interface CourseDetailPageProps {
  courseId: string;
  onNavigate: (page: string, params?: any) => void;
}

export const CourseDetailPage: React.FC<CourseDetailPageProps> = ({
  courseId,
  onNavigate
}) => {
  const { t, isRTL } = useLanguage();
  const { courses, userCourseProgress, toggleLessonComplete } = useData();

  const course = courses.find(c => c.id === courseId) || courses[0];
  const ArrowIcon = isRTL ? ArrowRight : ArrowLeft;

  const [activeLessonId, setActiveLessonId] = useState<string>(course.lessons[0]?.id || '');

  if (!course) return null;

  const progressObj = userCourseProgress[course.id] || { completedLessonIds: [], progressPercent: 0 };
  const activeLesson = course.lessons.find(l => l.id === activeLessonId) || course.lessons[0];

  return (
    <div className="space-y-6 pb-20">
      
      {/* Back button */}
      <button
        onClick={() => onNavigate('courses')}
        className="flex items-center gap-2 text-xs font-bold text-slate-500 hover:text-purple-400 transition cursor-pointer"
      >
        <ArrowIcon className="w-4 h-4" />
        <span>العودة لقائمة الدورات</span>
      </button>

      {/* Course Header Banner */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/20">
                {t.disciplines[course.discipline]}
              </span>
              <span className="text-xs text-slate-400 font-mono">
                المحاضر: {course.instructorName} ({t.roles[course.instructorRole]})
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
              {course.title}
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 max-w-3xl leading-relaxed">
              {course.description}
            </p>
          </div>

          {/* Progress Box */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 w-full lg:w-72 shrink-0 space-y-2">
            <div className="flex items-center justify-between text-xs font-bold">
              <span className="text-slate-700 dark:text-slate-300">نسبة التقدم الكلية:</span>
              <span className="text-purple-400 font-mono text-sm">{progressObj.progressPercent}%</span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-purple-500 to-sky-500 rounded-full transition-all duration-500"
                style={{ width: `${progressObj.progressPercent}%` }}
              />
            </div>
            <p className="text-[10px] text-slate-400">
              تم إنجاز {progressObj.completedLessonIds.length} من أصل {course.lessons.length} دروس
            </p>
          </div>
        </div>
      </div>

      {/* Main Grid: Player on Left, Lessons Syllabus on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Lesson Player & Notes */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Simulated Video / Technical Player */}
          <div className="aspect-video w-full rounded-3xl bg-slate-950 border border-slate-800 overflow-hidden relative flex flex-col items-center justify-center text-center p-6 shadow-2xl">
            <div className="w-16 h-16 rounded-full bg-purple-600/20 text-purple-400 border border-purple-500/30 flex items-center justify-center mb-3 animate-pulse">
              <PlayCircle className="w-10 h-10" />
            </div>
            <h3 className="text-base sm:text-lg font-bold text-white mb-1">
              {activeLesson.title}
            </h3>
            <p className="text-xs text-slate-400 font-mono mb-4">
              المدة المقدرة: {activeLesson.duration} • بيئة المحاكاة الهندسية
            </p>
            <div className="flex items-center gap-3">
              <button 
                onClick={() => toggleLessonComplete(course.id, activeLesson.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                  progressObj.completedLessonIds.includes(activeLesson.id)
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    : 'bg-purple-600 hover:bg-purple-500 text-white shadow-lg'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>
                  {progressObj.completedLessonIds.includes(activeLesson.id) ? 'تم إكمال هذا الدرس ✓' : 'تحديد الدرس كمكتمل'}
                </span>
              </button>
            </div>
          </div>

          {/* Lesson Synopsis & Notes */}
          <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              ملخص الوحدة والمفاهيم الهندسية الأساسية
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              {activeLesson.summary}
            </p>

            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5 text-sky-400" />
                <div>
                  <p className="text-xs font-bold text-slate-900 dark:text-white">
                    ملخص الدرس والمخططات الملحقة.pdf
                  </p>
                  <span className="text-[10px] text-slate-400">تحميل ملف التدريب العملي المعتمد</span>
                </div>
              </div>
              <button
                onClick={() => alert('جاري تنزيل ملخص الدرس التدريبي')}
                className="px-3.5 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-700 hover:bg-sky-500 hover:text-white text-xs font-semibold transition"
              >
                تحميل المرفق
              </button>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Course Curriculum List */}
        <div className="space-y-4">
          <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-3 shadow-sm">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              {t.courses.curriculum} ({course.lessons.length} دروس)
            </h3>

            <div className="space-y-2">
              {course.lessons.map((lesson, idx) => {
                const isCurrent = lesson.id === activeLessonId;
                const isCompleted = progressObj.completedLessonIds.includes(lesson.id);

                return (
                  <div
                    key={lesson.id}
                    onClick={() => setActiveLessonId(lesson.id)}
                    className={`p-3.5 rounded-2xl border transition cursor-pointer flex items-center justify-between ${
                      isCurrent
                        ? 'bg-purple-500/10 border-purple-500 text-purple-400 font-bold shadow-sm'
                        : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-3 truncate">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleLessonComplete(course.id, lesson.id);
                        }}
                        className="text-slate-400 hover:text-emerald-400"
                      >
                        {isCompleted ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 fill-emerald-400/20" />
                        ) : (
                          <Circle className="w-4 h-4" />
                        )}
                      </button>
                      <div className="truncate text-xs">
                        <span className="block truncate">{idx + 1}. {lesson.title}</span>
                        <span className="text-[10px] text-slate-400 font-mono">{lesson.duration}</span>
                      </div>
                    </div>

                    <PlayCircle className={`w-4 h-4 shrink-0 ${isCurrent ? 'text-purple-400' : 'text-slate-400'}`} />
                  </div>
                );
              })}
            </div>

            {/* Final Exam CTA */}
            <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => onNavigate('quizzes')}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold text-xs shadow-md shadow-purple-600/30 transition hover:scale-[1.02] cursor-pointer"
              >
                <Award className="w-4 h-4" />
                <span>{t.courses.finalQuiz}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
