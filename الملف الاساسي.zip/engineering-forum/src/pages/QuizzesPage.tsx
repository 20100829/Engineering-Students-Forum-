import React from 'react';
import { 
  HelpCircle, 
  Clock, 
  Award, 
  Users, 
  ArrowLeft, 
  ArrowRight, 
  CheckCircle2, 
  Sparkles,
  Zap
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { useData } from '../context/DataContext';

interface QuizzesPageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const QuizzesPage: React.FC<QuizzesPageProps> = ({ onNavigate }) => {
  const { t, isRTL } = useLanguage();
  const { quizzes, userQuizAttempts } = useData();

  const ArrowIcon = isRTL ? ArrowLeft : ArrowRight;

  return (
    <div className="space-y-6 pb-20">
      
      {/* Header Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-amber-950/80 via-slate-900 to-slate-900 border border-amber-500/30 shadow-xl relative overflow-hidden">
        <div className="relative z-10 max-w-2xl space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold">
            <Zap className="w-3.5 h-3.5" />
            <span>التحديات والمسابقات العلمية</span>
          </div>
          <h1 className="text-xl sm:text-3xl font-black text-white">
            {t.quizzes.title}
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            {t.quizzes.subtitle}
          </p>
        </div>
      </div>

      {/* User previous attempts record */}
      {userQuizAttempts.length > 0 && (
        <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-4">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              سجل نتائجك السابقة في التحديات
            </h3>
            <span className="text-xs text-amber-500 font-bold">{userQuizAttempts.length} اختبارات مجتازة</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {userQuizAttempts.map(att => (
              <div 
                key={att.id}
                className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-1"
              >
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-slate-900 dark:text-white truncate">{att.quizTitle}</span>
                  <span className={`font-mono ${att.percentage >= 70 ? 'text-emerald-400' : 'text-amber-400'}`}>
                    {att.percentage}%
                  </span>
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                  <span>النتيجة: {att.score}/{att.totalQuestions}</span>
                  <span>{new Date(att.date).toLocaleDateString('ar-EG')}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Available Quizzes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {quizzes.map(quiz => (
          <div
            key={quiz.id}
            className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-7 shadow-sm hover:shadow-lg transition-all flex flex-col justify-between space-y-4"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-md bg-sky-500/10 text-sky-400 border border-sky-500/20">
                  {t.disciplines[quiz.discipline]}
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-400 font-mono">
                  صعوبة: {quiz.difficulty}
                </span>
              </div>

              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white leading-snug">
                  {quiz.title}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                  {quiz.description}
                </p>
              </div>

              <div className="flex items-center gap-4 text-xs text-slate-400 font-mono pt-1">
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  {quiz.durationMinutes} {t.quizzes.duration}
                </span>
                <span className="flex items-center gap-1">
                  <HelpCircle className="w-3.5 h-3.5 text-sky-400" />
                  {quiz.questions.length} {t.quizzes.questionsCount}
                </span>
                <span className="flex items-center gap-1">
                  <Users className="w-3.5 h-3.5 text-purple-400" />
                  {quiz.participantsCount} مشارك
                </span>
              </div>
            </div>

            {/* Start Button */}
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <span className="text-[11px] text-slate-400">
                إعداد: <strong className="text-slate-700 dark:text-slate-200">{quiz.authorName}</strong>
              </span>

              <button
                onClick={() => onNavigate('quiz_player', quiz.id)}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs transition shadow-md shadow-amber-500/20 cursor-pointer"
              >
                <span>{t.quizzes.startChallenge}</span>
                <ArrowIcon className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
