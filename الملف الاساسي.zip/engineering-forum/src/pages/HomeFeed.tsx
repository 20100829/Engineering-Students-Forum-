import React, { useState } from 'react';
import { 
  Sparkles, 
  MessageSquare, 
  Heart, 
  Bookmark, 
  Share2, 
  FileText, 
  Cpu, 
  Users, 
  GraduationCap, 
  HelpCircle, 
  ArrowLeft, 
  ArrowRight, 
  Clock, 
  Tag, 
  PlusCircle, 
  ChevronRight,
  TrendingUp,
  ShieldCheck,
  Zap,
  CheckCircle2
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { Post, EngineeringProject, EngineeringDiscipline } from '../types';
import { ModeratorBadge } from '../components/common/ModeratorBadge';

interface HomeFeedProps {
  onNavigate: (page: string, params?: any) => void;
  onOpenCreatePost: () => void;
  onOpenPdfViewer: (resource: any) => void;
  onOpenReport: (item: any) => void;
}

export const HomeFeed: React.FC<HomeFeedProps> = ({
  onNavigate,
  onOpenCreatePost,
  onOpenPdfViewer,
  onOpenReport
}) => {
  const { t, isRTL } = useLanguage();
  const { currentUser } = useAuth();
  const { 
    posts, 
    projects, 
    groups, 
    courses, 
    quizzes, 
    toggleLikePost, 
    toggleSavePost, 
    savedPostIds,
    joinedGroupIds,
    toggleJoinGroup 
  } = useData();

  const [activeTab, setActiveTab] = useState<'latest' | 'trending'>('latest');
  const [copiedPostId, setCopiedPostId] = useState<string | null>(null);

  const ArrowIcon = isRTL ? ArrowLeft : ArrowRight;

  const sortedPosts = [...posts].sort((a, b) => {
    if (activeTab === 'trending') {
      return (b.likesCount + b.commentsCount * 2) - (a.likesCount + a.commentsCount * 2);
    }
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  const handleShare = (post: Post) => {
    navigator.clipboard?.writeText(window.location.origin + '/#post-' + post.id);
    setCopiedPostId(post.id);
    setTimeout(() => setCopiedPostId(null), 2000);
  };

  return (
    <div className="space-y-8 pb-16">
      
      {/* Engineering Welcome Banner */}
      <div className="relative rounded-3xl bg-gradient-to-r from-slate-900 via-[#0b172a] to-sky-950/80 border border-sky-500/20 p-6 sm:p-8 overflow-hidden shadow-xl">
        <div className="absolute top-0 right-0 w-80 h-80 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/10 border border-sky-500/30 text-sky-400 text-xs font-semibold">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>{t.app.motto}</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white">
              أهلاً بك، {currentUser ? currentUser.displayName : 'زميلنا المهندس'}!
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              تصفح آخر النقاشات الهندسية، وشارك مخططاتك الكهربائية ومشاريعك التقنية مع زملائك والأساتذة المشرفين.
            </p>
            <div className="pt-1">
              <button
                onClick={() => onNavigate('leadership')}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-semibold transition cursor-pointer shadow-sm"
              >
                <span>👑 هيئة المسؤولين والمشرفين • المدير العام: قداري محمود طه ياسين | المشرفان: فضيلي فاتح وعبيدي صلاح الدين ←</span>
              </button>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              onClick={onOpenCreatePost}
              className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-sky-600/30 transition hover:scale-[1.02] cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>{t.nav.newPost}</span>
            </button>
            <button
              onClick={() => onNavigate('create_project')}
              className="flex items-center gap-2 px-4 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs sm:text-sm font-semibold transition cursor-pointer"
            >
              <Cpu className="w-4 h-4 text-emerald-400" />
              <span>{t.nav.newProject}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Feed + Right Sidebar widgets */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left 2 Cols: Discussions Feed */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Feed Header & Tabs */}
          <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('latest')}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                  activeTab === 'latest'
                    ? 'bg-sky-500 text-white shadow-sm'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Clock className="w-3.5 h-3.5" />
                <span>{t.home.latestPosts}</span>
              </button>

              <button
                onClick={() => setActiveTab('trending')}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                  activeTab === 'trending'
                    ? 'bg-sky-500 text-white shadow-sm'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <TrendingUp className="w-3.5 h-3.5" />
                <span>{t.home.trendingPosts}</span>
              </button>
            </div>

            <button
              onClick={() => onNavigate('posts')}
              className="text-xs text-sky-500 hover:underline font-semibold flex items-center gap-1 cursor-pointer"
            >
              <span>{t.home.viewAll}</span>
              <ArrowIcon className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Posts Feed Items */}
          <div className="space-y-4">
            {sortedPosts.map(post => {
              const isSaved = savedPostIds.includes(post.id);
              return (
                <div
                  key={post.id}
                  className="rounded-3xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800/90 shadow-sm hover:shadow-md transition-all p-5 sm:p-6"
                >
                  {/* Author meta row */}
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-600 to-indigo-600 text-white font-bold text-sm flex items-center justify-center">
                        {post.authorName.charAt(0)}
                      </div>
                      <div>
                        <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
                          <span className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">
                            {post.authorName.replace(/\s*\(مشرف.*?\)/, '')}
                          </span>
                          <ModeratorBadge 
                            authorId={post.authorId} 
                            authorName={post.authorName} 
                            isModerator={post.isModerator} 
                            moderatorTitle={post.moderatorTitle} 
                          />
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-sky-500/10 text-sky-500 border border-sky-500/20">
                            {t.roles[post.authorRole]}
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-400 font-mono">
                          {t.disciplines[post.discipline]} • {new Date(post.createdAt).toLocaleDateString('ar-EG')}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => onOpenReport({ id: post.id, type: 'post', title: post.title })}
                      className="text-slate-400 hover:text-rose-400 text-xs p-1"
                      title="إبلاغ عن محتوى"
                    >
                      •••
                    </button>
                  </div>

                  {/* Post Title & Content */}
                  <div 
                    onClick={() => onNavigate('post_detail', post.id)}
                    className="cursor-pointer group"
                  >
                    <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white group-hover:text-sky-500 transition mb-2">
                      {post.title}
                    </h3>
                    <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed line-clamp-3 mb-3">
                      {post.content}
                    </p>
                  </div>

                  {/* Attached Schematic / Image */}
                  {post.images && post.images.length > 0 && (
                    <div 
                      onClick={() => onNavigate('post_detail', post.id)}
                      className="mb-3 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 max-h-80 cursor-pointer"
                    >
                      <img 
                        src={post.images[0]} 
                        alt={post.title}
                        className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" 
                      />
                    </div>
                  )}

                  {/* Attached PDF Preview Link */}
                  {post.pdfUrl && (
                    <div className="mb-3 p-3 rounded-2xl bg-sky-500/5 border border-sky-500/20 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <FileText className="w-5 h-5 text-sky-500" />
                        <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                          {post.pdfTitle || 'مخطط هندسي مرفق.pdf'}
                        </span>
                      </div>
                      <button
                        onClick={() => onOpenPdfViewer({
                          id: post.id,
                          title: post.pdfTitle || post.title,
                          description: post.content,
                          discipline: post.discipline,
                          authorOrSource: post.authorName,
                          fileSize: '2.4 MB',
                          downloadsCount: 120
                        })}
                        className="px-3 py-1 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold cursor-pointer transition"
                      >
                        معاينة PDF
                      </button>
                    </div>
                  )}

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {post.tags.map(tag => (
                      <span
                        key={tag}
                        className="px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-[10px] font-medium"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>

                  {/* Action Buttons Row */}
                  <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800/80 text-xs text-slate-500 dark:text-slate-400">
                    <div className="flex items-center gap-4">
                      {/* Like */}
                      <button
                        onClick={() => toggleLikePost(post.id)}
                        className="flex items-center gap-1.5 hover:text-rose-500 transition cursor-pointer"
                      >
                        <Heart className="w-4 h-4 fill-current text-rose-500" />
                        <span className="font-bold">{post.likesCount}</span>
                      </button>

                      {/* Comments */}
                      <button
                        onClick={() => onNavigate('post_detail', post.id)}
                        className="flex items-center gap-1.5 hover:text-sky-500 transition cursor-pointer"
                      >
                        <MessageSquare className="w-4 h-4" />
                        <span className="font-bold">{post.commentsCount}</span>
                      </button>
                    </div>

                    <div className="flex items-center gap-3">
                      {/* Bookmark */}
                      <button
                        onClick={() => toggleSavePost(post.id)}
                        className={`p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer ${
                          isSaved ? 'text-amber-400' : ''
                        }`}
                        title="حفظ"
                      >
                        <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
                      </button>

                      {/* Share */}
                      <button
                        onClick={() => handleShare(post)}
                        className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
                        title="نسخ الرابط"
                      >
                        {copiedPostId === post.id ? (
                          <span className="text-[10px] text-emerald-400 font-bold">تم النسخ!</span>
                        ) : (
                          <Share2 className="w-4 h-4" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 1 Col: Engineering Widgets */}
        <div className="space-y-6">
          
          {/* Widget 1: Daily Engineering Quiz Challenge */}
          {quizzes.length > 0 && (
            <div className="rounded-3xl bg-gradient-to-br from-amber-500/15 via-slate-900 to-slate-900 border border-amber-500/30 p-5 shadow-lg relative overflow-hidden">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase mb-2">
                <HelpCircle className="w-4 h-4" />
                <span>{t.home.quickQuiz}</span>
              </div>
              <h3 className="text-sm font-bold text-white mb-2 leading-tight">
                {quizzes[0].title}
              </h3>
              <p className="text-xs text-slate-300 line-clamp-2 mb-4 leading-relaxed">
                {quizzes[0].description}
              </p>
              <div className="flex items-center justify-between text-xs text-slate-400 mb-4 font-mono">
                <span>⏱️ {quizzes[0].durationMinutes} {t.quizzes.duration}</span>
                <span>👥 {quizzes[0].participantsCount} مشارك</span>
              </div>
              <button
                onClick={() => onNavigate('quiz_player', quizzes[0].id)}
                className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs transition shadow-md shadow-amber-500/20 cursor-pointer text-center"
              >
                {t.quizzes.startChallenge} ←
              </button>
            </div>
          )}

          {/* Widget 2: Featured Engineering Projects */}
          <div className="rounded-3xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Cpu className="w-4 h-4 text-emerald-400" />
                <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                  {t.home.recentProjects}
                </h3>
              </div>
              <button
                onClick={() => onNavigate('projects')}
                className="text-xs text-sky-500 hover:underline"
              >
                {t.home.viewAll}
              </button>
            </div>

            <div className="space-y-3">
              {projects.slice(0, 2).map(proj => (
                <div
                  key={proj.id}
                  onClick={() => onNavigate('project_detail', proj.id)}
                  className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer border border-slate-200 dark:border-slate-700/60"
                >
                  <div className="flex items-center justify-between text-[10px] font-semibold text-emerald-400 mb-1">
                    <span>{t.disciplines[proj.discipline]}</span>
                    <span className="font-mono text-slate-400">♥ {proj.likesCount}</span>
                  </div>
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white line-clamp-1 mb-1">
                    {proj.title}
                  </h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2">
                    {proj.tagline}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Widget 3: Active Groups */}
          <div className="rounded-3xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-sky-400" />
                <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                  {t.home.activeGroups}
                </h3>
              </div>
              <button
                onClick={() => onNavigate('groups')}
                className="text-xs text-sky-500 hover:underline"
              >
                {t.home.viewAll}
              </button>
            </div>

            <div className="space-y-2">
              {groups.slice(0, 3).map(grp => {
                const isJoined = joinedGroupIds.includes(grp.id);
                return (
                  <div
                    key={grp.id}
                    className="flex items-center justify-between p-2.5 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800/60 transition"
                  >
                    <div 
                      onClick={() => onNavigate('group_detail', grp.id)}
                      className="flex items-center gap-2.5 cursor-pointer truncate"
                    >
                      <div className="w-8 h-8 rounded-lg bg-sky-500/10 text-sky-400 flex items-center justify-center font-bold text-xs shrink-0">
                        {grp.name.charAt(0)}
                      </div>
                      <div className="truncate">
                        <p className="text-xs font-bold text-slate-900 dark:text-white truncate">{grp.name}</p>
                        <p className="text-[10px] text-slate-400">{grp.memberCount} عضو</p>
                      </div>
                    </div>

                    <button
                      onClick={() => toggleJoinGroup(grp.id)}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border transition shrink-0 ${
                        isJoined
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                          : 'bg-sky-500 text-white border-sky-500 hover:bg-sky-400'
                      }`}
                    >
                      {isJoined ? 'منضم ✓' : 'انضمام'}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Widget 4: Recommended Engineering Courses */}
          {courses.length > 0 && (
            <div className="rounded-3xl bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 p-5 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <GraduationCap className="w-4 h-4 text-purple-400" />
                  <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                    {t.home.popularCourses}
                  </h3>
                </div>
                <button
                  onClick={() => onNavigate('courses')}
                  className="text-xs text-sky-500 hover:underline"
                >
                  {t.home.viewAll}
                </button>
              </div>

              <div 
                onClick={() => onNavigate('course_detail', courses[0].id)}
                className="group cursor-pointer rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800"
              >
                <div className="h-28 overflow-hidden">
                  <img 
                    src={courses[0].coverImage} 
                    alt={courses[0].title}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-300" 
                  />
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-800/80">
                  <span className="text-[10px] font-semibold text-purple-400 block mb-1">
                    {t.disciplines[courses[0].discipline]}
                  </span>
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white line-clamp-2 leading-snug">
                    {courses[0].title}
                  </h4>
                  <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400">
                    <span>{courses[0].instructorName}</span>
                    <span>★ {courses[0].rating} ({courses[0].enrolledCount})</span>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
