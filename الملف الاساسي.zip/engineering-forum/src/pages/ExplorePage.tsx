import React, { useState } from 'react';
import { 
  Compass, 
  Search, 
  Cpu, 
  MessageSquare, 
  BookOpen, 
  Users, 
  Sparkles, 
  ArrowLeft, 
  ArrowRight,
  TrendingUp,
  Tag
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { useData } from '../context/DataContext';
import { EngineeringDiscipline } from '../types';

interface ExplorePageProps {
  initialQuery?: string;
  onNavigate: (page: string, params?: any) => void;
}

export const ExplorePage: React.FC<ExplorePageProps> = ({ initialQuery = '', onNavigate }) => {
  const { t, isRTL } = useLanguage();
  const { posts, projects, groups, libraryResources } = useData();

  const [query, setQuery] = useState(initialQuery);
  const ArrowIcon = isRTL ? ArrowLeft : ArrowRight;

  const disciplines: { key: EngineeringDiscipline; label: string; icon: string; count: number }[] = [
    { key: 'electrical', label: t.disciplines.electrical, icon: '⚡', count: 48 },
    { key: 'electronics', label: t.disciplines.electronics, icon: '🔌', count: 39 },
    { key: 'automation', label: t.disciplines.automation, icon: '⚙️', count: 28 },
    { key: 'robotics_ai', label: t.disciplines.robotics_ai, icon: '🤖', count: 52 },
    { key: 'renewable_energy', label: t.disciplines.renewable_energy, icon: '☀️', count: 31 },
    { key: 'mechanical', label: t.disciplines.mechanical, icon: '🔩', count: 24 },
    { key: 'civil', label: t.disciplines.civil, icon: '🏗️', count: 19 },
    { key: 'computer_sci', label: t.disciplines.computer_sci, icon: '💻', count: 45 },
    { key: 'telecom', label: t.disciplines.telecom, icon: '📡', count: 18 },
  ];

  const matchedPosts = query ? posts.filter(p => p.title.toLowerCase().includes(query.toLowerCase()) || p.content.toLowerCase().includes(query.toLowerCase())) : [];
  const matchedProjects = query ? projects.filter(p => p.title.toLowerCase().includes(query.toLowerCase()) || p.tagline.toLowerCase().includes(query.toLowerCase())) : [];

  return (
    <div className="space-y-8 pb-20">
      
      {/* Search Header */}
      <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-r from-sky-950 via-[#0a162b] to-slate-900 border border-sky-500/20 shadow-xl text-center space-y-4">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-500/10 border border-sky-500/30 text-sky-400 text-xs font-semibold">
          <Compass className="w-4 h-4" />
          <span>استكشاف المحتوى الهندسي المفتوح</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-black text-white">
          ما الذي تريد اكتشافه أو تعلمه اليوم؟
        </h1>

        <div className="max-w-2xl mx-auto relative pt-2">
          <Search className={`absolute top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 ${isRTL ? 'right-4' : 'left-4'}`} />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث عن: Arduino, محركات كهربائية, ROS2, خلايا شمسية, PLC..."
            className={`w-full h-12 rounded-2xl bg-slate-900/90 border border-slate-700/80 text-xs sm:text-sm text-white placeholder-slate-400 focus:outline-none focus:border-sky-500 shadow-xl ${
              isRTL ? 'pr-12 pl-4' : 'pl-12 pr-4'
            }`}
          />
        </div>
      </div>

      {/* Query Search Results if any */}
      {query && (
        <div className="space-y-4">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
            نتائج البحث عن "{query}" ({matchedPosts.length + matchedProjects.length} عنصر)
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {matchedPosts.map(p => (
              <div 
                key={p.id}
                onClick={() => onNavigate('post_detail', p.id)}
                className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-sky-500 cursor-pointer space-y-1"
              >
                <span className="text-[10px] font-bold text-sky-400">مناقشة هندسية</span>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white">{p.title}</h4>
                <p className="text-[11px] text-slate-400 line-clamp-2">{p.content}</p>
              </div>
            ))}
            {matchedProjects.map(proj => (
              <div 
                key={proj.id}
                onClick={() => onNavigate('project_detail', proj.id)}
                className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500 cursor-pointer space-y-1"
              >
                <span className="text-[10px] font-bold text-emerald-400">مشروع وابتكار</span>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white">{proj.title}</h4>
                <p className="text-[11px] text-slate-400 line-clamp-2">{proj.tagline}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Disciplines Directory */}
      <div className="space-y-4">
        <h2 className="text-base font-bold text-slate-900 dark:text-white">
          تصفح حسب التخصصات الهندسية
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {disciplines.map(d => (
            <div
              key={d.key}
              onClick={() => onNavigate('posts', { discipline: d.key })}
              className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-sky-500/40 transition cursor-pointer flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <span className="text-3xl">{d.icon}</span>
                <div>
                  <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                    {d.label}
                  </h3>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {d.count} موضوع وبحث منشور
                  </span>
                </div>
              </div>
              <ArrowIcon className="w-4 h-4 text-slate-400" />
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
