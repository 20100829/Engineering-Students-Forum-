import React, { useState } from 'react';
import { 
  BookOpen, 
  Search, 
  Download, 
  Eye, 
  Bookmark, 
  Filter, 
  ShieldCheck, 
  FileText, 
  Globe, 
  GraduationCap,
  Sparkles,
  ShieldAlert
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { useData } from '../context/DataContext';
import { EngineeringDiscipline, LibraryResource, Language } from '../types';

interface LibraryPageProps {
  onOpenPdfViewer: (resource: LibraryResource) => void;
  onOpenReport: (item: any) => void;
}

export const LibraryPage: React.FC<LibraryPageProps> = ({
  onOpenPdfViewer,
  onOpenReport
}) => {
  const { t, isRTL } = useLanguage();
  const { 
    libraryResources, 
    savedResourceIds, 
    toggleSaveResource, 
    incrementResourceDownload 
  } = useData();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDiscipline, setSelectedDiscipline] = useState<EngineeringDiscipline | 'all'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedLang, setSelectedLang] = useState<Language | 'all'>('all');

  const filteredResources = libraryResources.filter(res => {
    const matchDiscipline = selectedDiscipline === 'all' || res.discipline === selectedDiscipline;
    const matchCat = selectedCategory === 'all' || res.category === selectedCategory;
    const matchLang = selectedLang === 'all' || res.language === selectedLang;
    const matchQuery = !searchQuery ||
      res.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      res.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      res.authorOrSource.toLowerCase().includes(searchQuery.toLowerCase());
    return matchDiscipline && matchCat && matchLang && matchQuery;
  });

  const handleDownload = (res: LibraryResource) => {
    incrementResourceDownload(res.id);
    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(`[مرجع]: ${res.title}\nالمؤلف: ${res.authorOrSource}`));
    element.setAttribute('download', `${res.title.slice(0, 30)}.txt`);
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="space-y-6 pb-20">
      
      {/* Header Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-slate-900 via-[#0d1627] to-blue-950 border border-sky-500/20 shadow-xl relative overflow-hidden">
        <div className="relative z-10 max-w-2xl space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-500/10 border border-sky-500/30 text-sky-400 text-xs font-semibold">
            <BookOpen className="w-3.5 h-3.5" />
            <span>المستودع العلمي الرقمي</span>
          </div>
          <h1 className="text-xl sm:text-3xl font-black text-white">
            {t.library.title}
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            {t.library.subtitle}
          </p>
          <div className="flex items-center gap-2 pt-2 text-[11px] text-emerald-400 font-medium">
            <ShieldCheck className="w-4 h-4" />
            <span>{t.library.copyrightNotice}</span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          
          {/* Search query */}
          <div className="relative md:col-span-1">
            <Search className={`absolute top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 ${isRTL ? 'right-3' : 'left-3'}`} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.library.search}
              className={`w-full h-10 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-sky-500 ${
                isRTL ? 'pr-9 pl-3' : 'pl-9 pr-3'
              }`}
            />
          </div>

          {/* Discipline */}
          <div>
            <select
              value={selectedDiscipline}
              onChange={(e) => setSelectedDiscipline(e.target.value as any)}
              className="w-full h-10 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 px-3 text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:border-sky-500"
            >
              <option value="all">جميع التخصصات</option>
              {Object.entries(t.disciplines).map(([k, name]) => (
                <option key={k} value={k}>{name}</option>
              ))}
            </select>
          </div>

          {/* Category */}
          <div>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full h-10 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 px-3 text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:border-sky-500"
            >
              <option value="all">{t.library.categoryAll}</option>
              <option value="book">{t.library.categoryBook}</option>
              <option value="lecture">{t.library.categoryLecture}</option>
              <option value="summary">{t.library.categorySummary}</option>
              <option value="datasheet">{t.library.categoryDatasheet}</option>
            </select>
          </div>

          {/* Language */}
          <div>
            <select
              value={selectedLang}
              onChange={(e) => setSelectedLang(e.target.value as any)}
              className="w-full h-10 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 px-3 text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:border-sky-500"
            >
              <option value="all">كل اللغات (العربية / En / Fr)</option>
              <option value="ar">العربية</option>
              <option value="en">English</option>
              <option value="fr">Français</option>
            </select>
          </div>
        </div>
      </div>

      {/* Resources Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filteredResources.map(resource => {
          const isSaved = savedResourceIds.includes(resource.id);

          return (
            <div
              key={resource.id}
              className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-sm hover:border-sky-500/40 transition-all flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-sky-500/10 text-sky-500 border border-sky-500/20">
                      {t.disciplines[resource.discipline]}
                    </span>
                    <span className="text-[10px] font-mono text-slate-400 uppercase">
                      {resource.language} • {resource.fileSize}
                    </span>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => toggleSaveResource(resource.id)}
                      className={`p-1.5 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 ${
                        isSaved ? 'text-amber-400 bg-amber-400/10 border-amber-400/30' : 'text-slate-400'
                      }`}
                      title="حفظ في المفضلة"
                    >
                      <Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-current' : ''}`} />
                    </button>
                    <button
                      onClick={() => onOpenReport({ id: resource.id, type: 'resource', title: resource.title })}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400"
                      title={t.library.reportCopyright}
                    >
                      <ShieldAlert className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div>
                  <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white leading-snug">
                    {resource.title}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-3 leading-relaxed">
                    {resource.description}
                  </p>
                </div>

                <div className="text-[11px] text-slate-400 space-y-0.5 pt-1">
                  <p>المصدر / المؤلف: <strong className="text-slate-700 dark:text-slate-300">{resource.authorOrSource}</strong></p>
                  <p>المستوى الموصى به: <span className="text-slate-700 dark:text-slate-300">{resource.educationLevel}</span></p>
                </div>
              </div>

              {/* Bottom Actions Row */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span className="text-[10px] font-mono text-slate-400">
                  📥 {resource.downloadsCount} تنزيل • 👁️ {resource.viewsCount} مشاهدة
                </span>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onOpenPdfViewer(resource)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-sky-500/10 hover:text-sky-400 text-slate-700 dark:text-slate-300 text-xs font-semibold transition cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>{t.library.readOnline}</span>
                  </button>

                  <button
                    onClick={() => handleDownload(resource)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold shadow-md shadow-sky-600/30 transition cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>{t.library.download}</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
