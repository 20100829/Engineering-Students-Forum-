import React from 'react';
import { Bell, CheckCheck, Trash2, Heart, MessageSquare, Cpu, Award } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { useData } from '../context/DataContext';

export const NotificationsPage: React.FC = () => {
  const { t } = useLanguage();
  const { notifications, markNotificationAsRead, markAllNotificationsAsRead } = useData();

  const getIcon = (type: string) => {
    switch (type) {
      case 'like': return <Heart className="w-4 h-4 text-rose-500" />;
      case 'comment': return <MessageSquare className="w-4 h-4 text-sky-500" />;
      case 'project_invite': return <Cpu className="w-4 h-4 text-emerald-500" />;
      case 'quiz_result': return <Award className="w-4 h-4 text-amber-500" />;
      default: return <Bell className="w-4 h-4 text-purple-500" />;
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-20">
      <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
            {t.nav.notifications}
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            تنبيهات التفاعل مع مشاريعك، منشوراتك والتحديات الهندسية.
          </p>
        </div>

        <button
          onClick={markAllNotificationsAsRead}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-semibold text-sky-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
        >
          <CheckCheck className="w-4 h-4" />
          <span>تحديد الكل كمقروء</span>
        </button>
      </div>

      <div className="space-y-3">
        {notifications.length === 0 ? (
          <div className="p-12 text-center rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-400">
            لا توجد إشعارات جديدة في صندوقك حالياً.
          </div>
        ) : (
          notifications.map(notif => (
            <div
              key={notif.id}
              onClick={() => markNotificationAsRead(notif.id)}
              className={`p-4 rounded-2xl border transition flex items-start gap-3 cursor-pointer ${
                notif.isRead
                  ? 'bg-white dark:bg-slate-900/60 border-slate-200 dark:border-slate-800 text-slate-400'
                  : 'bg-sky-500/5 dark:bg-sky-500/10 border-sky-500/30 text-slate-900 dark:text-white font-medium shadow-sm'
              }`}
            >
              <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 shrink-0">
                {getIcon(notif.type)}
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs sm:text-sm font-bold">{notif.title}</h4>
                  <span className="text-[10px] text-slate-400 font-mono">{notif.createdAt}</span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                  {notif.body}
                </p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
