import React, { useState } from 'react';
import { 
  ArrowLeft, 
  ArrowRight, 
  Heart, 
  Users, 
  ShieldCheck, 
  PlusCircle, 
  CheckCircle2, 
  Circle, 
  FileText, 
  Cpu, 
  Calendar, 
  Share2,
  Sparkles,
  MessageSquare
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';

interface ProjectDetailPageProps {
  projectId: string;
  onNavigate: (page: string, params?: any) => void;
  onOpenPdfViewer: (resource: any) => void;
}

export const ProjectDetailPage: React.FC<ProjectDetailPageProps> = ({
  projectId,
  onNavigate,
  onOpenPdfViewer
}) => {
  const { t, isRTL } = useLanguage();
  const { currentUser, isExpert, canTeach } = useAuth();
  const { 
    projects, 
    toggleLikeProject, 
    addProjectUpdate, 
    toggleTaskStatus, 
    assignSupervisor 
  } = useData();

  const project = projects.find(p => p.id === projectId) || projects[0];
  const ArrowIcon = isRTL ? ArrowRight : ArrowLeft;

  const [activeTab, setActiveTab] = useState<'overview' | 'bom' | 'schematics' | 'tasks' | 'updates'>('overview');
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [updateTitle, setUpdateTitle] = useState('');
  const [updateContent, setUpdateContent] = useState('');

  if (!project) return null;

  const handlePostUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!updateTitle.trim() || !updateContent.trim()) return;
    addProjectUpdate(project.id, updateTitle.trim(), updateContent.trim());
    setUpdateTitle('');
    setUpdateContent('');
    setShowUpdateModal(false);
  };

  const handleVolunteerSupervisor = () => {
    if (!currentUser) return;
    assignSupervisor(project.id, {
      id: currentUser.id,
      name: currentUser.displayName,
      role: currentUser.role,
      verified: true
    });
    alert('تم تسجيل إشرافك الأكاديمي المعتمد على هذا المشروع بنجاح!');
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-20">
      
      {/* Back button */}
      <button
        onClick={() => onNavigate('projects')}
        className="flex items-center gap-2 text-xs font-bold text-slate-500 hover:text-emerald-400 transition cursor-pointer"
      >
        <ArrowIcon className="w-4 h-4" />
        <span>العودة لقائمة المشاريع والابتكارات</span>
      </button>

      {/* Main Project Hero */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
        
        {/* Banner with Cover Image */}
        <div className="h-56 sm:h-72 relative">
          <img
            src={project.images[0] || 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=800&auto=format&fit=crop&q=80'}
            alt={project.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/50 to-transparent" />
          
          <div className="absolute bottom-6 right-6 left-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div className="space-y-1.5 max-w-2xl">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-500 text-white shadow-md">
                  المرحلة: {project.stage}
                </span>
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-slate-900/80 text-sky-400 border border-slate-700">
                  {t.disciplines[project.discipline]}
                </span>
              </div>
              <h1 className="text-xl sm:text-3xl font-black text-white">{project.title}</h1>
              <p className="text-xs text-slate-300 font-mono">
                مؤسس المشروع: {project.creatorName} • تاريخ التوثيق: {project.createdAt}
              </p>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => toggleLikeProject(project.id)}
                className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold backdrop-blur-md transition cursor-pointer"
              >
                <Heart className="w-4 h-4 text-rose-500 fill-current" />
                <span>{project.likesCount} إعجاب</span>
              </button>
              
              <button
                onClick={() => {
                  navigator.clipboard?.writeText(window.location.href);
                  alert('تم نسخ رابط المشروع للمشاركة');
                }}
                className="p-2.5 rounded-2xl bg-white/10 hover:bg-white/20 text-white transition cursor-pointer"
              >
                <Share2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Supervisor Status Bar */}
        <div className="px-6 py-3.5 bg-slate-50 dark:bg-slate-800/60 border-t border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <div>
              <span className="text-slate-500 dark:text-slate-400">{t.projects.supervisor}: </span>
              {project.scientificSupervisor ? (
                <strong className="text-slate-900 dark:text-white font-bold">
                  {project.scientificSupervisor.name} ({t.roles[project.scientificSupervisor.role]})
                </strong>
              ) : (
                <span className="text-amber-400 italic font-medium">{t.projects.supervisorNone}</span>
              )}
            </div>
          </div>

          {!project.scientificSupervisor && (canTeach || isExpert) && (
            <button
              onClick={handleVolunteerSupervisor}
              className="px-3.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition shadow-sm cursor-pointer self-start sm:self-auto"
            >
              تقديم الإشراف العلمي كأستاذ/خبير
            </button>
          )}
        </div>

        {/* Workspace Tab Navigation */}
        <div className="flex items-center px-6 border-b border-slate-100 dark:border-slate-800 text-xs font-bold gap-6 overflow-x-auto">
          {[
            { id: 'overview', label: 'نظرة عامة والوصف' },
            { id: 'bom', label: `المكونات (${project.componentsList.length})` },
            { id: 'schematics', label: 'المخططات الهندسية' },
            { id: 'tasks', label: `المهام (${project.tasks.length})` },
            { id: 'updates', label: `سجل التحديثات (${project.updates.length})` },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`py-4 border-b-2 whitespace-nowrap transition cursor-pointer ${
                activeTab === tab.id
                  ? 'border-emerald-500 text-emerald-500 font-black'
                  : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* TAB 1: OVERVIEW & TEAM */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-4">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                وصف المشروع والأهداف التقنية
              </h3>
              <div className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">
                {project.description}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            {/* Team Members List */}
            <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-sky-400" />
                  <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                    {t.projects.teamMembers} ({project.teamMembers.length})
                  </h3>
                </div>
              </div>

              <div className="space-y-3">
                {project.teamMembers.map(m => (
                  <div key={m.userId} className="flex items-center gap-3 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                    <div className="w-8 h-8 rounded-lg bg-sky-600 text-white font-bold text-xs flex items-center justify-center">
                      {m.name.charAt(0)}
                    </div>
                    <div>
                      <p className="text-xs font-bold text-slate-900 dark:text-white">{m.name}</p>
                      <span className="text-[10px] text-slate-400">{m.roleInTeam}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: BOM (COMPONENTS LIST) */}
      {activeTab === 'bom' && (
        <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                قائمة المكونات والقطع الإلكترونية (Bill of Materials - BOM)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                تحديد دقيق للمواصفات والكميات لتسهيل تكرار النموذج الأولي.
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-700 text-slate-400 font-semibold">
                  <th className="py-3 px-4">اسم المكوّن / القطعة</th>
                  <th className="py-3 px-4 text-center">الكمية</th>
                  <th className="py-3 px-4">المواصفات الفنية المعتمدة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {project.componentsList.map((comp, idx) => (
                  <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="py-3 px-4 font-bold text-slate-900 dark:text-white">{comp.name}</td>
                    <td className="py-3 px-4 text-center font-mono text-emerald-400 font-bold">{comp.quantity}</td>
                    <td className="py-3 px-4 text-slate-500 dark:text-slate-300 font-mono text-[11px]">{comp.specs}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: SCHEMATICS & DIAGRAMS */}
      {activeTab === 'schematics' && (
        <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              {t.projects.circuitDiagram}
            </h3>
            {project.schematicsUrl && (
              <button
                onClick={() => onOpenPdfViewer({
                  id: project.id,
                  title: `مخططات توصيل: ${project.title}`,
                  description: project.description,
                  discipline: project.discipline,
                  authorOrSource: project.creatorName,
                  fileSize: '4.8 MB',
                  downloadsCount: 88
                })}
                className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition shadow-sm"
              >
                معاينة المخطط الكامل في قارئ PDF
              </button>
            )}
          </div>

          <div className="p-6 rounded-2xl bg-slate-950 font-mono text-xs text-sky-300 border border-slate-800 overflow-x-auto leading-relaxed">
{`// ARCHITECTURE DIAGRAM FOR [${project.title.toUpperCase()}]
// ===============================================================
+-----------------------+           +-----------------------+
|  PV Array (Monocryst) | --------> | VFD Solar Inverter    |
|  6 x 450W = 2700Wp    |           | 3-Phase 380V Output   |
+-----------------------+           +-----------------------+
            |                                   |
            v                                   v
+-----------------------+           +-----------------------+
| Submersible Pump      | <-------- | Sensor Node (ESP32)   |
| 3-Phase 2.2kW Head 45m|           | LoRa SX1278 868MHz    |
+-----------------------+           +-----------------------+`}
          </div>
        </div>
      )}

      {/* TAB 4: TASKS & ROADMAP */}
      {activeTab === 'tasks' && (
        <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider pb-3 border-b border-slate-100 dark:border-slate-800">
            {t.projects.tasks}
          </h3>

          <div className="space-y-3">
            {project.tasks.map(task => (
              <div
                key={task.id}
                onClick={() => toggleTaskStatus(project.id, task.id)}
                className={`p-4 rounded-2xl border transition cursor-pointer flex items-center justify-between ${
                  task.isCompleted
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                    : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700/60 text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  {task.isCompleted ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  ) : (
                    <Circle className="w-5 h-5 text-slate-400" />
                  )}
                  <div>
                    <span className={`text-xs font-semibold ${task.isCompleted ? 'line-through text-slate-400' : ''}`}>
                      {task.title}
                    </span>
                    {task.assignedTo && (
                      <span className="block text-[10px] text-slate-400 font-mono mt-0.5">
                        المكلف بالإنجاز: {task.assignedTo}
                      </span>
                    )}
                  </div>
                </div>

                <span className="text-[10px] font-bold px-2 py-0.5 rounded font-mono">
                  {task.isCompleted ? 'منجز ✓' : 'قيد التنفيذ'}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: CHANGELOG & UPDATES */}
      {activeTab === 'updates' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              {t.projects.updates}
            </h3>

            <button
              onClick={() => setShowUpdateModal(true)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition shadow-md shadow-emerald-600/30"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>{t.projects.addUpdate}</span>
            </button>
          </div>

          <div className="space-y-4">
            {project.updates.map(upd => (
              <div
                key={upd.id}
                className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2 shadow-sm"
              >
                <div className="flex items-center justify-between text-xs">
                  <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                    {upd.title}
                  </h4>
                  <span className="text-slate-400 font-mono text-[11px]">{upd.date}</span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  {upd.content}
                </p>
              </div>
            ))}
          </div>

          {/* New Update Modal */}
          {showUpdateModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md">
              <div className="w-full max-w-lg rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-2xl">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">نشر تحديث هندسي جديد للمشروع</h3>
                <form onSubmit={handlePostUpdate} className="space-y-3">
                  <input
                    type="text"
                    value={updateTitle}
                    onChange={(e) => setUpdateTitle(e.target.value)}
                    placeholder="عنوان التحديث (مثال: نجاح اختبار المحرك على الحمل الأقصى)..."
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-900 dark:text-white"
                    required
                  />
                  <textarea
                    rows={4}
                    value={updateContent}
                    onChange={(e) => setUpdateContent(e.target.value)}
                    placeholder="تفاصيل التحديث، القياسات، التعديلات في المخطط..."
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white resize-none"
                    required
                  />
                  <div className="flex items-center justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setShowUpdateModal(false)}
                      className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white"
                    >
                      إلغاء
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md shadow-emerald-600/30"
                    >
                      نشر التحديث
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

    </div>
  );
};
