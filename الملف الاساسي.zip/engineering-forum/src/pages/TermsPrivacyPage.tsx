import React from 'react';
import { ShieldCheck, Lock, Award, BookOpen, AlertTriangle } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';

export const TermsPrivacyPage: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-20 text-slate-800 dark:text-slate-200">
      
      <div className="pb-4 border-b border-slate-200 dark:border-slate-800">
        <h1 className="text-xl sm:text-3xl font-black text-slate-900 dark:text-white">
          ميثاق الخصوصية وسياسة حماية المجتمع الهندسي
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Engineering Students Forum - Terms, Privacy & Minor Protection Charter
        </p>
      </div>

      {/* 1. Minor Safety & Child Protection */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4 shadow-sm">
        <div className="flex items-center gap-2.5 text-emerald-500 font-bold text-base">
          <ShieldCheck className="w-6 h-6" />
          <h2>1. حماية التلاميذ والقاصرين والبيانات الشخصية</h2>
        </div>
        <div className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 space-y-3 leading-relaxed">
          <p>
            تستقبل منصة "منتدى تلاميذ وطلاب الهندسة" تلاميذ الثانويات المهتمين بالعلوم التقنية والكهربائية. انطلاقاً من مسؤوليتنا الأخلاقية والقانونية:
          </p>
          <ul className="list-disc list-inside space-y-1.5 pr-2">
            <li>يُحظر منعاً باتاً طلب أو نشر أرقام الهواتف أو العناوين السكنية أو الحسابات الخاصة للتلاميذ علناً.</li>
            <li>معلومات المؤسسة التعليمية والبريد الإلكتروني محجوبة تلقائياً ولا تظهر إلا باختيار المستخدم.</li>
            <li>تخضع الرسائل والمناقشات لمرشحات ذكية ترصد أي محاولة لتداول البيانات الشخصية الحساسة.</li>
            <li>يملك أولياء الأمور والتلاميذ الحق في طلب حذف حساباتهم وبياناتهم فوراً عبر الإعدادات.</li>
          </ul>
        </div>
      </div>

      {/* 2. Scientific & Engineering Conduct */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4 shadow-sm">
        <div className="flex items-center gap-2.5 text-sky-500 font-bold text-base">
          <Award className="w-6 h-6" />
          <h2>2. ميثاق النزاهة العلمية وحقوق الملكية الفكرية</h2>
        </div>
        <div className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 space-y-3 leading-relaxed">
          <p>
            تلتزم المنصة بتعزيز البحث والابتكار الهندسي الشريف:
          </p>
          <ul className="list-disc list-inside space-y-1.5 pr-2">
            <li>جميع المراجع والكتب المنشورة في المكتبة مخصصة للأغراض التعليمية والأكاديمية غير الربحية.</li>
            <li>يجب عزو المخططات الكهربائية والبرمجيات المفتوحة إلى مصادرها ومطوريها الأصليين.</li>
            <li>توفّر المنصة زر إبلاغ فوري عن أي مادة تنتهك حقوق المؤلفين لمعالجتها في غضون 24 ساعة.</li>
          </ul>
        </div>
      </div>

      {/* 3. Electrical & Safety Caution */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4 shadow-sm">
        <div className="flex items-center gap-2.5 text-amber-500 font-bold text-base">
          <AlertTriangle className="w-6 h-6" />
          <h2>3. السلامة الكهربائية والمخبرية</h2>
        </div>
        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
          تتضمن العديد من المشاريع التعامل مع الجهود العالية (High Voltage)، والبطاريات، والمحركات الصناعية. يُنصح التلاميذ دائماً بعدم تنفيذ أي تجارب تتعدى 24V دون إشراف أستاذ أو مهندس مؤهل داخل مختبر مجهز بوسائل الحماية الفردية.
        </p>
      </div>

    </div>
  );
};
