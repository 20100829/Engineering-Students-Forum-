import React, { useState } from 'react';
import { 
  ArrowLeft, 
  ArrowRight, 
  Plus, 
  Trash2, 
  Cpu, 
  FileText, 
  CheckCircle2, 
  Sparkles,
  Layers
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { EngineeringDiscipline, ProjectComponent, ProjectTask } from '../types';

interface CreateProjectPageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const CreateProjectPage: React.FC<CreateProjectPageProps> = ({ onNavigate }) => {
  const { t, isRTL } = useLanguage();
  const { currentUser } = useAuth();
  const { createProject } = useData();

  const ArrowIcon = isRTL ? ArrowRight : ArrowLeft;

  const [title, setTitle] = useState('');
  const [tagline, setTagline] = useState('');
  const [description, setDescription] = useState('');
  const [discipline, setDiscipline] = useState<EngineeringDiscipline>(currentUser?.discipline || 'electrical');
  const [stage, setStage] = useState<'idea' | 'schematics' | 'prototype' | 'testing' | 'completed'>('idea');
  const [imageUrl, setImageUrl] = useState('');
  
  // Components BOM
  const [components, setComponents] = useState<ProjectComponent[]>([
    { name: '', quantity: 1, specs: '' }
  ]);

  // Tasks
  const [tasks, setTasks] = useState<string[]>([
    'إعداد المخطط الكهربائي والتوصيلي الأولي',
    'اختبار الحساسات على لوحة التجارب Breadboard'
  ]);
  const [taskInput, setTaskInput] = useState('');

  if (!currentUser) {
    return (
      <div className="p-12 text-center">
        <p className="text-slate-400">يرجى تسجيل الدخول لإنشاء وتوثيق مشروع هندسي جديد.</p>
        <button onClick={() => onNavigate('login')} className="mt-4 text-sky-400 font-bold underline">
          تسجيل الدخول
        </button>
      </div>
    );
  }

  const handleAddComponent = () => {
    setComponents([...components, { name: '', quantity: 1, specs: '' }]);
  };

  const handleRemoveComponent = (idx: number) => {
    setComponents(components.filter((_, i) => i !== idx));
  };

  const handleComponentChange = (idx: number, field: keyof ProjectComponent, val: any) => {
    const updated = [...components];
    updated[idx] = { ...updated[idx], [field]: val };
    setComponents(updated);
  };

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (taskInput.trim()) {
      setTasks([...tasks, taskInput.trim()]);
      setTaskInput('');
    }
  };

  const handleRemoveTask = (idx: number) => {
    setTasks(tasks.filter((_, i) => i !== idx));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !tagline.trim() || !description.trim()) return;

    const validComponents = components.filter(c => c.name.trim().length > 0);
    const validTasks: ProjectTask[] = tasks.map((tText, i) => ({
      id: `task_${Date.now()}_${i}`,
      title: tText,
      isCompleted: false
    }));

    createProject({
      title: title.trim(),
      tagline: tagline.trim(),
      description: description.trim(),
      discipline,
      stage,
      creatorId: currentUser.id,
      creatorName: currentUser.displayName,
      images: imageUrl.trim() ? [imageUrl.trim()] : ['https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=800&auto=format&fit=crop&q=80'],
      componentsList: validComponents.length > 0 ? validComponents : [
        { name: 'متحكم دقيق', quantity: 1, specs: 'Microcontroller Unit' }
      ],
      tasks: validTasks,
      teamMembers: [
        { userId: currentUser.id, name: currentUser.displayName, roleInTeam: 'قائد ومؤسس المشروع' }
      ]
    });

    onNavigate('projects');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20">
      
      {/* Back button */}
      <button
        onClick={() => onNavigate('projects')}
        className="flex items-center gap-2 text-xs font-bold text-slate-500 hover:text-white transition cursor-pointer"
      >
        <ArrowIcon className="w-4 h-4" />
        <span>إلغاء والعودة للمشاريع</span>
      </button>

      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-xl space-y-8">
        
        {/* Header */}
        <div className="pb-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
              {t.projects.createNew}
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              وثّق اختراعك أو نموذجك الأولي، وشارك قائمة المكونات، وادعُ زملاءك وأساتذتك للتعاون.
            </p>
          </div>
          <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
            <Cpu className="w-6 h-6" />
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          
          {/* Title & Tagline */}
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                اسم المشروع أو الابتكار <span className="text-emerald-400">*</span>
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="مثال: نظام تحكم هجين في ألواح الطاقة الشمسية المتتبعة للشمس (Solar Tracker)"
                className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white font-bold focus:outline-none focus:border-emerald-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                شعار / نبذة مختصرة عن المشروع (Tagline) <span className="text-emerald-400">*</span>
              </label>
              <input
                type="text"
                value={tagline}
                onChange={(e) => setTagline(e.target.value)}
                placeholder="وصف تسويقي وهندسي مكثف في سطر واحد..."
                className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                required
              />
            </div>
          </div>

          {/* Discipline and Stage */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                التخصص الهندسي
              </label>
              <select
                value={discipline}
                onChange={(e) => setDiscipline(e.target.value as any)}
                className="w-full h-11 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-3 text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
              >
                {Object.entries(t.disciplines).map(([k, name]) => (
                  <option key={k} value={k}>{name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t.projects.stage}
              </label>
              <select
                value={stage}
                onChange={(e) => setStage(e.target.value as any)}
                className="w-full h-11 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-3 text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
              >
                <option value="idea">{t.projects.stageIdea}</option>
                <option value="schematics">{t.projects.stageSchematics}</option>
                <option value="prototype">{t.projects.stagePrototype}</option>
                <option value="testing">{t.projects.stageTesting}</option>
                <option value="completed">{t.projects.stageCompleted}</option>
              </select>
            </div>
          </div>

          {/* Detailed Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              الوصف الهندسي، مبدأ العمل والأهداف التقنية <span className="text-emerald-400">*</span>
            </label>
            <textarea
              rows={5}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="اشرح المشكلة الهندسية التي يعالجها الابتكار، والتقنيات والمتحكمات المستخدمة..."
              className="w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500 resize-none leading-relaxed"
              required
            />
          </div>

          {/* Cover image url */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              رابط صورة النموذج الأولي أو المخطط (اختياري)
            </label>
            <input
              type="url"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              placeholder="https://example.com/project-prototype.jpg"
              className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
            />
          </div>

          {/* Bill of Materials (BOM) Editor */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                  قائمة المكونات والقطع (Bill of Materials)
                </h3>
                <p className="text-[11px] text-slate-400">حدد القطع والمواصفات لتمكين الزملاء من مراجعة التصميم.</p>
              </div>
              <button
                type="button"
                onClick={handleAddComponent}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-xs font-semibold hover:bg-emerald-500/20"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>إضافة قطعة</span>
              </button>
            </div>

            <div className="space-y-2">
              {components.map((comp, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <input
                    type="text"
                    value={comp.name}
                    onChange={(e) => handleComponentChange(idx, 'name', e.target.value)}
                    placeholder="اسم القطعة (مثال: Arduino Nano)"
                    className="flex-1 px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                  />
                  <input
                    type="number"
                    min="1"
                    value={comp.quantity}
                    onChange={(e) => handleComponentChange(idx, 'quantity', parseInt(e.target.value) || 1)}
                    className="w-20 px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-center text-slate-900 dark:text-white font-mono"
                  />
                  <input
                    type="text"
                    value={comp.specs}
                    onChange={(e) => handleComponentChange(idx, 'specs', e.target.value)}
                    placeholder="المواصفات (مثال: ATmega328P, 5V, 16MHz)"
                    className="flex-1 px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                  />
                  {components.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveComponent(idx)}
                      className="p-2 text-slate-400 hover:text-rose-500"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Submit Actions */}
          <div className="flex items-center justify-end gap-3 pt-6 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => onNavigate('projects')}
              className="px-5 py-2.5 rounded-xl text-xs font-semibold text-slate-400 hover:text-white"
            >
              {t.common.cancel}
            </button>
            <button
              type="submit"
              className="flex items-center gap-2 px-7 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 text-white font-bold text-xs sm:text-sm shadow-lg shadow-emerald-600/30 transition hover:scale-[1.02] cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>نشر وتوثيق المشروع في المعرض</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
