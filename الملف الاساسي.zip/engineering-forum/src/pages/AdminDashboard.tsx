import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Users, 
  MessageSquare, 
  Cpu, 
  GraduationCap, 
  BookOpen, 
  ShieldAlert, 
  CheckCircle2, 
  XCircle, 
  Settings, 
  Activity,
  Layers,
  Lock
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { UserRole } from '../types';

export const AdminDashboard: React.FC = () => {
  const { t } = useLanguage();
  const { currentUser, isAdmin } = useAuth();
  const { 
    posts, 
    projects, 
    courses, 
    libraryResources, 
    groups, 
    reports, 
    approvePost, 
    rejectPost, 
    resolveReport 
  } = useData();

  const [activeTab, setActiveTab] = useState<'overview' | 'moderation' | 'users' | 'audit'>('overview');

  // Hard security gate
  if (!currentUser || !isAdmin) {
    return (
      <div className="max-w-md mx-auto p-8 rounded-3xl bg-slate-900 border border-rose-500/30 text-center space-y-4 my-16 shadow-2xl">
        <Lock className="w-12 h-12 text-rose-500 mx-auto" />
        <h2 className="text-lg font-bold text-white">منطقة إدارية مقيدة</h2>
        <p className="text-xs text-slate-400 leading-relaxed">
          يتطلب هذا القسم صلاحيات الإدارة العليا للوصول. يتم تدقيق وتسجيل كافة محاولات الدخول غير المصرح بها أمنياً.
        </p>
      </div>
    );
  }

  const pendingReports = reports.filter(r => r.status === 'pending');
  const pendingPosts = posts.filter(p => !p.isApproved);

  const stats = [
    { label: t.admin.totalUsers, value: '1,540', icon: Users, color: 'text-sky-400' },
    { label: t.admin.totalPosts, value: posts.length, icon: MessageSquare, color: 'text-blue-400' },
    { label: t.admin.totalProjects, value: projects.length, icon: Cpu, color: 'text-emerald-400' },
    { label: t.admin.totalCourses, value: courses.length, icon: GraduationCap, color: 'text-purple-400' },
    { label: 'المكتبة والكتب', value: libraryResources.length, icon: BookOpen, color: 'text-amber-400' },
    { label: t.admin.activeReports, value: pendingReports.length, icon: ShieldAlert, color: 'text-rose-400' },
  ];

  return (
    <div className="space-y-6 pb-20">
      
      {/* Admin Header */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-slate-900 via-[#101b33] to-slate-950 border border-sky-500/30 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-400 text-xs font-bold">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>المدير العام ومنشئ التطبيق: قداري محمود طه ياسين</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-white">{t.admin.title}</h1>
          <p className="text-xs text-slate-400">{t.admin.subtitle}</p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-slate-900 border border-slate-800 text-xs font-bold">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-3 py-2 rounded-xl transition ${activeTab === 'overview' ? 'bg-sky-500 text-white' : 'text-slate-400 hover:text-white'}`}
          >
            {t.admin.tabOverview}
          </button>
          <button
            onClick={() => setActiveTab('moderation')}
            className={`px-3 py-2 rounded-xl transition relative ${activeTab === 'moderation' ? 'bg-sky-500 text-white' : 'text-slate-400 hover:text-white'}`}
          >
            <span>{t.admin.tabModeration}</span>
            {pendingReports.length > 0 && (
              <span className="w-2 h-2 rounded-full bg-rose-500 absolute top-1.5 right-1" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('users')}
            className={`px-3 py-2 rounded-xl transition ${activeTab === 'users' ? 'bg-sky-500 text-white' : 'text-slate-400 hover:text-white'}`}
          >
            {t.admin.tabUsers}
          </button>
          <button
            onClick={() => setActiveTab('audit')}
            className={`px-3 py-2 rounded-xl transition ${activeTab === 'audit' ? 'bg-sky-500 text-white' : 'text-slate-400 hover:text-white'}`}
          >
            {t.admin.tabAudit}
          </button>
        </div>
      </div>

      {/* TAB 1: OVERVIEW & STATS */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {stats.map((s, i) => {
              const Icon = s.icon;
              return (
                <div key={i} className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm text-center">
                  <div className={`w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto mb-2 ${s.color}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="text-xl font-black text-slate-900 dark:text-white font-mono">{s.value}</div>
                  <span className="text-[11px] text-slate-400 font-medium">{s.label}</span>
                </div>
              );
            })}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Quick moderation queue card */}
            <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
              <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center justify-between">
                <span>البلاغات المعلقة قيد التحقيق ({pendingReports.length})</span>
                <ShieldAlert className="w-4 h-4 text-rose-500" />
              </h3>

              {pendingReports.length === 0 ? (
                <p className="text-xs text-slate-400 py-6 text-center">لا توجد بلاغات نشطة حالياً. المجتمع الهندسي في حالة ممتازة!</p>
              ) : (
                <div className="space-y-2">
                  {pendingReports.map(rep => (
                    <div key={rep.id} className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs flex items-center justify-between">
                      <div className="truncate pr-2">
                        <span className="font-bold text-slate-900 dark:text-white block truncate">{rep.reason}</span>
                        <span className="text-[10px] text-slate-400 font-mono">المبلغ: {rep.reporterName}</span>
                      </div>
                      <div className="flex gap-1.5 shrink-0">
                        <button
                          onClick={() => resolveReport(rep.id, 'resolved')}
                          className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white text-[10px] font-bold"
                        >
                          معالجة
                        </button>
                        <button
                          onClick={() => resolveReport(rep.id, 'dismissed')}
                          className="px-2.5 py-1 rounded-lg bg-slate-700 text-slate-300 text-[10px]"
                        >
                          تجاهل
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Disciplines oversight */}
            <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
              <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                التخصصات الهندسية المعتمدة
              </h3>
              <div className="grid grid-cols-2 gap-2 text-xs">
                {Object.entries(t.disciplines).map(([k, name]) => (
                  <div key={k} className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 flex items-center justify-between">
                    <span className="font-semibold text-slate-800 dark:text-slate-200 text-[11px] truncate">{name}</span>
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: MODERATION */}
      {activeTab === 'moderation' && (
        <div className="space-y-4">
          <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              سجل البلاغات وإجراءات السلامة
            </h3>
            {reports.length === 0 ? (
              <p className="text-xs text-slate-400 py-6 text-center">لا توجد تقارير مسجلة في السجل.</p>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {reports.map(r => (
                  <div key={r.id} className="py-3.5 flex items-center justify-between gap-4 text-xs">
                    <div>
                      <p className="font-bold text-slate-900 dark:text-white">{r.reason}</p>
                      <p className="text-[10px] text-slate-400 font-mono">
                        النوع: {r.targetType} • المعرّف: {r.targetId} • تاريخ: {new Date(r.createdAt).toLocaleDateString('ar-EG')}
                      </p>
                    </div>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      r.status === 'pending' ? 'bg-amber-500/10 text-amber-400' : 'bg-emerald-500/10 text-emerald-400'
                    }`}>
                      {r.status === 'pending' ? 'معلق' : 'تم البت فيه'}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: USERS & ROLES */}
      {activeTab === 'users' && (
        <div className="space-y-6">
          <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              صلاحيات هيئة الإدارة والمشرفين المعتمدين
            </h3>
            <div className="space-y-2 text-xs">
              {[
                { 
                  name: 'قداري محمود طه ياسين', 
                  title: 'منشئ التطبيق ومؤسس المنصة • المسؤول والمدير العام', 
                  dept: 'الإدارة العامة والإشراف الشامل والقرارات التنفيذية',
                  badge: 'مدير أعلى (Admin)'
                },
                { 
                  name: 'فضيلي فاتح', 
                  title: 'مشرف البرمجة والهندسة البرمجية', 
                  dept: 'مراجعة الأكواد، النظم المدمجة، ومشاريع الإعلام الآلي والذكاء الاصطناعي',
                  badge: 'مشرف قسم (Supervisor)'
                },
                { 
                  name: 'عبيدي صلاح الدين', 
                  title: 'مشرف المخططات والهندسات', 
                  dept: 'تدقيق ومصادقة المخططات الكهربائية، دوائر PCB، ونمذجة الـ CAD',
                  badge: 'مشرف قسم (Supervisor)'
                },
              ].map((staff, idx) => (
                <div key={idx} className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between">
                  <div>
                    <strong className="text-slate-900 dark:text-white font-bold text-sm block">{staff.name}</strong>
                    <span className="text-sky-500 font-semibold text-[11px] block">{staff.title}</span>
                    <span className="text-[11px] text-slate-400">{staff.dept}</span>
                  </div>
                  <span className="text-[10px] font-mono text-amber-400 font-bold px-2.5 py-1 rounded-xl bg-amber-500/10 border border-amber-500/30 shrink-0">
                    {staff.badge}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              صلاحيات مستويات العضويات في المنتدى
            </h3>
            <div className="space-y-2 text-xs">
              {[
                { role: 'تلميذ ثانوي', perm: 'النشر بعد المراجعة • قراءة وتنزيل المراجع • المشاركة في التحديات والفرق' },
                { role: 'طالب جامعي', perm: 'النشر المباشر الموثق • إنشاء المشاريع الهندسية • الانضمام للفرق ومجموعات النقاش' },
                { role: 'أستاذ / معلم', perm: 'الإشراف الأكاديمي المعتمد • نشر الدورات والامتحانات • مراجعة مشاريع الطلاب' },
                { role: 'مهندس / خبير', perm: 'الإشراف العلمي الميداني • تقييم النماذج والمخططات • تقديم الاستشارات' },
              ].map((item, idx) => (
                <div key={idx} className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800 flex items-center justify-between">
                  <div>
                    <strong className="text-slate-900 dark:text-white font-bold block">{item.role}</strong>
                    <span className="text-[11px] text-slate-400">{item.perm}</span>
                  </div>
                  <span className="text-[10px] font-mono text-emerald-400 font-bold px-2 py-0.5 rounded bg-emerald-500/10">
                    نشط ومفعّل
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: AUDIT LOG */}
      {activeTab === 'audit' && (
        <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 space-y-3 font-mono text-xs">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-sans mb-3">
            سجل التدقيق الإداري والأمني (Security & Audit Log)
          </h3>
          <div className="space-y-2 text-slate-400 text-[11px]">
            <p className="p-2.5 rounded-xl bg-slate-950 text-slate-300">
              [2026-10-30 05:40:12 UTC] AUTH_CHECK: SuperAdmin session validated from secure environment.
            </p>
            <p className="p-2.5 rounded-xl bg-slate-950 text-slate-300">
              [2026-10-29 18:22:04 UTC] POLICY_AUDIT: Minor privacy filters engaged. 0 leak attempts detected.
            </p>
            <p className="p-2.5 rounded-xl bg-slate-950 text-slate-300">
              [2026-10-28 11:15:30 UTC] MODERATION_GATE: Hybrid content approval active. 4 items approved.
            </p>
          </div>
        </div>
      )}

    </div>
  );
};
