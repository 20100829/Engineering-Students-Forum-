import React, { useState } from 'react';
import { 
  Mail, 
  Send, 
  ShieldAlert, 
  ShieldCheck, 
  UserX, 
  Paperclip, 
  Info,
  CheckCircle2,
  Lock,
  Plus
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';

interface MessagesPageProps {
  onOpenReport: (item: any) => void;
}

export const MessagesPage: React.FC<MessagesPageProps> = ({ onOpenReport }) => {
  const { t } = useLanguage();
  const { currentUser } = useAuth();
  const { conversations, users, sendMessage, createConversation } = useData();

  const [activeConvId, setActiveConvId] = useState(conversations[0]?.id || '');
  const [inputText, setInputText] = useState('');
  const [safetyWarning, setSafetyWarning] = useState<string | null>(null);
  const [showNewChat, setShowNewChat] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState('');

  const activeConv = conversations.find(c => c.id === activeConvId) || conversations[0];

  const handleCreateConversation = () => {
    const user = users.find(candidate => candidate.id === selectedUserId);
    if (!user) return;
    const conversationId = createConversation(user);
    if (conversationId) {
      setActiveConvId(conversationId);
      setShowNewChat(false);
      setSelectedUserId('');
    }
  };

  // Minor Privacy Filter: Detect phone numbers (e.g. 05xx, 06xx, 07xx or regex digits)
  const phonePattern = /(?:\+?\d{1,3}[-.\s]?)?\(?\d{2,4}\)?[-.\s]?\d{3,4}[-.\s]?\d{3,4}/;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !currentUser || !activeConv) return;

    if (phonePattern.test(inputText)) {
      setSafetyWarning('تنبيه أمني صارم: يُمنع تبادل أو طلب أرقام الهواتف أو الحسابات الشخصية لحماية خصوصية وسلامة الطلبة والتلاميذ.');
      return;
    }

    setSafetyWarning(null);
    sendMessage(activeConv.id, inputText.trim(), { id: currentUser.id, name: currentUser.displayName });
    setInputText('');
  };

  return (
    <div className="max-w-5xl mx-auto space-y-4 pb-20">
      
      {/* Safety Notice Banner */}
      <div className="p-4 rounded-2xl bg-sky-500/10 border border-sky-500/20 text-sky-400 text-xs flex items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>نسخة تجريبية: تُحفظ الرسائل على هذا المتصفح فقط، ومرشح الأرقام ليس بديلًا عن نظام حماية على الخادم.</span>
        </div>
        <span className="text-[10px] font-mono bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded">غير مشفّر طرفًا لطرف</span>
      </div>

      {/* Main Messaging Layout */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm grid grid-cols-1 md:grid-cols-3 h-[600px]">
        
        {/* Left Col: Conversations List */}
        <div className="border-l border-slate-200 dark:border-slate-800 flex flex-col">
          <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <h2 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              {t.nav.messages} ({conversations.length})
            </h2>
            <button onClick={() => setShowNewChat(value => !value)} className="text-sky-500 hover:text-sky-400 p-1" title="محادثة جديدة" aria-label="محادثة جديدة">
              <Plus className="w-4 h-4" />
            </button>
          </div>

          {showNewChat && (
            <div className="p-3 border-b border-slate-200 dark:border-slate-800 space-y-2">
              <label className="text-[11px] text-slate-500">ابدأ محادثة مع عضو موثّق</label>
              <select value={selectedUserId} onChange={event => setSelectedUserId(event.target.value)} className="w-full rounded-lg p-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                <option value="">اختر عضوًا</option>
                {users.filter(user => user.id !== currentUser?.id).map(user => <option key={user.id} value={user.id}>{user.displayName}</option>)}
              </select>
              <button disabled={!selectedUserId} onClick={handleCreateConversation} className="w-full rounded-lg bg-sky-600 disabled:opacity-40 text-white text-xs py-2">بدء المحادثة</button>
              {users.length === 0 && <p className="text-[10px] text-amber-500">لا يوجد أعضاء موثّقون متاحون بعد.</p>}
            </div>
          )}

          <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/60">
            {conversations.map(conv => (
              <div
                key={conv.id}
                onClick={() => { setActiveConvId(conv.id); setSafetyWarning(null); }}
                className={`p-3.5 flex items-center gap-3 transition cursor-pointer ${
                  conv.id === activeConvId
                    ? 'bg-sky-500/10 dark:bg-sky-500/15'
                    : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
                }`}
              >
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-600 to-indigo-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
                  {conv.participantName.charAt(0)}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {conv.participantName}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">{conv.lastMessageTime}</span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                    {conv.lastMessage}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right 2 Cols: Active Chat Workspace */}
        {activeConv ? (
          <div className="md:col-span-2 flex flex-col justify-between h-full bg-slate-50/50 dark:bg-[#070b14]/50">
            
            {/* Chat header */}
            <div className="p-4 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-sky-600 text-white font-bold text-xs flex items-center justify-center">
                  {activeConv.participantName.charAt(0)}
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-900 dark:text-white">
                    {activeConv.participantName}
                  </h3>
                  <span className="text-[10px] text-sky-400 font-mono">
                    {t.roles[activeConv.participantRole]}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => onOpenReport({ id: activeConv.id, type: 'message', title: `محادثة مع ${activeConv.participantName}` })}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500"
                  title="إبلاغ عن محادثة"
                >
                  <ShieldAlert className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Messages bubble timeline */}
            <div className="flex-1 p-4 overflow-y-auto space-y-3">
              {activeConv.messages.map(msg => {
                const isMe = msg.senderId === currentUser?.id || msg.senderName === 'أنا' || msg.senderName === currentUser?.displayName;
                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${isMe ? 'items-start' : 'items-end'}`}
                  >
                    <div
                      className={`max-w-[80%] p-3.5 rounded-2xl text-xs leading-relaxed ${
                        isMe
                          ? 'bg-sky-600 text-white rounded-br-none shadow-md shadow-sky-600/20'
                          : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 rounded-bl-none border border-slate-200 dark:border-slate-700 shadow-sm'
                      }`}
                    >
                      <p>{msg.text}</p>
                    </div>
                    <span className="text-[9px] text-slate-400 font-mono mt-1 px-1">
                      {msg.timestamp}
                    </span>
                  </div>
                );
              })}

              {safetyWarning && (
                <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs">
                  {safetyWarning}
                </div>
              )}
            </div>

            {/* Input message form */}
            <form onSubmit={handleSend} className="p-3 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="اكتب رسالتك العلمية أو استفسارك الهندسي هنا..."
                className="flex-1 h-10 px-4 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-sky-500"
              />
              <button
                type="submit"
                className="w-10 h-10 rounded-xl bg-sky-600 hover:bg-sky-500 text-white flex items-center justify-center transition cursor-pointer shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        ) : (
          <div className="md:col-span-2 flex items-center justify-center text-xs text-slate-400">
            اختر محادثة لبدء المراسلة.
          </div>
        )}
      </div>
    </div>
  );
};
