import React, { useState } from 'react';
import { 
  Cpu, 
  PlusCircle, 
  Search, 
  Heart, 
  Users, 
  CheckCircle2, 
  ArrowLeft, 
  ArrowRight,
  ShieldCheck,
  Zap,
  Tag
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { useData } from '../context/DataContext';
import { EngineeringDiscipline } from '../types';

interface ProjectsPageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const ProjectsPage: React.FC<ProjectsPageProps> = ({ onNavigate }) => {
  const { t, isRTL } = useLanguage();
  const { projects, toggleLikeProject } = useData();

  const [selectedDiscipline, setSelectedDiscipline] = useState<EngineeringDiscipline | 'all'>('all');
  const [selectedStage, setSelectedStage] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const ArrowIcon = isRTL ? ArrowLeft : ArrowRight;

  const stageLabels: Record<string, string> = {
    idea: t.projects.stageIdea,
    schematics: t.projects.stageSchematics,
    prototype: t.projects.stagePrototype,
    testing: t.projects.stageTesting,
    completed: t.projects.stageCompleted,
  };

  const filteredProjects = projects.filter(p => {
    const matchDiscipline = selectedDiscipline === 'all' || p.discipline === selectedDiscipline;
    const matchStage = selectedStage === 'all' || p.stage === selectedStage;
    const matchQuery = !searchQuery ||
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.tagline.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.creatorName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchDiscipline && matchStage && matchQuery;
  });

  return (
    <div className="space-y-6 pb-20">
      
      {/* Header Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-emerald-950/80 via-slate-900 to-sky-950 border border-emerald-500/20 shadow-xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold">
              <Cpu className="w-3.5 h-3.5" />
              <span>حاضنة الابتكار والبحث التطبيقي</span>
            </div>
            <h1 className="text-xl sm:text-3xl font-black text-white">
              {t.projects.title}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {t.projects.subtitle}
            </p>
          </div>

          <button
            onClick={() => onNavigate('create_project')}
            className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 text-white font-bold text-xs sm:text-sm shadow-lg shadow-emerald-600/30 transition hover:scale-[1.02] cursor-pointer shrink-0 self-start md:self-auto"
          >
            <PlusCircle className="w-4 h-4" />
            <span>{t.projects.createNew}</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          
          {/* Search */}
          <div className="relative">
            <Search className={`absolute top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 ${isRTL ? 'right-3' : 'left-3'}`} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث عن نموذج، ابتكار، أو فريق..."
              className={`w-full h-10 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-emerald-500 ${
                isRTL ? 'pr-9 pl-3' : 'pl-9 pr-3'
              }`}
            />
          </div>

          {/* Discipline */}
          <div>
            <select
              value={selectedDiscipline}
              onChange={(e) => setSelectedDiscipline(e.target.value as any)}
              className="w-full h-10 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 px-3 text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
            >
              <option value="all">جميع التخصصات الهندسية</option>
              {Object.entries(t.disciplines).map(([k, name]) => (
                <option key={k} value={k}>{name}</option>
              ))}
            </select>
          </div>

          {/* Stage */}
          <div>
            <select
              value={selectedStage}
              onChange={(e) => setSelectedStage(e.target.value)}
              className="w-full h-10 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 px-3 text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
            >
              <option value="all">كافة مراحل الإنجاز</option>
              <option value="idea">{t.projects.stageIdea}</option>
              <option value="schematics">{t.projects.stageSchematics}</option>
              <option value="prototype">{t.projects.stagePrototype}</option>
              <option value="testing">{t.projects.stageTesting}</option>
              <option value="completed">{t.projects.stageCompleted}</option>
            </select>
          </div>
        </div>
      </div>

      {/* Projects Showcase Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredProjects.map(proj => {
          const completedTasks = proj.tasks.filter(t => t.isCompleted).length;
          const tasksPercent = proj.tasks.length > 0 ? Math.round((completedTasks / proj.tasks.length) * 100) : 0;

          return (
            <div
              key={proj.id}
              className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm hover:shadow-xl transition-all flex flex-col justify-between"
            >
              <div>
                {/* Images Preview */}
                <div 
                  onClick={() => onNavigate('project_detail', proj.id)}
                  className="h-48 relative overflow-hidden cursor-pointer group"
                >
                  <img
                    src={proj.images[0] || 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=800&auto=format&fit=crop&q=80'}
                    alt={proj.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-transparent to-transparent" />
                  
                  <div className="absolute top-3 right-3 flex items-center gap-1.5">
                    <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-md bg-emerald-600 text-white shadow-md">
                      {stageLabels[proj.stage] || proj.stage}
                    </span>
                    <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-md bg-slate-900/80 text-sky-400 border border-slate-700">
                      {t.disciplines[proj.discipline]}
                    </span>
                  </div>

                  {proj.scientificSupervisor && (
                    <div className="absolute bottom-3 right-3 flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-purple-950/90 border border-purple-500/30 text-purple-300 text-[10px] font-semibold backdrop-blur-sm">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                      <span>مشرف أكاديمي: {proj.scientificSupervisor.name}</span>
                    </div>
                  )}
                </div>

                {/* Details */}
                <div className="p-6 space-y-3">
                  <div 
                    onClick={() => onNavigate('project_detail', proj.id)}
                    className="cursor-pointer"
                  >
                    <h3 className="text-base font-bold text-slate-900 dark:text-white hover:text-emerald-400 transition leading-snug">
                      {proj.title}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                      {proj.tagline}
                    </p>
                  </div>

                  {/* Tasks Progress Bar */}
                  <div className="space-y-1 pt-1">
                    <div className="flex items-center justify-between text-[10px] font-mono text-slate-400">
                      <span>إنجاز المهام ({completedTasks}/{proj.tasks.length})</span>
                      <span className="text-emerald-400 font-bold">{tasksPercent}%</span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-emerald-500 to-sky-500 rounded-full transition-all duration-500"
                        style={{ width: `${tasksPercent}%` }}
                      />
                    </div>
                  </div>

                  {/* Team Avatars */}
                  <div className="flex items-center justify-between pt-2 text-xs text-slate-400">
                    <div className="flex items-center gap-1">
                      <Users className="w-3.5 h-3.5 text-sky-400" />
                      <span>فريق من {proj.teamMembers.length} أعضاء</span>
                    </div>
                    <span className="font-mono text-[11px]">مؤسس: {proj.creatorName}</span>
                  </div>
                </div>
              </div>

              {/* Bottom Actions */}
              <div className="p-6 pt-0 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between mt-2">
                <button
                  onClick={() => toggleLikeProject(proj.id)}
                  className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-rose-500 transition cursor-pointer"
                >
                  <Heart className="w-4 h-4 text-rose-500 fill-current" />
                  <span className="font-bold">{proj.likesCount} إعجاب</span>
                </button>

                <button
                  onClick={() => onNavigate('project_detail', proj.id)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-emerald-500 hover:text-white text-slate-800 dark:text-slate-200 text-xs font-bold transition cursor-pointer"
                >
                  <span>عرض تفاصيل المشروع</span>
                  <ArrowIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
