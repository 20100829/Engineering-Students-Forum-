import React, { useState } from 'react';
import { Users, Search, PlusCircle, Check, ArrowRight, ArrowLeft } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { useData } from '../context/DataContext';
import { EngineeringGroup } from '../types';

interface GroupsPageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const GroupsPage: React.FC<GroupsPageProps> = ({ onNavigate }) => {
  const { t, currentLang, isRTL } = useLanguage();
  const { groups, joinedGroupIds, toggleJoinGroup } = useData();

  const [searchQuery, setSearchQuery] = useState('');
  const ArrowIcon = isRTL ? ArrowLeft : ArrowRight;

  const filteredGroups = groups.filter(g => 
    !searchQuery ||
    g.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    g.nameEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
    g.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6 pb-16">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
            {t.nav.groups}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            مجموعات تخصصية تجمع الطلبة والأساتذة والخبراء حسب الشعبة الهندسية.
          </p>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className={`absolute top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 ${isRTL ? 'right-3' : 'left-3'}`} />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث عن مجموعة تخصصية..."
            className={`w-full h-10 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-sky-500 ${
              isRTL ? 'pr-9 pl-3' : 'pl-9 pr-3'
            }`}
          />
        </div>
      </div>

      {/* Groups Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredGroups.map(group => {
          const isJoined = joinedGroupIds.includes(group.id);
          const groupTitle = currentLang === 'ar' ? group.name : currentLang === 'fr' ? group.nameFr : group.nameEn;

          return (
            <div
              key={group.id}
              className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Cover Banner */}
                <div 
                  onClick={() => onNavigate('group_detail', group.id)}
                  className="h-36 overflow-hidden relative cursor-pointer group"
                >
                  <img
                    src={group.coverImage}
                    alt={group.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
                  <span className="absolute bottom-3 right-3 text-[10px] font-bold px-2 py-0.5 rounded-md bg-sky-500 text-white shadow-md">
                    {t.disciplines[group.discipline]}
                  </span>
                </div>

                {/* Content */}
                <div className="p-5 space-y-3">
                  <div 
                    onClick={() => onNavigate('group_detail', group.id)}
                    className="cursor-pointer"
                  >
                    <h3 className="text-base font-bold text-slate-900 dark:text-white hover:text-sky-500 transition line-clamp-1">
                      {groupTitle}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                      {group.description}
                    </p>
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1">
                    {group.tags.slice(0, 3).map(tag => (
                      <span
                        key={tag}
                        className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-[10px]"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Bottom Actions Row */}
              <div className="p-5 pt-0 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between mt-2">
                <div className="flex items-center gap-1.5 text-xs text-slate-400 font-mono">
                  <Users className="w-3.5 h-3.5 text-sky-400" />
                  <span>{group.memberCount} عضو</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => toggleJoinGroup(group.id)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer border ${
                      isJoined
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                        : 'bg-sky-600 hover:bg-sky-500 text-white border-sky-600 shadow-sm'
                    }`}
                  >
                    {isJoined ? 'منضم ✓' : 'انضمام'}
                  </button>
                  <button
                    onClick={() => onNavigate('group_detail', group.id)}
                    className="p-1.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-400 hover:text-white"
                  >
                    <ArrowIcon className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
