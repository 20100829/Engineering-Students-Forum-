import React from 'react';
import { 
  ShieldCheck, 
  Award, 
  Crown, 
  Mail, 
  Cpu, 
  Zap, 
  Users, 
  GraduationCap, 
  Sparkles, 
  MessageSquare, 
  CheckCircle2, 
  ArrowLeft, 
  ArrowRight,
  BookOpen
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { Logo } from '../components/common/Logo';
import { ModeratorBadge } from '../components/common/ModeratorBadge';

interface StaffLeadershipPageProps {
  onNavigate: (page: string, params?: any) => void;
}

export const StaffLeadershipPage: React.FC<StaffLeadershipPageProps> = ({ onNavigate }) => {
  const { t, isRTL } = useLanguage();
  const { currentUser } = useAuth();
  const ArrowIcon = isRTL ? ArrowLeft : ArrowRight;

  const supervisors = [
    {
      name: 'فضيلي فاتح',
      title: 'مشرف البرمجة والهندسة البرمجية',
      department: 'قسم البرمجيات، هندسة الأنظمة المدمجة، والخوارزميات',
      discipline: 'computer_sci',
      avatar: 'ف',
      bio: 'الإشراف على المشاريع البرمجية الهندسية، مراجعة الأكواد مفتوحة المصدر، لغات C/C++ وبايثون، وتأطير مسابقات البرمجة وتطوير الأنظمة الذكية.',
      badge: 'مشرف البرمجة والهندسة البرمجية',
      email: 'fedili.fateh@engineering-forum.org'
    },
    {
      name: 'عبيدي صلاح الدين',
      title: 'مشرف المخططات والهندسات',
      department: 'قسم المخططات الهندسية، الدارات الإلكترونية، وتصاميم PCB و CAD',
      discipline: 'electrical',
      avatar: 'ع',
      bio: 'تدقيق ومصادقة المخططات الكهربائية والتوصيلية، مراجعة تصاميم اللوحات المطبوعة PCB، والتحقق من المعايير القياسية للمشاريع الهندسية.',
      badge: 'مشرف المخططات والهندسات',
      email: 'abaidi.salaheddine@engineering-forum.org'
    },
    {
      name: 'د. كريم بن منصور',
      title: 'أستاذ محاضر وباحث في التحكم الصناعي',
      department: 'مشرف قسم الأتمتة الصناعية والتحكم الآلي',
      discipline: 'automation',
      avatar: 'ك',
      bio: 'إشراف أكاديمي على مشاريع التخرج، مراجعة مناهج لغة السلم Ladder والـ SCADA، وتأطير المسابقات الوطنية.',
      badge: 'إشراف أكاديمي معتمد',
      email: 'karim.prof@polytech.edu'
    },
    {
      name: 'م. رشيد السليماني',
      title: 'مهندس دولة استشاري أول',
      department: 'مشرف قسم الهندسة الكهربائية والطاقات المتجددة',
      discipline: 'renewable_energy',
      avatar: 'ر',
      bio: 'تقييم دراسات الجدوى الفنية، مراجعة مخططات المحولات الكهروضوئية والشبكات الذكية، وتوجيه الطلاب ميدانياً.',
      badge: 'خبير صناعي معتمد',
      email: 'rachid.power@energy-systems.com'
    },
    {
      name: 'م. سارة بن علي',
      title: 'باحثة في هندسة الأنظمة الذكية',
      department: 'مشرفة قسم الروبوتات والذكاء الاصطناعي',
      discipline: 'robotics_ai',
      avatar: 'س',
      bio: 'تنسيق فرق بناء الروبوتات الذاتية، مراجعة حزم ROS2 و SLAM، وتنظيم ورش العمل لطلاب الجامعات.',
      badge: 'مشرفة روبوتيك وذكاء اصطناعي',
      email: 'sara.eng@univ.edu'
    },
    {
      name: 'أ. أنس العلمي',
      title: 'مختص الإلكترونيات والأنظمة المدمجة',
      department: 'مشرف قسم نوادي الثانويات والمخترعين الصغار',
      discipline: 'electronics',
      avatar: 'أ',
      bio: 'دعم ومتابعة تلاميذ الثانويات، تدريب المبتدئين على دوائر الـ NE555 والأردوينو، وضمان بيئة آمنة للتلاميذ.',
      badge: 'مشرف نوادي الثانويات',
      email: 'anas.elec@school.edu'
    }
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-24">
      
      {/* Top Header */}
      <div className="text-center space-y-3 pt-2">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold backdrop-blur-md">
          <Crown className="w-4 h-4 text-amber-400" />
          <span>الهيكل الإداري والإشرافي الرسمي للمنتدى</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-black text-slate-900 dark:text-white">
          المسؤولون والمشرفون على المنصة
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 max-w-2xl mx-auto leading-relaxed">
          هيئة متكاملة من المهندسين والأساتذة الأكاديميين تحت قيادة إدارة المنصة لضمان جودة المحتوى الهندسي، وسلامة التلاميذ والطلبة.
        </p>
      </div>

      {/* GRAND FOUNDER & GENERAL MANAGER CARD */}
      <div className="relative rounded-3xl bg-gradient-to-br from-slate-900 via-[#0b172a] to-blue-950 border-2 border-amber-500/40 p-6 sm:p-10 shadow-2xl overflow-hidden group">
        
        {/* Ambient Lights & Circuit Pattern */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute inset-0 bg-grid-pattern opacity-30 pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-center lg:items-start gap-8 text-right">
          
          {/* Avatar and Badges */}
          <div className="flex flex-col items-center shrink-0 space-y-3">
            <div className="relative">
              <div className="w-28 h-28 sm:w-36 sm:h-36 rounded-3xl bg-gradient-to-tr from-amber-500 via-sky-600 to-indigo-700 p-1 shadow-2xl flex items-center justify-center">
                <div className="w-full h-full rounded-[22px] bg-slate-950 flex flex-col items-center justify-center text-white">
                  <span className="text-3xl sm:text-4xl font-black tracking-tight font-serif text-transparent bg-clip-text bg-gradient-to-tr from-amber-300 via-white to-sky-300">
                    ق.م
                  </span>
                  <span className="text-[10px] text-amber-400 font-mono mt-1 font-bold">FOUNDER</span>
                </div>
              </div>
              <div className="absolute -top-2 -right-2 p-2 rounded-2xl bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/30">
                <Crown className="w-5 h-5" />
              </div>
            </div>

            <div className="text-center space-y-1">
              <span className="inline-block px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40 text-[11px] font-bold">
                منشئ ومؤسس التطبيق
              </span>
              <span className="block px-3 py-0.5 rounded-full bg-sky-500/20 text-sky-300 border border-sky-500/40 text-[10px] font-semibold">
                المسؤول والمدير العام
              </span>
            </div>
          </div>

          {/* Leader Info and Statement */}
          <div className="flex-1 space-y-4 text-center lg:text-right">
            <div>
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 mb-1">
                <h2 className="text-2xl sm:text-3xl font-black text-white">
                  قداري محمود طه ياسين
                </h2>
                <span className="flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold">
                  <ShieldCheck className="w-4 h-4" />
                  <span>موثّق رسمياً</span>
                </span>
              </div>
              <p className="text-xs sm:text-sm font-semibold text-amber-400 font-mono">
                Kaddari Mahmoud Taha Yassine • Founder & Executive Director
              </p>
            </div>

            {/* Word from the Founder */}
            <div className="p-5 rounded-2xl bg-slate-950/70 border border-slate-800 text-xs sm:text-sm text-slate-300 leading-relaxed space-y-2 text-justify">
              <div className="flex items-center gap-2 text-sky-400 font-bold text-xs uppercase tracking-wider mb-1">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>رسالة منشئ ومؤسس التطبيق والمسؤول العام:</span>
              </div>
              <p>
                «أرحب بجميع زملائي وأبنائي من تلاميذ الثانويات وطلاب المعاهد والجامعات، وأساتذتنا الأفاضل ومهندسينا الخبراء. صممت هذه المنصة لتكون البيت الهندسي الجامع لكل التخصصات العلمية والتقنية، نتبادل فيها المعرفة الحقيقية، نبتكر النماذج الأولية، ونعمل معاً بروح الفريق لصناعة مستقبل تقني مشرف. نتعهد دائماً بحماية خصوصية أبنائنا القاصرين، وتوفير بيئة تعليمية محفزة خالية من المعوقات.»
              </p>
            </div>

            {/* Authority and Roles */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs pt-1">
              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-slate-300 flex items-center gap-2">
                <Cpu className="w-4 h-4 text-sky-400 shrink-0" />
                <span>هندسة المنصة والبنية البرمجية</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-slate-300 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>حماية الخصوصية وميثاق القاصرين</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-slate-300 flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-400 shrink-0" />
                <span>الاعتماد الإداري والإشراف العام</span>
              </div>
            </div>

            {/* Contact / Actions */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 pt-3 border-t border-slate-800">
              <button
                onClick={() => onNavigate('messages')}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/20 transition cursor-pointer"
              >
                <Mail className="w-4 h-4" />
                <span>التواصل المباشر مع المدير العام</span>
              </button>

              <button
                onClick={() => onNavigate('terms')}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 transition"
              >
                <BookOpen className="w-4 h-4 text-sky-400" />
                <span>ميثاق الإدارة والنزاهة الهندسية</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* DEPARTMENT SUPERVISORS SECTION */}
      <div className="space-y-6 pt-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-slate-800">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Users className="w-6 h-6 text-sky-500" />
              <span>مشرفو الأقسام والتخصصات الهندسية</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              أساتذة ومهندسون معتمدون مكلفون بالإشراف الأكاديمي، مراجعة المشاريع والرد على استفسارات الأعضاء.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {supervisors.map((sup, idx) => (
            <div
              key={idx}
              className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-sm hover:shadow-xl transition-all space-y-4 flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-sky-600 to-indigo-600 text-white font-black text-base flex items-center justify-center shrink-0">
                      {sup.avatar}
                    </div>
                    <div>
                      <div className="flex flex-wrap items-center gap-1.5">
                        <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                          {sup.name}
                        </h3>
                        <ModeratorBadge authorName={sup.name} size="xs" />
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">
                        {sup.title}
                      </p>
                    </div>
                  </div>

                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-purple-500/10 text-purple-400 border border-purple-500/20 shrink-0">
                    {sup.badge}
                  </span>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
                  <span className="text-[10px] font-bold text-sky-500 block mb-1">
                    {sup.department}
                  </span>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {sup.bio}
                  </p>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-[11px] text-slate-400 font-mono truncate">
                  {sup.email}
                </span>

                <button
                  onClick={() => onNavigate('messages')}
                  className="px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold shadow-sm transition"
                >
                  طلب استشارة
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ADMINISTRATIVE STRUCTURE AND POWERS */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4 shadow-sm">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>صلاحيات ومسؤوليات هيئة الإدارة والإشراف</span>
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 space-y-1.5 border border-slate-200 dark:border-slate-700/60">
            <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-amber-400" />
              <span>1. الإدارة العامة وتأسيس المنصة</span>
            </h4>
            <p>
              السيد <strong>قداري محمود طه ياسين</strong> يمتلك الصلاحية التنفيذية الكاملة لتوجيه سياسات المنتدى، تطوير بنيته البرمجية، تعيين المشرفين، وحماية المنظومة التعليمية.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 space-y-1.5 border border-slate-200 dark:border-slate-700/60">
            <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-sky-400" />
              <span>2. إشراف البرمجة وهندسة البرمجيات</span>
            </h4>
            <p>
              الأستاذ <strong>فضيلي فاتح</strong> مكلف بمراجعة المشاريع البرمجية، التدقيق الأمني للأكواد، وتأطير نوادي الخوارزميات والأنظمة المدمجة.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 space-y-1.5 border border-slate-200 dark:border-slate-700/60">
            <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>3. إشراف المخططات والهندسات</span>
            </h4>
            <p>
              الأستاذ <strong>عبيدي صلاح الدين</strong> مكلف بتدقيق ومصادقة المخططات الكهربائية والإلكترونية ومسارات PCB لضمان سلامة التنفيذ المخبري.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 space-y-1.5 border border-slate-200 dark:border-slate-700/60">
            <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-purple-400" />
              <span>4. الإشراف الأكاديمي وسلامة القاصرين</span>
            </h4>
            <p>
              مراقبة مستمرة لمنع تداول أرقام الهواتف أو البيانات الحساسة للتلاميذ، والتعامل الفوري مع أي بلاغ للمحافظة على بيئة تعليمية آمنة.
            </p>
          </div>
        </div>
      </div>

    </div>
  );
};
