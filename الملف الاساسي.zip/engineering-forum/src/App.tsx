import React, { useState, useEffect } from 'react';
import { LanguageProvider, useLanguage } from './i18n/LanguageContext';
import { ThemeProvider } from './context/ThemeContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { DataProvider } from './context/DataContext';

import { Header } from './components/common/Header';
import { Sidebar } from './components/common/Sidebar';
import { MobileNav } from './components/common/MobileNav';

import { CreatePostModal } from './components/modals/CreatePostModal';
import { PdfViewerModal } from './components/modals/PdfViewerModal';
import { ReportModal } from './components/modals/ReportModal';

import { WelcomeLanding } from './pages/WelcomeLanding';
import { AuthPages } from './pages/AuthPages';
import { HomeFeed } from './pages/HomeFeed';
import { ExplorePage } from './pages/ExplorePage';
import { PostsPage } from './pages/PostsPage';
import { PostDetailPage } from './pages/PostDetailPage';
import { GroupsPage } from './pages/GroupsPage';
import { GroupDetailPage } from './pages/GroupDetailPage';
import { LibraryPage } from './pages/LibraryPage';
import { CoursesPage } from './pages/CoursesPage';
import { CourseDetailPage } from './pages/CourseDetailPage';
import { QuizzesPage } from './pages/QuizzesPage';
import { QuizPlayerPage } from './pages/QuizPlayerPage';
import { ProjectsPage } from './pages/ProjectsPage';
import { ProjectDetailPage } from './pages/ProjectDetailPage';
import { CreateProjectPage } from './pages/CreateProjectPage';
import { ProfilePage } from './pages/ProfilePage';
import { CvGeneratorPage } from './pages/CvGeneratorPage';
import { MessagesPage } from './pages/MessagesPage';
import { NotificationsPage } from './pages/NotificationsPage';
import { SettingsPage } from './pages/SettingsPage';
import { AdminDashboard } from './pages/AdminDashboard';
import { ModerationPage } from './pages/ModerationPage';
import { TermsPrivacyPage } from './pages/TermsPrivacyPage';
import { StaffLeadershipPage } from './pages/StaffLeadershipPage';

import { LibraryResource } from './types';

const MainAppContent: React.FC = () => {
  const { currentLang, isRTL } = useLanguage();
  const { currentUser, authLoading } = useAuth();

  // Navigation State
  const [currentPage, setCurrentPage] = useState<string>('welcome');
  const [pageParams, setPageParams] = useState<any>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Modals state
  const [isCreatePostOpen, setIsCreatePostOpen] = useState(false);
  const [activePdfResource, setActivePdfResource] = useState<LibraryResource | null>(null);
  const [reportTarget, setReportTarget] = useState<any>(null);

  const navigateTo = (page: string, params?: any) => {
    setCurrentPage(page);
    setPageParams(params || null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Scroll to top on page transition
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [currentPage]);
  useEffect(() => {
    if (!authLoading) setCurrentPage(currentUser ? 'home' : 'welcome');
  }, [authLoading, currentUser]);

  // Check if current view is a full-page mode (landing or auth)
  const isFullPageView = currentPage === 'welcome' || currentPage === 'login' || currentPage === 'register' || currentPage === 'forgot_password';

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#070b14] text-slate-800 dark:text-slate-100 flex flex-col transition-colors selection:bg-sky-500 selection:text-white">
      
      {/* Modals Container */}
      <CreatePostModal
        isOpen={isCreatePostOpen}
        onClose={() => setIsCreatePostOpen(false)}
      />

      <PdfViewerModal
        resource={activePdfResource}
        isOpen={!!activePdfResource}
        onClose={() => setActivePdfResource(null)}
      />

      <ReportModal
        isOpen={!!reportTarget}
        onClose={() => setReportTarget(null)}
        targetId={reportTarget?.id || ''}
        targetType={reportTarget?.type || 'post'}
        targetTitle={reportTarget?.title}
      />

      {/* Render Full Page (Welcome or Auth) */}
      {isFullPageView ? (
        <div className="flex-1">
          {currentPage === 'welcome' && (
            <WelcomeLanding onNavigate={navigateTo} />
          )}
          {(currentPage === 'login' || currentPage === 'register' || currentPage === 'forgot_password') && (
            <AuthPages initialMode={currentPage as any} onNavigate={navigateTo} />
          )}
        </div>
      ) : (
        /* Standard Dashboard Layout with Header, Sidebar, Content and Mobile Nav */
        <>
          <Header
            onOpenCreatePost={() => setIsCreatePostOpen(true)}
            onNavigate={navigateTo}
            currentPage={currentPage}
            onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
          />

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full flex-1 flex">
            {/* Desktop / Responsive Sidebar */}
            <Sidebar
              currentPage={currentPage}
              onNavigate={navigateTo}
              isOpen={isSidebarOpen}
              onClose={() => setIsSidebarOpen(false)}
            />

            {/* Dynamic Main Workspace Content */}
            <main className="flex-1 min-w-0 py-6 lg:px-8">
              {currentPage === 'home' && (
                <HomeFeed
                  onNavigate={navigateTo}
                  onOpenCreatePost={() => setIsCreatePostOpen(true)}
                  onOpenPdfViewer={(res) => setActivePdfResource(res)}
                  onOpenReport={(item) => setReportTarget(item)}
                />
              )}

              {currentPage === 'explore' && (
                <ExplorePage
                  initialQuery={pageParams?.query || ''}
                  onNavigate={navigateTo}
                />
              )}

              {currentPage === 'posts' && (
                <PostsPage
                  initialDiscipline={pageParams?.discipline || 'all'}
                  onNavigate={navigateTo}
                  onOpenCreatePost={() => setIsCreatePostOpen(true)}
                  onOpenPdfViewer={(res) => setActivePdfResource(res)}
                  onOpenReport={(item) => setReportTarget(item)}
                />
              )}

              {currentPage === 'post_detail' && (
                <PostDetailPage
                  postId={pageParams}
                  onNavigate={navigateTo}
                  onOpenPdfViewer={(res) => setActivePdfResource(res)}
                  onOpenReport={(item) => setReportTarget(item)}
                />
              )}

              {currentPage === 'groups' && (
                <GroupsPage onNavigate={navigateTo} />
              )}

              {currentPage === 'group_detail' && (
                <GroupDetailPage
                  groupId={pageParams}
                  onNavigate={navigateTo}
                  onOpenCreatePost={() => setIsCreatePostOpen(true)}
                />
              )}

              {currentPage === 'library' && (
                <LibraryPage
                  onOpenPdfViewer={(res) => setActivePdfResource(res)}
                  onOpenReport={(item) => setReportTarget(item)}
                />
              )}

              {currentPage === 'courses' && (
                <CoursesPage onNavigate={navigateTo} />
              )}

              {currentPage === 'course_detail' && (
                <CourseDetailPage
                  courseId={pageParams}
                  onNavigate={navigateTo}
                />
              )}

              {currentPage === 'quizzes' && (
                <QuizzesPage onNavigate={navigateTo} />
              )}

              {currentPage === 'quiz_player' && (
                <QuizPlayerPage
                  quizId={pageParams}
                  onNavigate={navigateTo}
                />
              )}

              {currentPage === 'projects' && (
                <ProjectsPage onNavigate={navigateTo} />
              )}

              {currentPage === 'project_detail' && (
                <ProjectDetailPage
                  projectId={pageParams}
                  onNavigate={navigateTo}
                  onOpenPdfViewer={(res) => setActivePdfResource(res)}
                />
              )}

              {currentPage === 'create_project' && (
                <CreateProjectPage onNavigate={navigateTo} />
              )}

              {currentPage === 'profile' && (
                <ProfilePage onNavigate={navigateTo} />
              )}

              {currentPage === 'cv' && (
                <CvGeneratorPage />
              )}

              {currentPage === 'messages' && (
                <MessagesPage onOpenReport={(item) => setReportTarget(item)} />
              )}

              {currentPage === 'notifications' && (
                <NotificationsPage />
              )}

              {currentPage === 'settings' && (
                <SettingsPage onNavigate={navigateTo} />
              )}

              {currentPage === 'admin' && (
                <AdminDashboard />
              )}

              {currentPage === 'moderation' && (
                <ModerationPage />
              )}

              {currentPage === 'terms' && (
                <TermsPrivacyPage />
              )}

              {currentPage === 'leadership' && (
                <StaffLeadershipPage onNavigate={navigateTo} />
              )}
            </main>
          </div>

          {/* App-like Mobile Bottom Nav */}
          <MobileNav
            currentPage={currentPage}
            onNavigate={navigateTo}
            onOpenCreatePost={() => setIsCreatePostOpen(true)}
          />
        </>
      )}

      {/* Global Footer (no-print) */}
      {!isFullPageView && (
        <footer className="no-print mt-auto border-t border-slate-200 dark:border-slate-800 bg-white/60 dark:bg-slate-950/60 backdrop-blur-md py-6 text-center text-xs text-slate-500">
          <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
            <p className="font-semibold text-slate-700 dark:text-slate-300">
              «نتعلم، نبتكر، نتشارك، ونصنع المستقبل» • منتدى تلاميذ وطلاب الهندسة
            </p>
            <div className="flex items-center gap-4 text-sky-500">
              <button onClick={() => navigateTo('leadership')} className="hover:underline font-bold text-amber-500">
                المسؤولون والمشرفون
              </button>
              <button onClick={() => navigateTo('terms')} className="hover:underline">
                الشروط والخصوصية
              </button>
              <button onClick={() => navigateTo('welcome')} className="hover:underline">
                عن المنصة
              </button>
              <button onClick={() => navigateTo('settings')} className="hover:underline">
                الإعدادات
              </button>
            </div>
          </div>
        </footer>
      )}

    </div>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <AuthProvider>
          <DataProvider>
            <MainAppContent />
          </DataProvider>
        </AuthProvider>
      </LanguageProvider>
    </ThemeProvider>
  );
}
