export type Language = 'ar' | 'en' | 'fr';

export type UserRole = 
  | 'high_school_student' // تلميذ ثانوي
  | 'university_student'  // طالب جامعي
  | 'teacher'             // أستاذ أو معلم
  | 'expert_engineer'     // مهندس أو خبير
  | 'admin';              // مدير النظام

export type EngineeringDiscipline = 
  | 'electrical'      // الهندسة الكهربائية
  | 'electronics'     // الإلكترونيات
  | 'automation'      // الأتمتة الصناعية والتحكم الآلي
  | 'robotics_ai'     // الروبوتات والذكاء الاصطناعي
  | 'mechanical'      // الهندسة الميكانيكية
  | 'civil'           // الهندسة المدنية
  | 'computer_sci'    // الإعلام الآلي وعلوم الحاسوب
  | 'renewable_energy'// الطاقات المتجددة
  | 'telecom'         // الاتصالات والشبكات
  | 'general';        // علوم هندسية عامة

export interface UserProfile {
  id: string;
  username: string;
  displayName: string;
  email: string;
  role: UserRole;
  requestedRole?: UserRole;
  discipline: EngineeringDiscipline;
  educationLevel: string;
  institution?: string;
  bio?: string;
  avatarUrl?: string;
  coverUrl?: string;
  skills: string[];
  achievements: string[];
  isVerified?: boolean;
  isTrusted?: boolean;
  isModerator?: boolean;
  moderatorTitle?: string;
  privacy: {
    showEmail: boolean;
    showInstitution: boolean;
    allowDirectMessages: 'everyone' | 'verified_only' | 'nobody';
  };
  createdAt: string;
}

export type PostType = 'article' | 'question' | 'tutorial' | 'project_showcase' | 'schematic';

export interface PostComment {
  id: string;
  postId: string;
  authorId: string;
  authorName: string;
  authorAvatar?: string;
  authorRole: UserRole;
  isModerator?: boolean;
  moderatorTitle?: string;
  content: string;
  createdAt: string;
  likesCount: number;
  replies?: PostComment[];
}

export interface Post {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar?: string;
  authorRole: UserRole;
  authorDiscipline: EngineeringDiscipline;
  isModerator?: boolean;
  moderatorTitle?: string;
  title: string;
  content: string;
  discipline: EngineeringDiscipline;
  type: PostType;
  tags: string[];
  images?: string[];
  pdfUrl?: string;
  pdfTitle?: string;
  videoUrl?: string;
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  savesCount: number;
  isApproved: boolean; // For hybrid moderation
  isFeatured?: boolean;
  createdAt: string;
}

export interface EngineeringGroup {
  id: string;
  name: string;
  nameEn: string;
  nameFr: string;
  description: string;
  discipline: EngineeringDiscipline;
  coverImage: string;
  moderatorId: string;
  moderatorName: string;
  memberCount: number;
  isPrivate: boolean;
  rules?: string[];
  tags: string[];
}

export interface LibraryResource {
  id: string;
  title: string;
  description: string;
  discipline: EngineeringDiscipline;
  category: 'book' | 'lecture' | 'summary' | 'datasheet' | 'standard';
  educationLevel: string;
  language: Language;
  authorOrSource: string;
  fileSize: string;
  fileUrl: string;
  downloadsCount: number;
  viewsCount: number;
  uploadedBy: string;
  createdAt: string;
  isCopyrightClean: boolean;
}

export interface Lesson {
  id: string;
  title: string;
  duration: string;
  videoUrl?: string;
  summary: string;
  attachmentName?: string;
  isCompleted?: boolean;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  instructorId: string;
  instructorName: string;
  instructorRole: UserRole;
  discipline: EngineeringDiscipline;
  level: 'beginner' | 'intermediate' | 'advanced';
  coverImage: string;
  lessons: Lesson[];
  enrolledCount: number;
  rating: number;
  isApproved: boolean;
  createdAt: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  type: 'multiple_choice' | 'true_false' | 'short_answer';
  options?: string[];
  correctAnswer: number | boolean | string; // Evaluated after submission
  explanation: string;
}

export interface Quiz {
  id: string;
  title: string;
  description: string;
  discipline: EngineeringDiscipline;
  durationMinutes: number;
  difficulty: 'easy' | 'medium' | 'hard';
  questions: QuizQuestion[];
  participantsCount: number;
  authorName: string;
  showAnswersAfter: boolean;
}

export interface QuizAttempt {
  id: string;
  quizId: string;
  quizTitle: string;
  userId: string;
  score: number;
  totalQuestions: number;
  percentage: number;
  timeSpentMinutes: number;
  date: string;
  answers: Record<string, any>;
}

export interface ProjectTask {
  id: string;
  title: string;
  assignedTo?: string;
  isCompleted: boolean;
  dueDate?: string;
}

export interface ProjectComponent {
  name: string;
  quantity: number;
  specs: string;
}

export interface EngineeringProject {
  id: string;
  title: string;
  tagline: string;
  description: string;
  discipline: EngineeringDiscipline;
  creatorId: string;
  creatorName: string;
  creatorAvatar?: string;
  scientificSupervisor?: {
    id: string;
    name: string;
    role: UserRole;
    verified: boolean;
  };
  teamMembers: {
    userId: string;
    name: string;
    roleInTeam: string;
  }[];
  stage: 'idea' | 'schematics' | 'prototype' | 'testing' | 'completed';
  images: string[];
  schematicsUrl?: string;
  componentsList: ProjectComponent[];
  tasks: ProjectTask[];
  updates: {
    id: string;
    title: string;
    content: string;
    date: string;
  }[];
  likesCount: number;
  isFeatured?: boolean;
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: string;
  createdAt?: string;
  attachmentUrl?: string;
}

export interface Conversation {
  id: string;
  memberIds?: string[];
  memberProfiles?: { id: string; name: string; role: UserRole }[];
  participantId: string;
  participantName: string;
  participantAvatar?: string;
  participantRole: UserRole;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  messages: ChatMessage[];
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  body: string;
  type: 'like' | 'comment' | 'project_invite' | 'group_request' | 'quiz_result' | 'admin_announcement';
  isRead: boolean;
  link?: string;
  createdAt: string;
}

export interface ModerationReport {
  id: string;
  targetId: string;
  targetType: 'post' | 'comment' | 'user' | 'resource' | 'message';
  reporterId: string;
  reporterName: string;
  reason: string;
  status: 'pending' | 'resolved' | 'dismissed';
  createdAt: string;
  adminNotes?: string;
}
