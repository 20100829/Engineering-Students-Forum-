import React, { createContext, useContext, useEffect, useState } from 'react';
import { UserProfile, UserRole, EngineeringDiscipline } from '../types';
import { auth, db, firebaseConfigured } from '../firebase';
import {
  createUserWithEmailAndPassword,
  deleteUser,
  onAuthStateChanged,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signOut,
  updateProfile as updateFirebaseProfile,
  User as FirebaseUser,
} from 'firebase/auth';
import { deleteDoc, doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';

interface RegisterData {
  username: string;
  displayName: string;
  email: string;
  password: string;
  role: UserRole;
  discipline: EngineeringDiscipline;
  educationLevel: string;
  institution?: string;
}

interface AuthContextType {
  currentUser: UserProfile | null;
  isAuthenticated: boolean;
  authLoading: boolean;
  login: (email: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  register: (data: RegisterData) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  updateProfile: (updates: Partial<UserProfile>) => void;
  requestPasswordReset: (email: string) => Promise<boolean>;
  deleteAccount: () => Promise<boolean>;
  isAdmin: boolean;
  canModerate: boolean;
  canTeach: boolean;
  isExpert: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);
const ACCOUNT_CONFIG_ERROR = 'إعداد Firebase غير مكتمل. تحقق من قيم VITE_FIREBASE_* في ملف البيئة.';
const SERVICE_ERROR = 'تعذر الاتصال بخدمات Firebase. تحقق من تفعيل Authentication وFirestore وقواعد الأمان.';

function messageForAuthError(error: unknown): string {
  const code = (error as { code?: string })?.code || '';
  const messages: Record<string, string> = {
    'auth/invalid-email': 'صيغة البريد الإلكتروني غير صحيحة.',
    'auth/user-not-found': 'لا يوجد حساب بهذا البريد الإلكتروني.',
    'auth/wrong-password': 'كلمة المرور غير صحيحة.',
    'auth/invalid-credential': 'البريد الإلكتروني أو كلمة المرور غير صحيحة.',
    'auth/email-already-in-use': 'هذا البريد مسجل مسبقًا.',
    'auth/weak-password': 'اجعل كلمة المرور 6 أحرف على الأقل.',
    'auth/too-many-requests': 'محاولات كثيرة. انتظر قليلًا ثم حاول مجددًا.',
    'auth/network-request-failed': 'تعذر الاتصال بالإنترنت. تحقق من الاتصال وحاول مجددًا.',
    'permission-denied': 'رفضت قواعد Firestore العملية. انشر قواعد الأمان المرفقة في Firebase Console.',
  };
  return messages[code] || SERVICE_ERROR;
}

function safeRole(value: unknown): UserRole {
  return value === 'high_school_student' || value === 'teacher' || value === 'expert_engineer'
    ? value
    : 'university_student';
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [authLoading, setAuthLoading] = useState(true);

  useEffect(() => {
    if (!auth || !db) {
      setAuthLoading(false);
      return;
    }
    const database = db;
    return onAuthStateChanged(auth, async (firebaseUser: FirebaseUser | null) => {
      if (!firebaseUser || !firebaseUser.emailVerified) {
        setCurrentUser(null);
        if (firebaseUser && auth) void signOut(auth);
        setAuthLoading(false);
        return;
      }
      try {
        await updateDoc(doc(database, 'users', firebaseUser.uid), { isVerified: true });
        const profileSnap = await getDoc(doc(database, 'users', firebaseUser.uid));
        if (!profileSnap.exists()) {
          setCurrentUser(null);
          setAuthLoading(false);
          return;
        }
        const privateSnap = await getDoc(doc(database, 'privateUsers', firebaseUser.uid));
        const profile = profileSnap.data() as UserProfile;
        const claims = (await firebaseUser.getIdTokenResult()).claims;
        const role: UserRole = claims.admin === true ? 'admin' : claims.teacher === true ? 'teacher' : claims.expert === true ? 'expert_engineer' : safeRole(profile.role);
        setCurrentUser({ ...profile, ...(privateSnap.exists() ? privateSnap.data() : {}), id: firebaseUser.uid, email: firebaseUser.email || profile.email, isVerified: true, role });
      } catch (error) {
        console.error('Unable to load authenticated profile', error);
        setCurrentUser(null);
      } finally {
        setAuthLoading(false);
      }
    });
  }, []);

  const login = async (email: string, pass: string): Promise<{ success: boolean; error?: string }> => {
    if (!auth || !firebaseConfigured) return { success: false, error: ACCOUNT_CONFIG_ERROR };
    try {
      const credential = await signInWithEmailAndPassword(auth, email.trim(), pass);
      await credential.user.reload();
      if (!credential.user.emailVerified) {
        await sendEmailVerification(credential.user);
        await signOut(auth);
        return { success: false, error: 'يجب تأكيد بريدك أولًا. أرسلنا رسالة تأكيد جديدة إلى بريدك.' };
      }
      return { success: true };
    } catch (error) {
      return { success: false, error: messageForAuthError(error) };
    }
  };

  const register = async (data: RegisterData): Promise<{ success: boolean; error?: string }> => {
    if (!auth || !db || !firebaseConfigured) return { success: false, error: ACCOUNT_CONFIG_ERROR };
    if (!data.displayName.trim() || !data.email.trim() || !data.username.trim() || data.password.length < 6) {
      return { success: false, error: 'أدخل البيانات المطلوبة واجعل كلمة المرور 6 أحرف على الأقل.' };
    }
    let createdUid: string | null = null;
    try {
      const credential = await createUserWithEmailAndPassword(auth, data.email.trim(), data.password);
      createdUid = credential.user.uid;
      const profile: Omit<UserProfile, 'email'> & { requestedRole: UserRole } = {
        id: credential.user.uid,
        username: data.username.trim().toLowerCase(),
        displayName: data.displayName.trim(),
        // New signups never receive privileged application roles. Elevated roles require trusted admin approval.
        role: 'university_student',
        requestedRole: data.role,
        discipline: data.discipline,
        educationLevel: data.educationLevel,
        bio: 'عضو جديد في منتدى تلاميذ وطلاب الهندسة.',
        skills: [],
        achievements: [],
        isVerified: false,
        isTrusted: false,
        privacy: { showEmail: false, showInstitution: false, allowDirectMessages: 'verified_only' },
        createdAt: new Date().toISOString().slice(0, 10),
      };
      await setDoc(doc(db, 'users', credential.user.uid), profile);
      await setDoc(doc(db, 'privateUsers', credential.user.uid), { institution: data.institution || '' });
      await sendEmailVerification(credential.user);
      await signOut(auth);
      return { success: true };
    } catch (error) {
      // Avoid leaving an auth-only orphan if creating the profile failed.
      if (createdUid && auth.currentUser?.uid === createdUid) {
        try {
          if (db) await deleteDoc(doc(db, 'privateUsers', createdUid));
          if (db) await deleteDoc(doc(db, 'users', createdUid));
          await deleteUser(auth.currentUser);
        } catch { /* Firebase may require recent login; surface the original error. */ }
      }
      return { success: false, error: messageForAuthError(error) };
    }
  };

  const logout = async () => {
    if (auth) await signOut(auth);
    setCurrentUser(null);
  };

  const updateProfile = (updates: Partial<UserProfile>) => {
    if (!currentUser || !auth?.currentUser || !db) return;
    const safeUpdates = { ...updates } as Record<string, unknown>;
    delete safeUpdates.id;
    delete safeUpdates.email;
    delete safeUpdates.role;
    delete safeUpdates.isVerified;
    delete safeUpdates.isTrusted;
    delete safeUpdates.isModerator;
    const institution = safeUpdates.institution;
    delete safeUpdates.institution;
    const updated = { ...currentUser, ...safeUpdates } as UserProfile;
    if (typeof institution === 'string') updated.institution = institution;
    setCurrentUser(updated);
    if (Object.keys(safeUpdates).length) void updateDoc(doc(db, 'users', currentUser.id), safeUpdates).catch(error => {
      console.error('Profile update failed', error);
      setCurrentUser(currentUser);
    });
    if (typeof institution === 'string') {
      void updateDoc(doc(db, 'privateUsers', currentUser.id), { institution }).catch(error => console.error('Private profile update failed', error));
    }
    if (typeof safeUpdates.displayName === 'string') {
      void updateFirebaseProfile(auth.currentUser, { displayName: safeUpdates.displayName });
    }
  };

  const requestPasswordReset = async (email: string): Promise<boolean> => {
    if (!auth || !firebaseConfigured) return false;
    try {
      await sendPasswordResetEmail(auth, email.trim());
      return true;
    } catch (error) {
      console.error('Password reset request failed', error);
      return false;
    }
  };

  const deleteAccount = async (): Promise<boolean> => {
    if (!auth?.currentUser || !db) return false;
    try {
      await deleteDoc(doc(db, 'privateUsers', auth.currentUser.uid));
      await deleteDoc(doc(db, 'users', auth.currentUser.uid));
      await deleteUser(auth.currentUser);
      setCurrentUser(null);
      return true;
    } catch (error) {
      console.error('Account deletion failed', error);
      return false;
    }
  };

  // Privileged roles are read only from a trusted Firebase ID-token claim.
  const isAdmin = currentUser?.role === 'admin';
  const canModerate = isAdmin || currentUser?.role === 'teacher';
  const canTeach = isAdmin || currentUser?.role === 'teacher' || currentUser?.role === 'expert_engineer';
  const isExpert = currentUser?.role === 'teacher' || currentUser?.role === 'expert_engineer';

  return <AuthContext.Provider value={{
    currentUser,
    isAuthenticated: !!currentUser,
    authLoading,
    login,
    register,
    logout,
    updateProfile,
    requestPasswordReset,
    deleteAccount,
    isAdmin,
    canModerate,
    canTeach,
    isExpert,
  }}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
