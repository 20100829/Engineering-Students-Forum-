import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { db } from '../firebase';
import { addDoc, arrayUnion, collection, doc, increment, onSnapshot, orderBy, query, setDoc, updateDoc, where } from 'firebase/firestore';
import { 
  Post, 
  EngineeringGroup, 
  LibraryResource, 
  Course, 
  Quiz, 
  QuizAttempt, 
  EngineeringProject, 
  Conversation, 
  NotificationItem, 
  ModerationReport,
  EngineeringDiscipline,
  PostType,
  UserProfile
} from '../types';

interface DataContextType {
  posts: Post[];
  groups: EngineeringGroup[];
  libraryResources: LibraryResource[];
  courses: Course[];
  quizzes: Quiz[];
  projects: EngineeringProject[];
  conversations: Conversation[];
  users: UserProfile[];
  notifications: NotificationItem[];
  reports: ModerationReport[];
  savedPostIds: string[];
  savedResourceIds: string[];
  userQuizAttempts: QuizAttempt[];
  
  // Post operations
  createPost: (postData: Omit<Post, 'id' | 'likesCount' | 'commentsCount' | 'sharesCount' | 'savesCount' | 'createdAt' | 'isApproved'>) => void;
  toggleLikePost: (postId: string) => void;
  toggleSavePost: (postId: string) => void;
  addComment: (postId: string, text: string, author: { id: string; name: string; role: any }) => void;
  
  // Group operations
  joinedGroupIds: string[];
  toggleJoinGroup: (groupId: string) => void;

  // Project operations
  createProject: (projectData: Omit<EngineeringProject, 'id' | 'likesCount' | 'createdAt' | 'updates'>) => void;
  toggleLikeProject: (projectId: string) => void;
  addProjectUpdate: (projectId: string, title: string, content: string) => void;
  toggleTaskStatus: (projectId: string, taskId: string) => void;
  assignSupervisor: (projectId: string, supervisor: any) => void;

  // Course operations
  userCourseProgress: Record<string, { completedLessonIds: string[]; progressPercent: number }>;
  toggleLessonComplete: (courseId: string, lessonId: string) => void;

  // Library operations
  toggleSaveResource: (resourceId: string) => void;
  incrementResourceDownload: (resourceId: string) => void;
  
  // Quiz operations
  submitQuizAttempt: (attempt: Omit<QuizAttempt, 'id' | 'date'>) => QuizAttempt;

  // Message operations
  sendMessage: (conversationId: string, text: string, sender: { id: string; name: string }) => void;
  createConversation: (participant: any, firstMessage?: string) => string;

  // Notification operations
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;

  // Moderation & Admin
  reportItem: (report: Omit<ModerationReport, 'id' | 'status' | 'createdAt'>) => void;
  approvePost: (postId: string) => void;
  rejectPost: (postId: string) => void;
  resolveReport: (reportId: string, resolution: 'resolved' | 'dismissed') => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

// Initial Engineering Data Seeds
const INITIAL_GROUPS: EngineeringGroup[] = [
  {
    id: 'grp_elec',
    name: 'الهندسة الكهربائية والطاقات',
    nameEn: 'Electrical & Power Engineering',
    nameFr: 'Génie Électrique & Énergie',
    description: 'ملتقى مهندسي وطلاب الهندسة الكهربائية: الدوائر الكهربائية، محطات القدرة، المحولات، والشبكات الذكية.',
    discipline: 'electrical',
    coverImage: 'https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?w=800&auto=format&fit=crop&q=80',
    moderatorId: 'usr_expert_1',
    moderatorName: 'م. رشيد السليماني',
    memberCount: 342,
    isPrivate: false,
    tags: ['دوائر كهربائية', 'محركات كهربائية', 'ضغط عالي', 'محولات', 'Power Grids']
  },
  {
    id: 'grp_electronics',
    name: 'الإلكترونيات والدارات المدمجة',
    nameEn: 'Electronics & Embedded Systems',
    nameFr: 'Électronique & Systèmes Embarqués',
    description: 'تصميم اللوحات المطبوعة PCB، الدارات المنطقية، أشباه الموصلات، الميكروكنترولر Arduino وSTM32 وESP32.',
    discipline: 'electronics',
    coverImage: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&auto=format&fit=crop&q=80',
    moderatorId: 'usr_abaidi',
    moderatorName: 'عبيدي صلاح الدين (مشرف المخططات والهندسات)',
    memberCount: 289,
    isPrivate: false,
    tags: ['PCB Design', 'Microcontrollers', 'Analog', 'Digital Logic', 'Schematics']
  },
  {
    id: 'grp_automation',
    name: 'الأتمتة الصناعية والتحكم الآلي',
    nameEn: 'Industrial Automation & Control',
    nameFr: 'Automatisme & Contrôle Industriel',
    description: 'برمجة المتحكمات المنطقية PLC (Siemens, Schneider, Allen Bradley)، نظم SCADA، والمشغلات الهيدروليكية والهوائية.',
    discipline: 'automation',
    coverImage: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=800&auto=format&fit=crop&q=80',
    moderatorId: 'usr_teacher_1',
    moderatorName: 'د. كريم بن منصور',
    memberCount: 215,
    isPrivate: false,
    tags: ['PLC Ladder', 'SCADA', 'Pneumatics', 'PID Control', 'Sensors']
  },
  {
    id: 'grp_robotics',
    name: 'الروبوتات والذكاء الاصطناعي',
    nameEn: 'Robotics & Artificial Intelligence',
    nameFr: 'Robotique & Intelligence Artificielle',
    description: 'بناء الأذرع الآلية، الروبوتات المتنقلة، رؤية الحاسوب، ونظام التشغيل الروبوتي ROS / ROS2.',
    discipline: 'robotics_ai',
    coverImage: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=800&auto=format&fit=crop&q=80',
    moderatorId: 'usr_uni_student_1',
    moderatorName: 'سارة بن علي',
    memberCount: 412,
    isPrivate: false,
    tags: ['ROS2', 'Kinematics', 'Computer Vision', 'Autonomous', 'SLAM']
  },
  {
    id: 'grp_renewables',
    name: 'الطاقات المتجددة والنظيفة',
    nameEn: 'Renewable & Clean Energy',
    nameFr: 'Énergies Renouvelables',
    description: 'أنظمة الطاقة الشمسية الكهروضوئية، توربينات الرياح، بنوك البطاريات، ونظم ضخ المياه بالطاقة الشمسية.',
    discipline: 'renewable_energy',
    coverImage: 'https://images.unsplash.com/photo-1509391365360-2e959784a276?w=800&auto=format&fit=crop&q=80',
    moderatorId: 'usr_expert_1',
    moderatorName: 'م. رشيد السليماني',
    memberCount: 198,
    isPrivate: false,
    tags: ['Solar PV', 'Wind Turbines', 'Inverters', 'MPPT', 'Energy Storage']
  },
  {
    id: 'grp_mechanical',
    name: 'الهندسة الميكانيكية والتصنيع',
    nameEn: 'Mechanical Engineering & CAD',
    nameFr: 'Génie Mécanique & CAO',
    description: 'النمذجة ثلاثية الأبعاد (SolidWorks, Inventor, Fusion 360)، مقاومة المواد، والطباعة ثلاثية الأبعاد والتصنيع CNC.',
    discipline: 'mechanical',
    coverImage: 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=800&auto=format&fit=crop&q=80',
    moderatorId: 'usr_teacher_1',
    moderatorName: 'د. كريم بن منصور',
    memberCount: 184,
    isPrivate: false,
    tags: ['CAD', 'SolidWorks', 'Thermodynamics', 'Fluid Mechanics', 'CNC']
  },
  {
    id: 'grp_civil',
    name: 'الهندسة المدنية والإنشاءات',
    nameEn: 'Civil Engineering & Construction',
    nameFr: 'Génie Civil & Bâtiment',
    description: 'حساب المنشآت الخرسانية والمعدنية، ميكانيكا التربة، الجسور، وتطبيقات برامج التحليل Robot Structural Analysis.',
    discipline: 'civil',
    coverImage: 'https://images.unsplash.com/photo-1541888946425-d0fbb18615f3?w=800&auto=format&fit=crop&q=80',
    moderatorId: 'usr_admin_1',
    moderatorName: 'إدارة المنتدى',
    memberCount: 167,
    isPrivate: false,
    tags: ['BIM', 'Structures', 'Concrete', 'Soil Mechanics', 'Revit']
  },
  {
    id: 'grp_cs',
    name: 'علوم الحاسوب والبرمجيات الهندسية',
    nameEn: 'Computer Science & Software',
    nameFr: 'Informatique & Génie Logiciel',
    description: 'الخوارزميات، البرمجة بالنظم المدمجة C/C++، بايثون للحسابات الهندسية، وقواعد البيانات وتطوير الويب.',
    discipline: 'computer_sci',
    coverImage: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&auto=format&fit=crop&q=80',
    moderatorId: 'usr_fedili',
    moderatorName: 'فضيلي فاتح (مشرف البرمجة والهندسة البرمجية)',
    memberCount: 350,
    isPrivate: false,
    tags: ['Algorithms', 'Python', 'C++', 'Embedded Linux', 'Data Structures']
  },
  {
    id: 'grp_telecom',
    name: 'الاتصالات والشبكات الذكية',
    nameEn: 'Telecommunications & Networks',
    nameFr: 'Télécommunications & Réseaux',
    description: 'معالجة الإشارات الرقمية DSP، الهوائيات، شبكات الجيل الخامس 5G، وبروتوكولات إنترنت الأشياء LoRaWAN وZigbee.',
    discipline: 'telecom',
    coverImage: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=800&auto=format&fit=crop&q=80',
    moderatorId: 'usr_expert_1',
    moderatorName: 'م. رشيد السليماني',
    memberCount: 145,
    isPrivate: false,
    tags: ['DSP', '5G', 'IoT', 'RF Circuits', 'Antennas']
  }
];

const INITIAL_POSTS: Post[] = [
  {
    id: 'post_kaddari_official',
    authorId: 'usr_admin_kaddari',
    authorName: 'قداري محمود طه ياسين',
    authorRole: 'admin',
    authorDiscipline: 'electrical',
    title: 'بيان افتتاحي وتوجيهي من مؤسس ومنشئ التطبيق والمسؤول والمدير العام لجميع الأعضاء والمهندسين',
    content: `بسم الله الرحمن الرحيم،
أرحب بجميع زملائي وأبنائي من تلاميذ الثانويات وطلاب المعاهد والجامعات، وأساتذتنا الأفاضل ومهندسينا الخبراء.

بصفتي منشئ ومؤسس هذا التطبيق والمسؤول والمدير العام لمنتدى تلاميذ وطلاب الهندسة، يسعدني أن أعلن عن انطلاق منصتنا الرقمية تحت شعارنا الخالد:
«نتعلم، نبتكر، نتشارك، ونصنع المستقبل».

لقد وضعنا في هذه المنصة كل الإمكانيات لدعم الطلاب في مختلف التخصصات: من الهندسة الكهربائية والإلكترونيات، إلى البرمجيات، الروبوتات، والميكانيكا والهندسة المدنية.
كما كلفنا هيئة إشرافية رائدة يقودها:
- الأستاذ فضيلي فاتح: مشرف البرمجة والهندسة البرمجية.
- الأستاذ عبيدي صلاح الدين: مشرف المخططات والهندسات.
مع نخبة من الأساتذة والخبراء الميدانيين.

ندعو الجميع للمشاركة الإيجابية، وتبادل المخططات الهندسية المعتمدة، مع الالتزام التام بحماية خصوصية أبنائنا التلاميذ والحفاظ على النزاهة العلمية.`,
    discipline: 'electrical',
    type: 'article',
    tags: ['إدارة المنتدى', 'قداري محمود طه ياسين', 'التأسيس', 'الهندسة والابتكار', 'كلمة المدير العام'],
    images: ['https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=800&auto=format&fit=crop&q=80'],
    likesCount: 245,
    commentsCount: 58,
    sharesCount: 64,
    savesCount: 110,
    isApproved: true,
    isFeatured: true,
    createdAt: '2026-10-30T08:00:00Z'
  },
  {
    id: 'post_fedili_programming',
    authorId: 'usr_fedili',
    authorName: 'فضيلي فاتح',
    authorRole: 'expert_engineer',
    authorDiscipline: 'computer_sci',
    isModerator: true,
    moderatorTitle: 'مشرف البرمجة والهندسة البرمجية',
    title: 'توجيهات الإشراف البرمجي: هندسة الشيفرات البرمجية النظيفة Clean Code في النظم المدمجة Embedded Systems',
    content: `السلام عليكم ورحمة الله،
بصفتي مشرف البرمجة والهندسة البرمجية في منتدى تلاميذ وطلاب الهندسة، يسعدني تقديم هذه المبادئ الأساسية لكل طالب يبني مشروعاً برمجياً أو نظاماً مدمجاً (STM32, ESP32, Raspberry Pi):

1. تجنب تخصيص الذاكرة الديناميكي (Dynamic Memory Allocation - malloc/free) في المتحكمات المحدودة الموارد تفادياً لتقطع الذاكرة (Heap Fragmentation) واستقرار النظام على المدى الطويل.
2. الاستفادة القصوى من ميزة constexpr في C++ لنقل الحسابات والتعاريف الثابتة إلى وقت الترجمة (Compile-time) بدلاً من استهلاك دورات المعالج وقت التشغيل.
3. كتابة دوال المقاطعة العتادية (Interrupt Service Routines - ISR) بأقصى سرعة وبدون تأخيرات زمنية، مع استخدام المتغيرات الموسومة بـ volatile لتفادي أخطاء تحسين المترجم (Compiler Optimization).
4. الفصل الصارم بين طبقة محركات العتاد (Hardware Abstraction Layer - HAL) وطبقة منطق التطبيق (Application Logic) لتسهيل إعادة استخدام الشيفرة.

أرحب بمراجعة أكوادكم البرمجية ومشاريعكم ومساعدتكم على تصحيح أخطاء الخوارزميات في قسم علوم الحاسوب والبرمجيات الهندسية!`,
    discipline: 'computer_sci',
    type: 'tutorial',
    tags: ['هندسة البرمجيات', 'فضيلي فاتح', 'C++', 'Embedded Systems', 'Clean Code'],
    pdfUrl: 'https://example.com/embedded-clean-code-guidelines.pdf',
    pdfTitle: 'دليل الإشراف البرمجي للأنظمة المدمجة - إعداد أ. فضيلي فاتح.pdf',
    images: ['https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&auto=format&fit=crop&q=80'],
    likesCount: 132,
    commentsCount: 29,
    sharesCount: 38,
    savesCount: 85,
    isApproved: true,
    isFeatured: true,
    createdAt: '2026-10-29T16:40:00Z'
  },
  {
    id: 'post_abaidi_schematics',
    authorId: 'usr_abaidi',
    authorName: 'عبيدي صلاح الدين',
    authorRole: 'expert_engineer',
    authorDiscipline: 'electronics',
    isModerator: true,
    moderatorTitle: 'مشرف المخططات والهندسات',
    title: 'دليل مراجعة المخططات الهندسية: القواعد الميدانية لتصميم دارات PCB متعددة الطبقات وتفادي أخطاء التصنيع',
    content: `تحياتي لجميع المهندسين والطلاب والمخترعين،
بصفتي مشرف المخططات والهندسات، أضع بين أيديكم خلاصة المعايير المعتمدة لتدقيق وتصنيع اللوحات الإلكترونية المطبوعة (PCB) بطرق احترافية:

1. سلامة طبقات التأريض (Ground Planes): احرصوا على أن يكون مسار العودة (Return Path) للإشارات عالية التردد مباشراً وأسفل المسار تماماً لتقليل الحث الذاتي والتداخل الكهرومغناطيسي (EMI).
2. مكثفات فك الارتباط (Decoupling Capacitors): يجب وضعها في أقرب نقطة ملموسة من دبابيس التغذية VCC/GND لكل دارة متكاملة IC مع مسارات عريضة وقصيرة.
3. تفادي الزوايا الحادة (90-degree corners): استخدموا دائماً زوايا 45 درجة أو مسارات منحنية لمنع انعكاس الإشارة وظاهرة Acid Traps أثناء حفر اللوحات.
4. مراجعة عرض المسارات الكهربائية حسب شدة التيار بالاعتماد على معيار IPC-2221.

قبل إرسال ملفات Gerber إلى مصانع التصنيع أو عرضها في مشاريع التخرج، يمكنكم طلب المراجعة الفنية المباشرة لمخططاتكم الهندسية.`,
    discipline: 'electronics',
    type: 'tutorial',
    tags: ['مخططات هندسية', 'عبيدي صلاح الدين', 'PCB Design', 'KiCad', 'Altium', 'EMI Reduction'],
    pdfUrl: 'https://example.com/pcb-engineering-guidelines.pdf',
    pdfTitle: 'معايير تدقيق المخططات الهندسية واللوحات المطبوعة - إعداد أ. عبيدي صلاح الدين.pdf',
    images: ['https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&auto=format&fit=crop&q=80'],
    likesCount: 154,
    commentsCount: 36,
    sharesCount: 42,
    savesCount: 96,
    isApproved: true,
    isFeatured: true,
    createdAt: '2026-10-29T10:15:00Z'
  },
  {
    id: 'post_1',
    authorId: 'usr_teacher_1',
    authorName: 'د. كريم بن منصور',
    authorRole: 'teacher',
    authorDiscipline: 'automation',
    title: 'دليل عملي: كيفية برمجة متحكمات PLC لحماية المحركات ثلاثية الأطوار من الحمل الزائد',
    content: `في هذا الدرس الهندسي، نستعرض الطريقة النموذجية لتصميم مخطط منطقي (Ladder Logic) يضمن حماية المحركات الحثية ثلاثية الأطوار (Three-phase Induction Motors) من:
1. انقطاع أحد الأطوار (Phase Loss).
2. الحمل الحراري الزائد عبر Relay Overload.
3. التبديل العكسي المباشر لحركة الدوران قبل التوقف التام.

المعادلة الأساسية لحساب تيار البداية:
I_start = (5 to 7) * I_nominal

مرفق مع المنشور مخطط التوصيل الكهربائي لدارة القدرة ودارة التحكم، بالإضافة إلى كود Ladder قابل للتطبيق على بيئات Siemens TIA Portal وSchneider EcoStruxure. شاركوني تجاربكم واستفساراتكم في التعليقات!`,
    discipline: 'automation',
    type: 'tutorial',
    tags: ['PLC', 'Siemens', 'Industrial Control', 'Electric Motors', 'Ladder Logic'],
    pdfUrl: 'https://example.com/plc-motor-protection.pdf',
    pdfTitle: 'المخطط الهندسي لدارة التحكم والقدرة.pdf',
    images: ['https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=800&auto=format&fit=crop&q=80'],
    likesCount: 68,
    commentsCount: 14,
    sharesCount: 22,
    savesCount: 45,
    isApproved: true,
    isFeatured: true,
    createdAt: '2026-10-28T09:30:00Z'
  },
  {
    id: 'post_2',
    authorId: 'usr_high_school_1',
    authorName: 'أنس العلمي',
    authorRole: 'high_school_student',
    authorDiscipline: 'electrical',
    title: 'مشروعي المدرسي: تحكم في سرعة محرك تيار مستمر DC باستخدام مؤقت NE555 وتقنية PWM',
    content: `السلام عليكم زملائي وأساتذتي الأفاضل.
قمت بتصميم وتجميع لوحة تجريبية صغيرة للتحكم في سرعة محرك DC بجهد 12V باستخدام المؤقت الشهير NE555 كمولد نبضات معدلة العرض (PWM)، مع ترانزستور قدرة MOSFET نوع IRFZ44N.

المشكلة التي واجهتني:
عند تقليل سرعة المحرك إلى أقل من 20%، ألاحظ وجود طنين خفيف واهتزاز. قمت بإضافة صمام ثنائي Flyback Diode 1N4007 بالتوازي مع المحرك. هل توصون برفع تردد PWM لتجاوز نطاق الترددات المسموعة (فوق 20kHz)؟
شكراً لتوجيهاتكم القيمة!`,
    discipline: 'electronics',
    type: 'question',
    tags: ['NE555', 'PWM', 'MOSFET', 'DC Motor', 'Electronics Starter'],
    images: ['https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&auto=format&fit=crop&q=80'],
    likesCount: 39,
    commentsCount: 9,
    sharesCount: 5,
    savesCount: 12,
    isApproved: true,
    isFeatured: false,
    createdAt: '2026-10-29T14:15:00Z'
  },
  {
    id: 'post_3',
    authorId: 'usr_expert_1',
    authorName: 'م. رشيد السليماني',
    authorRole: 'expert_engineer',
    authorDiscipline: 'renewable_energy',
    title: 'تحليل مقارن: كفاءة محولات الطاقة الشمسية المركزية مقابل المحولات الخيطية (String Inverters)',
    content: `في المشاريع الكبرى للمزارع الشمسية (> 10 MWp)، يبقى خيار المعمارية الهندسية للمحولات نقطة حاسمة في تكلفة الإنتاج الكلية (LCOE).

في هذه المقالة التقنية، نناقش:
- متى يكون محول السلسلة (String Inverter) مجدياً اقتصادياً من حيث الصيانة ومرونة الـ MPPT؟
- حساب الفواقد الحرارية عند درجات حرارة المحيط العالية (> 45°C في البيئات الصحراوية).
- أثر التوافقيات (Total Harmonic Distortion - THD) على جودة شبكة التوزيع الوطنية.

أرحب بنقاش مهندسي الكهرباء والطاقة في التعليقات.`,
    discipline: 'renewable_energy',
    type: 'article',
    tags: ['Solar Energy', 'Inverters', 'MPPT', 'LCOE', 'Smart Grid'],
    pdfUrl: 'https://example.com/solar-inverters-benchmark.pdf',
    pdfTitle: 'دراسة هندسية مقارنة لأنظمة المحولات الكهروضوئية.pdf',
    images: ['https://images.unsplash.com/photo-1509391365360-2e959784a276?w=800&auto=format&fit=crop&q=80'],
    likesCount: 84,
    commentsCount: 19,
    sharesCount: 31,
    savesCount: 62,
    isApproved: true,
    isFeatured: true,
    createdAt: '2026-10-27T18:00:00Z'
  },
  {
    id: 'post_4',
    authorId: 'usr_uni_student_1',
    authorName: 'سارة بن علي',
    authorRole: 'university_student',
    authorDiscipline: 'robotics_ai',
    title: 'تجربة دمج خوارزمية SLAM مع مستشعر LiDAR 2D وروبوت متنقل يعمل بنظام ROS 2 Humble',
    content: `يسعدني مشاركتكم نتائج الاختبارات الميدانية لروبوت الملاحة الذاتية الداخلي (Indoor Mobile Robot).
استخدمنا:
- عقل التحكم: Raspberry Pi 5 مع Ubuntu Server 22.04 + ROS 2 Humble.
- المستشعرات: RPLiDAR A1 + IMU MPU6050 بعد تطبيق فلتر كالمان (Extended Kalman Filter).
- الخوارزمية: Slam Toolbox لتوليد الخريطة الثنائية واكتشاف العوائق.

معدل الدقة في رسم الجدران والأبواب وصل إلى خطأ أقل من ±2.5 سم.
الخطوة القادمة: تطبيق حزمة Nav2 للتنقل الذاتي مع تخطيط المسار الديناميكي A*. رابط كود GitHub وملف URDF متاح للجميع!`,
    discipline: 'robotics_ai',
    type: 'project_showcase',
    tags: ['ROS2', 'SLAM', 'LiDAR', 'Robotics', 'RaspberryPi'],
    images: ['https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=800&auto=format&fit=crop&q=80'],
    likesCount: 92,
    commentsCount: 23,
    sharesCount: 40,
    savesCount: 77,
    isApproved: true,
    isFeatured: true,
    createdAt: '2026-10-26T11:20:00Z'
  }
];

const INITIAL_PROJECTS: EngineeringProject[] = [
  {
    id: 'proj_1',
    title: 'نظام ري ذكي هجين يعمل بالطاقة الشمسية وإنترنت الأشياء (IoT)',
    tagline: 'منظومة زراعية مؤتمتة تقيس رطوبة التربة وتتنبأ بالطقس مع ضخ شمسي دقيق بدون فواقد مائية.',
    description: `يهدف هذا المشروع الابتكاري إلى حل معضلة هدر المياه في الزراعة الحديثة. يدمج المشروع محطة كهروضوئية 2kW، ومضخة غاطسة ثلاثية الأطوار يقودها VFD شمسي، وشبكة من مجسات الرطوبة والحرارة متصلة عبر بروتوكول LoRaWAN إلى خادم محلي يحلل البيانات.

مراحل العمل:
1. التصميم الكهربائي وحساب طاقة الألواح والبطاريات.
2. بناء الدارات الإلكترونية لعقد الاستشعار ومراجعة استهلاك الطاقة (Sleep Mode).
3. برمجة لوحة التحكم والواجهة الرسومية Dashboard.`,
    discipline: 'renewable_energy',
    creatorId: 'usr_uni_student_1',
    creatorName: 'سارة بن علي',
    scientificSupervisor: {
      id: 'usr_expert_1',
      name: 'م. رشيد السليماني',
      role: 'expert_engineer',
      verified: true
    },
    teamMembers: [
      { userId: 'usr_uni_student_1', name: 'سارة بن علي', roleInTeam: 'قائد الفريق ومبرمج الأنظمة المدمجة' },
      { userId: 'usr_high_school_1', name: 'أنس العلمي', roleInTeam: 'مساعد تجميع الدوائر والتوصيل' },
      { userId: 'usr_ext_1', name: 'طارق حداد', roleInTeam: 'مصمم الميكانيك والأنابيب' }
    ],
    stage: 'prototype',
    images: [
      'https://images.unsplash.com/photo-1509391365360-2e959784a276?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=800&auto=format&fit=crop&q=80'
    ],
    schematicsUrl: 'https://example.com/schematics-solar-pump.pdf',
    componentsList: [
      { name: 'ألواح شمسية Monocrystalline 450W', quantity: 6, specs: 'Tier 1, Voc: 49.5V, Isc: 11.4A' },
      { name: 'محول تردد متغير VFD شمسي', quantity: 1, specs: '3-phase 2.2kW, MPPT 200-400VDC' },
      { name: 'متحكم ESP32 مع وحدة LoRa SX1278', quantity: 4, specs: '868MHz, 3.3V Ultra-low power' },
      { name: 'حساسات رطوبة التربة السعوية Capacitive', quantity: 8, specs: 'Corrosion resistant analog' }
    ],
    tasks: [
      { id: 'tsk_1', title: 'إتمام المخطط الكهربائي التوصيلي الأحادي (Single Line Diagram)', assignedTo: 'سارة بن علي', isCompleted: true },
      { id: 'tsk_2', title: 'اختبار عقد الاستشعار في الحقل لمسافة 1.5 كم LoRa', assignedTo: 'أنس العلمي', isCompleted: true },
      { id: 'tsk_3', title: 'معايرة خوارزمية فتح وإغلاق الصمامات الكهرومغناطيسية Solenoid', assignedTo: 'طارق حداد', isCompleted: false },
      { id: 'tsk_4', title: 'التشغيل التجريبي المتواصل لمدة 7 أيام وتوثيق النتائج', assignedTo: 'الفريق بأكمله', isCompleted: false }
    ],
    updates: [
      {
        id: 'upd_1',
        title: 'نجاح اختبار إرسال بيانات الرطوبة لمسافة 2 كم عبر تقنية LoRa',
        content: 'تمكنا اليوم بفضل الله من استلام بيانات رطوبة التربة بدون أي فقدان للحزم مع زمن تأخير أقل من 200ms.',
        date: '2026-10-25'
      },
      {
        id: 'upd_2',
        title: 'انضمام المهندس رشيد كمشرف علمي معتمد للمشروع',
        content: 'قام م. رشيد بمراجعة حسابات أمان العوازل ومقاطع الكابلات الشمسية وقدم ملاحظات قيّمة تمت معالجتها.',
        date: '2026-10-20'
      }
    ],
    likesCount: 114,
    isFeatured: true,
    createdAt: '2026-10-15'
  },
  {
    id: 'proj_2',
    title: 'ذراع روبوتية صناعية 6 درجات حرية (6-DOF) للفرز واللحام الدقيق',
    tagline: 'ذراع آلية معتمدة على محركات السيرفو ومحركات الخطوة الدقيقة مع واجهة تحكم وتحليل حركي Inverse Kinematics.',
    description: `مشروع تخرج طلابي يهدف لتصميم ذراع روبوتية منخفضة التكلفة للورشات التعليمية والمصانع الصغيرة. تم تصميم المفاصل ببرنامج SolidWorks وتصنيعها عبر الطباعة ثلاثية الأبعاد بألياف الكربون PETG-CF.`,
    discipline: 'robotics_ai',
    creatorId: 'usr_high_school_1',
    creatorName: 'أنس العلمي',
    scientificSupervisor: {
      id: 'usr_teacher_1',
      name: 'د. كريم بن منصور',
      role: 'teacher',
      verified: true
    },
    teamMembers: [
      { userId: 'usr_high_school_1', name: 'أنس العلمي', roleInTeam: 'قائد المشروع ومبرمج حركات السيرفو' },
      { userId: 'usr_uni_student_1', name: 'سارة بن علي', roleInTeam: 'مستشارة الحسابات الحركية (IK)' }
    ],
    stage: 'schematics',
    images: [
      'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=800&auto=format&fit=crop&q=80'
    ],
    schematicsUrl: 'https://example.com/robot-arm-assembly.pdf',
    componentsList: [
      { name: 'محركات خطوة NEMA 23 عالية العزم', quantity: 3, specs: 'High Torque 3Nm, 4.2A' },
      { name: 'محركات سيرفو معدنية دقيقة MG996R', quantity: 3, specs: 'Metal Gears 11kg/cm' },
      { name: 'مشغلات المحركات TB6600', quantity: 3, specs: 'Microstepping up to 1/32' }
    ],
    tasks: [
      { id: 'tsk_10', title: 'حساب عزم القصور الذاتي لكل مفصل (Inertia Analysis)', assignedTo: 'سارة بن علي', isCompleted: true },
      { id: 'tsk_11', title: 'طباعة التروس والمحاور بتقنية PETG', assignedTo: 'أنس العلمي', isCompleted: false }
    ],
    updates: [
      {
        id: 'upd_20',
        title: 'اعتماد المخطط الهيكلي ثلاثي الأبعاد من المشرف الأكاديمي',
        content: 'أبدى د. كريم موافقته على تصميم قاعدة المحاور بعد تقليل الوزن الإجمالي بنسبة 18%.',
        date: '2026-10-27'
      }
    ],
    likesCount: 78,
    isFeatured: true,
    createdAt: '2026-10-18'
  }
];

const INITIAL_LIBRARY: LibraryResource[] = [
  {
    id: 'res_1',
    title: 'مرجع هندسة القوى الكهربائية وتحليل الشبكات (Power Systems Analysis)',
    description: 'كتاب شامل في تدفق القدرة (Load Flow)، دارات القصر (Fault Analysis)، والاستقرار العابر في المنظومات الكهربائية الحديثة.',
    discipline: 'electrical',
    category: 'book',
    educationLevel: 'جامعي - مهندسون',
    language: 'ar',
    authorOrSource: 'ترجمة وإعداد هيئة أساتذة الهندسة الكهربائية',
    fileSize: '14.2 MB',
    fileUrl: 'https://example.com/power-systems-guide.pdf',
    downloadsCount: 520,
    viewsCount: 1420,
    uploadedBy: 'د. كريم بن منصور',
    createdAt: '2025-11-10',
    isCopyrightClean: true
  },
  {
    id: 'res_2',
    title: 'دليل تصميم الدوائر المطبوعة الاحترافية PCB Design Guidelines',
    description: 'أفضل الممارسات العملية في مسارات الإشارات عالية السرعة (High-speed routing)، فصل الأراضي (Ground Planes)، والتوافق الكهرومغناطيسي EMC.',
    discipline: 'electronics',
    category: 'datasheet',
    educationLevel: 'ثانوي وجامعي',
    language: 'en',
    authorOrSource: 'IEEE Technical Committee',
    fileSize: '5.8 MB',
    fileUrl: 'https://example.com/pcb-guidelines.pdf',
    downloadsCount: 840,
    viewsCount: 2310,
    uploadedBy: 'م. رشيد السليماني',
    createdAt: '2026-02-14',
    isCopyrightClean: true
  },
  {
    id: 'res_3',
    title: 'سلسلة محاضرات الأتمتة الصناعية: من الأساسيات إلى برمجة Siemens S7-1200',
    description: 'سلاسل تمارين محلولة ومخططات تطبيقية لأنظمة الفرز والتعبئة والتحكم في المحركات الحثية.',
    discipline: 'automation',
    category: 'lecture',
    educationLevel: 'طالب جامعي / تكوين مهني',
    language: 'fr',
    authorOrSource: 'Laboratoire d’Automatique Industrielle',
    fileSize: '8.4 MB',
    fileUrl: 'https://example.com/cours-automatisme-industriel.pdf',
    downloadsCount: 410,
    viewsCount: 980,
    uploadedBy: 'د. كريم بن منصور',
    createdAt: '2026-04-05',
    isCopyrightClean: true
  },
  {
    id: 'res_4',
    title: 'ملخص قوانين ميكانيكا المواد ومقاومة الإنشاءات (Strength of Materials Cheat Sheet)',
    description: 'ملخص مركّز يحتوي على كافة القوانين: الإجهاد، الانفعال، عزم الانحناء، وقوى القص في العوارض الهندسية.',
    discipline: 'mechanical',
    category: 'summary',
    educationLevel: 'ثانوي تقني وجامعي',
    language: 'ar',
    authorOrSource: 'نادي الهندسة الميكانيكية',
    fileSize: '3.1 MB',
    fileUrl: 'https://example.com/strength-of-materials.pdf',
    downloadsCount: 670,
    viewsCount: 1890,
    uploadedBy: 'سارة بن علي',
    createdAt: '2026-01-20',
    isCopyrightClean: true
  }
];

const INITIAL_COURSES: Course[] = [
  {
    id: 'crs_1',
    title: 'أساسيات وتطبيقات الهندسة الكهربائية والدوائر الإلكترونية',
    description: 'مسار تدريبي عملي متكامل يبدأ من قوانين أوم وكيرشوف، تحليل دارات التيار المتردد والمستمر، إلى بناء الدوائر الإلكترونية المتكاملة واختبارها على لوحات التجارب.',
    instructorId: 'usr_teacher_1',
    instructorName: 'د. كريم بن منصور',
    instructorRole: 'teacher',
    discipline: 'electrical',
    level: 'beginner',
    coverImage: 'https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?w=800&auto=format&fit=crop&q=80',
    lessons: [
      { id: 'lsn_1', title: 'مقدمة في الجهد والتيار والمقاومة وقانون أوم', duration: '25 دقيقة', summary: 'شرح مفهوم تدفق الإلكترونات، الحسابات الرياضية وفرق الجهد الكهربائي.' },
      { id: 'lsn_2', title: 'قوانين كيرشوف للجهود والتيارات (KVL & KCL)', duration: '35 دقيقة', summary: 'حل الدارات المعقدة بطريقة التيارات الحلقية والعقد.' },
      { id: 'lsn_3', title: 'المكثفات والملفات في دارات التيار المتردد AC', duration: '40 دقيقة', summary: 'الممانعة السعوية والحثية وزاوية الطور وعامل القدرة (Power Factor).' },
      { id: 'lsn_4', title: 'أشباه الموصلات: الصمام الثنائي والترانزستور BJT', duration: '45 دقيقة', summary: 'استخدام الترانزستور كمفتاح كهربائي وكمضخم إشارة.' },
      { id: 'lsn_5', title: 'مشروع تطبيقي: بناء مزود قدرة منظم 5V / 12V', duration: '50 دقيقة', summary: 'تصميم دارة التقويم والتنعيم وتنظيم الجهد باستخدام LM7805.' }
    ],
    enrolledCount: 420,
    rating: 4.9,
    isApproved: true,
    createdAt: '2025-12-01'
  },
  {
    id: 'crs_2',
    title: 'برمجة المتحكمات الصناعية PLC ونظم المراقبة SCADA',
    description: 'تعلّم أتمتة خطوط الإنتاج باستخدام لغة المخطط السلمي Ladder ولغة Function Block Diagram مع محاكاة واقعية لعمليات الفرز والتعبئة.',
    instructorId: 'usr_expert_1',
    instructorName: 'م. رشيد السليماني',
    instructorRole: 'expert_engineer',
    discipline: 'automation',
    level: 'intermediate',
    coverImage: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=800&auto=format&fit=crop&q=80',
    lessons: [
      { id: 'lsn_21', title: 'بنية المتحكم الصناعي والمداخل والمخارج الرقمية والتناظرية', duration: '30 دقيقة', summary: 'فهم بطاقات I/O وتوصيل الحساسات والمشغلات الصناعية.' },
      { id: 'lsn_22', title: 'قواعد لغة Ladder: المؤقتات والعدادات والمرحلات', duration: '45 دقيقة', summary: 'برمجة المؤقتات TON, TOF وتطبيق إشارات المرور.' },
      { id: 'lsn_23', title: 'التحكم التناسبي التكاملي التفاضلي (PID Tuning)', duration: '55 دقيقة', summary: 'ضبط حرارة الأفران وسرعة المحركات بدقة عالية.' }
    ],
    enrolledCount: 310,
    rating: 4.8,
    isApproved: true,
    createdAt: '2026-01-10'
  }
];

const INITIAL_QUIZZES: Quiz[] = [
  {
    id: 'quiz_elec_fundamentals',
    title: 'تحدي الكفاءة الهندسية: أساسيات الهندسة الكهربائية والدوائر',
    description: 'اختبار دقيق يقيس فهمك لقوانين الدوائر الكهربائية، تحليل الممانعات، وحساب عامل القدرة.',
    discipline: 'electrical',
    durationMinutes: 15,
    difficulty: 'medium',
    participantsCount: 328,
    authorName: 'د. كريم بن منصور',
    showAnswersAfter: true,
    questions: [
      {
        id: 'q1',
        question: 'إذا وُصلت ثلاث مقاومات متساوية قيمة كل منها 30 أوم على التوازي، فإن المقاومة المكافئة تساوي:',
        type: 'multiple_choice',
        options: ['10 أوم', '30 أوم', '90 أوم', '5 أوم'],
        correctAnswer: 0,
        explanation: 'في حالة التوازي لمقاومات متساوية: R_eq = R / n = 30 / 3 = 10 أوم.'
      },
      {
        id: 'q2',
        question: 'في دارة تيار متردد نقية الحثية (Pure Inductor)، يسبق الجهد الكهربائي التيار بزاوية طور قدرها 90 درجة.',
        type: 'true_false',
        options: ['صح', 'خطأ'],
        correctAnswer: 0,
        explanation: 'صحيح؛ في الملف الحثي يسبق الجهد التيار بمقدار ربع دورة (90 درجة) نظراً للقوة الدافعة الكهربائية العكسية.'
      },
      {
        id: 'q3',
        question: 'ما هو الجهاز المستخدم لقياس زاوية الطور وشكل الإشارة الكهربائية وترددها بصرياً في المختبر الهندسي؟',
        type: 'short_answer',
        correctAnswer: 'الأوسيلوسكوب',
        explanation: 'راسم الإشارة الكهربائي (الأوسيلوسكوب أو Oscilloscope) هو الأداة الأساسية لتحليل أشكال الموجات وتردداتها زمنياً.'
      },
      {
        id: 'q4',
        question: 'ما هي وحدة قياس الاستطاعة أو القدرة الظاهرية (Apparent Power) في المنظومات الكهربائية ثلاثية الأطوار؟',
        type: 'multiple_choice',
        options: ['الواط (Watt)', 'الفولت-أمبير (VA)', 'الفار (VAR)', 'الجول (Joule)'],
        correctAnswer: 1,
        explanation: 'القدرة الظاهرية S تقاس بالفولت-أمبير (VA) أو (kVA)، بينما القدرة الفعالة P تقاس بالواط، والقدرة غير الفعالة Q تقاس بالفار (VAR).'
      }
    ]
  },
  {
    id: 'quiz_robotics_logic',
    title: 'تحدي الروبوتات والمنطق الرقمي للمبتدئين',
    description: 'أسئلة تفاعلية حول الحساسات، البوابات المنطقية، ومتحكمات الأردوينو.',
    discipline: 'robotics_ai',
    durationMinutes: 10,
    difficulty: 'easy',
    participantsCount: 254,
    authorName: 'سارة بن علي',
    showAnswersAfter: true,
    questions: [
      {
        id: 'qr1',
        question: 'أي بوابة منطقية تعطي خرجا (1) فقط وفقط إذا كانت جميع المداخل تساوي (1)؟',
        type: 'multiple_choice',
        options: ['بوابة AND', 'بوابة OR', 'بوابة XOR', 'بوابة NOT'],
        correctAnswer: 0,
        explanation: 'بوابة الضرب المنطقي AND تشترط تحقق جميع المداخل بالحالة العالية (1).'
      },
      {
        id: 'qr2',
        question: 'مستشعر الموجات فوق الصوتية HC-SR04 يقيس المسافة عن طريق حساب زمن ارتداد موجات الصوت.',
        type: 'true_false',
        options: ['صح', 'خطأ'],
        correctAnswer: 0,
        explanation: 'صحيح؛ يعتمد على معادلة المسافة = (السرعة × الزمن) / 2.'
      }
    ]
  }
];

const INITIAL_CONVERSATIONS: Conversation[] = [
  {
    id: 'conv_1',
    participantId: 'usr_teacher_1',
    participantName: 'د. كريم بن منصور',
    participantRole: 'teacher',
    lastMessage: 'مرحباً، اطلعت على فكرة مشروع الذراع الروبوتية وهي واعدة جداً. راجع حسابات العزم وسأوقع ورقة الإشراف.',
    lastMessageTime: 'منذ ساعتين',
    unreadCount: 1,
    messages: [
      {
        id: 'm1',
        senderId: 'usr_teacher_1',
        senderName: 'د. كريم بن منصور',
        text: 'السلام عليكم ورحمة الله. كيف حال التقدم في دارة الحماية لمحرك التيار المستمر؟',
        timestamp: '10:15 ص'
      },
      {
        id: 'm2',
        senderId: 'usr_uni_student_1',
        senderName: 'سارة بن علي',
        text: 'وعليكم السلام يا دكتور. قمنا بإضافة صمام Flyback Diode ورفعنا تردد الـ PWM إلى 25kHz وتلاشى الطنين تماماً!',
        timestamp: '10:25 ص'
      },
      {
        id: 'm3',
        senderId: 'usr_teacher_1',
        senderName: 'د. كريم بن منصور',
        text: 'ممتاز جداً! هذا هو الحل الهندسي السليم. واصلوا الاختبارات الميدانية.',
        timestamp: '10:40 ص'
      }
    ]
  }
];

const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif_1',
    userId: 'usr_uni_student_1',
    title: 'طلب إشراف أكاديمي معتمد',
    body: 'وافق الدكتور كريم بن منصور على الإشراف العلمي لمشروعك "ذراع روبوتية صناعية".',
    type: 'project_invite',
    isRead: false,
    createdAt: 'منذ ساعة'
  },
  {
    id: 'notif_2',
    userId: 'usr_uni_student_1',
    title: 'تفاعل جديد مع منشورك',
    body: 'أعجب المهندس رشيد بمنشورك حول تجربة مستشعر LiDAR وترك تعليقاً فنياً.',
    type: 'like',
    isRead: false,
    createdAt: 'منذ 3 ساعات'
  },
  {
    id: 'notif_3',
    userId: 'usr_uni_student_1',
    title: 'تحدي اليوم الهندسي',
    body: 'تم فتح اختبار "أساسيات الهندسة الكهربائية والدوائر" بمشاركة 320 مهندساً.',
    type: 'quiz_result',
    isRead: true,
    createdAt: 'أمس'
  }
];

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();
  const [posts, setPosts] = useState<Post[]>(() => {
    const saved = localStorage.getItem('eng_forum_posts');
    return saved ? JSON.parse(saved) : INITIAL_POSTS;
  });

  const [groups, setGroups] = useState<EngineeringGroup[]>(() => {
    const saved = localStorage.getItem('eng_forum_groups');
    return saved ? JSON.parse(saved) : INITIAL_GROUPS;
  });

  const [projects, setProjects] = useState<EngineeringProject[]>(() => {
    const saved = localStorage.getItem('eng_forum_projects');
    return saved ? JSON.parse(saved) : INITIAL_PROJECTS;
  });

  const [libraryResources, setLibraryResources] = useState<LibraryResource[]>(() => {
    const saved = localStorage.getItem('eng_forum_library');
    return saved ? JSON.parse(saved) : INITIAL_LIBRARY;
  });

  const [courses] = useState<Course[]>(INITIAL_COURSES);
  const [quizzes] = useState<Quiz[]>(INITIAL_QUIZZES);

  const [conversations, setConversations] = useState<Conversation[]>(() => {
    const saved = localStorage.getItem('eng_forum_conversations');
    return saved ? JSON.parse(saved) : INITIAL_CONVERSATIONS;
  });
  const [users, setUsers] = useState<UserProfile[]>([]);

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = localStorage.getItem('eng_forum_notifications');
    return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
  });

  const [reports, setReports] = useState<ModerationReport[]>(() => {
    const saved = localStorage.getItem('eng_forum_reports');
    return saved ? JSON.parse(saved) : [];
  });

  const [savedPostIds, setSavedPostIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('eng_forum_saved_posts');
    return saved ? JSON.parse(saved) : ['post_1'];
  });

  const [savedResourceIds, setSavedResourceIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('eng_forum_saved_resources');
    return saved ? JSON.parse(saved) : ['res_1', 'res_2'];
  });

  const [joinedGroupIds, setJoinedGroupIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('eng_forum_joined_groups');
    return saved ? JSON.parse(saved) : ['grp_elec', 'grp_robotics'];
  });

  const [userCourseProgress, setUserCourseProgress] = useState<Record<string, { completedLessonIds: string[]; progressPercent: number }>>(() => {
    const saved = localStorage.getItem('eng_forum_course_progress');
    return saved ? JSON.parse(saved) : { crs_1: { completedLessonIds: ['lsn_1', 'lsn_2'], progressPercent: 40 } };
  });

  const [userQuizAttempts, setUserQuizAttempts] = useState<QuizAttempt[]>(() => {
    const saved = localStorage.getItem('eng_forum_quiz_attempts');
    return saved ? JSON.parse(saved) : [];
  });

  // Realtime shared content. Local example posts/projects are never uploaded or presented as published server content.
  useEffect(() => {
    if (!db) return;
    const unsubscribePosts = onSnapshot(collection(db, 'posts'), snapshot => {
      setPosts(snapshot.docs.map(item => ({ ...item.data(), id: item.id } as Post)));
    }, error => console.error('Firestore posts listener:', error));
    const unsubscribeProjects = onSnapshot(collection(db, 'projects'), snapshot => {
      setProjects(snapshot.docs.map(item => ({ ...item.data(), id: item.id } as EngineeringProject)));
    }, error => console.error('Firestore projects listener:', error));
    return () => { unsubscribePosts(); unsubscribeProjects(); };
  }, []);

  useEffect(() => {
    if (!db || !currentUser) {
      setUsers([]);
      return;
    }
    return onSnapshot(collection(db, 'users'), snapshot => {
      setUsers(snapshot.docs.map(item => ({ ...item.data(), id: item.id } as UserProfile)).filter(user => user.isVerified));
    }, error => console.error('Firestore users listener:', error));
  }, [currentUser?.id]);

  useEffect(() => {
    if (!db || !currentUser) {
      setConversations([]);
      return;
    }
    const memberQuery = query(collection(db, 'conversations'), where('memberIds', 'array-contains', currentUser.id));
    return onSnapshot(memberQuery, snapshot => {
      const chats = snapshot.docs.map(item => {
        const raw = item.data() as Conversation;
        const other = raw.memberProfiles?.find(member => member.id !== currentUser.id);
        return {
          ...raw,
          id: item.id,
          messages: [],
          participantId: other?.id || raw.participantId,
          participantName: other?.name || raw.participantName,
          participantRole: other?.role || raw.participantRole,
        };
      });
      setConversations(chats);
    }, error => console.error('Firestore conversations listener:', error));
  }, [currentUser?.id]);

  const conversationIds = conversations.map(conversation => conversation.id).join('|');
  useEffect(() => {
    if (!db || !currentUser || !conversationIds) return;
    const database = db;
    const stopListeners = conversations.map(conversation => {
      const messageQuery = query(collection(database, 'conversations', conversation.id, 'messages'), orderBy('createdAt', 'asc'));
      return onSnapshot(messageQuery, snapshot => {
        const messages = snapshot.docs.map(item => ({ ...item.data(), id: item.id } as Conversation['messages'][number]));
        setConversations(prev => prev.map(chat => chat.id === conversation.id ? { ...chat, messages } : chat));
      }, error => console.error('Firestore messages listener:', error));
    });
    return () => stopListeners.forEach(stop => stop());
  }, [currentUser?.id, conversationIds]);

  // Sync state to local storage
  useEffect(() => {
    localStorage.setItem('eng_forum_posts', JSON.stringify(posts));
  }, [posts]);

  useEffect(() => {
    localStorage.setItem('eng_forum_projects', JSON.stringify(projects));
  }, [projects]);

  useEffect(() => {
    localStorage.setItem('eng_forum_saved_posts', JSON.stringify(savedPostIds));
  }, [savedPostIds]);

  useEffect(() => {
    localStorage.setItem('eng_forum_saved_resources', JSON.stringify(savedResourceIds));
  }, [savedResourceIds]);

  useEffect(() => {
    localStorage.setItem('eng_forum_joined_groups', JSON.stringify(joinedGroupIds));
  }, [joinedGroupIds]);

  useEffect(() => {
    localStorage.setItem('eng_forum_course_progress', JSON.stringify(userCourseProgress));
  }, [userCourseProgress]);

  useEffect(() => {
    localStorage.setItem('eng_forum_quiz_attempts', JSON.stringify(userQuizAttempts));
  }, [userQuizAttempts]);

  useEffect(() => {
    localStorage.setItem('eng_forum_conversations', JSON.stringify(conversations));
  }, [conversations]);

  useEffect(() => {
    localStorage.setItem('eng_forum_notifications', JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem('eng_forum_reports', JSON.stringify(reports));
  }, [reports]);

  // Operations
  const createPost = (postData: Omit<Post, 'id' | 'likesCount' | 'commentsCount' | 'sharesCount' | 'savesCount' | 'createdAt' | 'isApproved'>) => {
    const newPost: Post = {
      ...postData,
      id: `post_${Date.now()}`,
      likesCount: 0,
      commentsCount: 0,
      sharesCount: 0,
      savesCount: 0,
      isApproved: true, // Auto-approve for trusted / demo simulation
      createdAt: new Date().toISOString()
    };
    setPosts(prev => [newPost, ...prev]);
    if (db) void setDoc(doc(db, 'posts', newPost.id), newPost).catch(error => console.error('Post publish failed:', error));
  };

  const toggleLikePost = (postId: string) => {
    setPosts(prev => prev.map(p => {
      if (p.id === postId) {
        return { ...p, likesCount: p.likesCount + 1 };
      }
      return p;
    }));
    if (db) void updateDoc(doc(db, 'posts', postId), { likesCount: increment(1) }).catch(error => console.error('Post like failed:', error));
  };

  const toggleSavePost = (postId: string) => {
    setSavedPostIds(prev => 
      prev.includes(postId) ? prev.filter(id => id !== postId) : [...prev, postId]
    );
  };

  const addComment = (postId: string, text: string, author: { id: string; name: string; role: any }) => {
    setPosts(prev => prev.map(p => {
      if (p.id === postId) {
        return { ...p, commentsCount: p.commentsCount + 1 };
      }
      return p;
    }));
  };

  const toggleJoinGroup = (groupId: string) => {
    setJoinedGroupIds(prev => {
      const isJoined = prev.includes(groupId);
      setGroups(gList => gList.map(g => {
        if (g.id === groupId) {
          return { ...g, memberCount: isJoined ? g.memberCount - 1 : g.memberCount + 1 };
        }
        return g;
      }));
      return isJoined ? prev.filter(id => id !== groupId) : [...prev, groupId];
    });
  };

  const createProject = (projectData: Omit<EngineeringProject, 'id' | 'likesCount' | 'createdAt' | 'updates'>) => {
    const newProj: EngineeringProject = {
      ...projectData,
      id: `proj_${Date.now()}`,
      likesCount: 1,
      updates: [
        {
          id: `upd_${Date.now()}`,
          title: 'إطلاق فكرة المشروع رسمياً على المنصة',
          content: 'تم توثيق المشروع والبدء في تشكيل فريق العمل ومراجعة المخططات.',
          date: new Date().toISOString().split('T')[0]
        }
      ],
      createdAt: new Date().toISOString().split('T')[0]
    };
    setProjects(prev => [newProj, ...prev]);
    if (db) void setDoc(doc(db, 'projects', newProj.id), newProj).catch(error => console.error('Project publish failed:', error));
  };

  const toggleLikeProject = (projectId: string) => {
    setProjects(prev => prev.map(p => {
      if (p.id === projectId) {
        return { ...p, likesCount: p.likesCount + 1 };
      }
      return p;
    }));
    if (db) void updateDoc(doc(db, 'projects', projectId), { likesCount: increment(1) }).catch(error => console.error('Project like failed:', error));
  };

  const addProjectUpdate = (projectId: string, title: string, content: string) => {
    const newUpdate = { id: `upd_${Date.now()}`, title, content, date: new Date().toISOString().split('T')[0] };
    setProjects(prev => prev.map(p => {
      if (p.id === projectId) {
        return { ...p, updates: [newUpdate, ...p.updates] };
      }
      return p;
    }));
    if (db) void updateDoc(doc(db, 'projects', projectId), { updates: arrayUnion(newUpdate) }).catch(error => console.error('Project update failed:', error));
  };

  const toggleTaskStatus = (projectId: string, taskId: string) => {
    const project = projects.find(item => item.id === projectId);
    const nextTasks = project?.tasks.map(task => task.id === taskId ? { ...task, isCompleted: !task.isCompleted } : task);
    setProjects(prev => prev.map(p => {
      if (p.id === projectId) {
        const updatedTasks = p.tasks.map(t => t.id === taskId ? { ...t, isCompleted: !t.isCompleted } : t);
        return { ...p, tasks: updatedTasks };
      }
      return p;
    }));
    if (db && nextTasks) void updateDoc(doc(db, 'projects', projectId), { tasks: nextTasks }).catch(error => console.error('Project task update failed:', error));
  };

  const assignSupervisor = (projectId: string, supervisor: any) => {
    setProjects(prev => prev.map(p => {
      if (p.id === projectId) {
        return { ...p, scientificSupervisor: supervisor };
      }
      return p;
    }));
    if (db) void updateDoc(doc(db, 'projects', projectId), { scientificSupervisor: supervisor }).catch(error => console.error('Supervisor assignment failed:', error));
  };

  const toggleLessonComplete = (courseId: string, lessonId: string) => {
    setUserCourseProgress(prev => {
      const current = prev[courseId] || { completedLessonIds: [], progressPercent: 0 };
      const exists = current.completedLessonIds.includes(lessonId);
      const updatedList = exists 
        ? current.completedLessonIds.filter(id => id !== lessonId)
        : [...current.completedLessonIds, lessonId];
      
      const course = courses.find(c => c.id === courseId);
      const totalLessons = course?.lessons.length || 1;
      const progressPercent = Math.round((updatedList.length / totalLessons) * 100);

      return {
        ...prev,
        [courseId]: {
          completedLessonIds: updatedList,
          progressPercent
        }
      };
    });
  };

  const toggleSaveResource = (resourceId: string) => {
    setSavedResourceIds(prev => 
      prev.includes(resourceId) ? prev.filter(id => id !== resourceId) : [...prev, resourceId]
    );
  };

  const incrementResourceDownload = (resourceId: string) => {
    setLibraryResources(prev => prev.map(r => {
      if (r.id === resourceId) {
        return { ...r, downloadsCount: r.downloadsCount + 1 };
      }
      return r;
    }));
  };

  const submitQuizAttempt = (attemptData: Omit<QuizAttempt, 'id' | 'date'>): QuizAttempt => {
    const attempt: QuizAttempt = {
      ...attemptData,
      id: `attempt_${Date.now()}`,
      date: new Date().toISOString()
    };
    setUserQuizAttempts(prev => [attempt, ...prev]);
    return attempt;
  };

  const sendMessage = (conversationId: string, text: string, sender: { id: string; name: string }) => {
    if (!currentUser || sender.id !== currentUser.id) return;
    const newMsg = {
      id: `msg_${Date.now()}`,
      senderId: sender.id,
      senderName: sender.name,
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      createdAt: new Date().toISOString()
    };

    setConversations(prev => prev.map(c => {
      if (c.id === conversationId) {
        return {
          ...c,
          lastMessage: text,
          lastMessageTime: 'الآن',
          messages: [...c.messages, newMsg]
        };
      }
      return c;
    }));
    if (db) void Promise.all([
      addDoc(collection(db, 'conversations', conversationId, 'messages'), newMsg),
      updateDoc(doc(db, 'conversations', conversationId), { lastMessage: text, lastMessageTime: new Date().toISOString(), updatedAt: new Date().toISOString() }),
    ]).catch(error => console.error('Message send failed:', error));
  };

  const createConversation = (participant: any, firstMessage?: string): string => {
    if (!currentUser || !db) return '';
    const database = db;
    const convId = `conv_${Date.now()}`;
    const otherId = participant.id || participant.userId;
    const otherName = participant.name || participant.displayName;
    const otherRole = participant.role || 'university_student';
    const newConv: Conversation = {
      id: convId,
      memberIds: [currentUser.id, otherId],
      memberProfiles: [
        { id: currentUser.id, name: currentUser.displayName, role: currentUser.role },
        { id: otherId, name: otherName, role: otherRole },
      ],
      participantId: otherId,
      participantName: otherName,
      participantRole: otherRole,
      lastMessage: firstMessage || 'بدء المحادثة الهندسية',
      lastMessageTime: 'الآن',
      unreadCount: 0,
      messages: firstMessage ? [{
        id: `m_${Date.now()}`,
        senderId: currentUser.id,
        senderName: currentUser.displayName,
        text: firstMessage,
        timestamp: 'الآن',
        createdAt: new Date().toISOString()
      }] : []
    };
    setConversations(prev => [newConv, ...prev]);
    const { messages, ...conversationDocument } = newConv;
    void setDoc(doc(database, 'conversations', convId), { ...conversationDocument, updatedAt: new Date().toISOString() })
      .then(() => firstMessage ? addDoc(collection(database, 'conversations', convId, 'messages'), messages[0]) : undefined)
      .catch(error => console.error('Conversation creation failed:', error));
    return convId;
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
  };

  const markAllNotificationsAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  };

  const reportItem = (reportData: Omit<ModerationReport, 'id' | 'status' | 'createdAt'>) => {
    const report: ModerationReport = {
      ...reportData,
      id: `rep_${Date.now()}`,
      status: 'pending',
      createdAt: new Date().toISOString()
    };
    setReports(prev => [report, ...prev]);
  };

  const approvePost = (postId: string) => {
    setPosts(prev => prev.map(p => p.id === postId ? { ...p, isApproved: true } : p));
  };

  const rejectPost = (postId: string) => {
    setPosts(prev => prev.filter(p => p.id !== postId));
  };

  const resolveReport = (reportId: string, resolution: 'resolved' | 'dismissed') => {
    setReports(prev => prev.map(r => r.id === reportId ? { ...r, status: resolution } : r));
  };

  return (
    <DataContext.Provider
      value={{
        posts,
        groups,
        libraryResources,
        courses,
        quizzes,
        projects,
        conversations,
        users,
        notifications,
        reports,
        savedPostIds,
        savedResourceIds,
        userQuizAttempts,
        createPost,
        toggleLikePost,
        toggleSavePost,
        addComment,
        joinedGroupIds,
        toggleJoinGroup,
        createProject,
        toggleLikeProject,
        addProjectUpdate,
        toggleTaskStatus,
        assignSupervisor,
        userCourseProgress,
        toggleLessonComplete,
        toggleSaveResource,
        incrementResourceDownload,
        submitQuizAttempt,
        sendMessage,
        createConversation,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        reportItem,
        approvePost,
        rejectPost,
        resolveReport
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
