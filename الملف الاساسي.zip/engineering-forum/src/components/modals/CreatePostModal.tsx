import React, { useState } from 'react';
import { X, Send, Image, FileText, Tag, AlertCircle, Sparkles } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { EngineeringDiscipline, PostType } from '../../types';

interface CreatePostModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CreatePostModal: React.FC<CreatePostModalProps> = ({ isOpen, onClose }) => {
  const { t } = useLanguage();
  const { currentUser } = useAuth();
  const { createPost } = useData();

  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [discipline, setDiscipline] = useState<EngineeringDiscipline>(currentUser?.discipline || 'electrical');
  const [type, setType] = useState<PostType>('article');
  const [tagInput, setTagInput] = useState('');
  const [tags, setTags] = useState<string[]>(['هندسة']);
  const [imageUrl, setImageUrl] = useState('');
  const [pdfTitle, setPdfTitle] = useState('');
  const [showAttachOptions, setShowAttachOptions] = useState(false);

  if (!isOpen || !currentUser) return null;

  const handleAddTag = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      const trimmed = tagInput.trim().replace(/^#/, '');
      if (trimmed && !tags.includes(trimmed)) {
        setTags([...tags, trimmed]);
        setTagInput('');
      }
    }
  };

  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter(t => t !== tagToRemove));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;

    createPost({
      authorId: currentUser.id,
      authorName: currentUser.displayName,
      authorRole: currentUser.role,
      authorDiscipline: currentUser.discipline,
      title: title.trim(),
      content: content.trim(),
      discipline,
      type,
      tags: tags.length > 0 ? tags : [t.disciplines[discipline]],
      images: imageUrl.trim() ? [imageUrl.trim()] : undefined,
      pdfTitle: pdfTitle.trim() || undefined,
      pdfUrl: pdfTitle.trim() ? 'https://example.com/attached-resource.pdf' : undefined,
    });

    // Reset and close
    setTitle('');
    setContent('');
    setTags(['هندسة']);
    setImageUrl('');
    setPdfTitle('');
    onClose();
  };

  const postTypes: { key: PostType; label: string }[] = [
    { key: 'article', label: t.posts.typeArticle },
    { key: 'question', label: t.posts.typeQuestion },
    { key: 'tutorial', label: t.posts.typeTutorial },
    { key: 'project_showcase', label: t.posts.typeProjectShowcase },
    { key: 'schematic', label: t.posts.typeSchematic },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-2xl rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-sky-500/10 text-sky-500 flex items-center justify-center font-bold">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {t.nav.newPost}
              </h2>
              <p className="text-xs text-slate-400">
                شارك المعرفة، اسأل المختصين، أو اعرض نتائج تجاربك
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 flex-1">
          {/* Post Type Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
              {t.posts.filterType}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {postTypes.map(pt => (
                <button
                  type="button"
                  key={pt.key}
                  onClick={() => setType(pt.key)}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold border transition text-center ${
                    type === pt.key
                      ? 'bg-sky-500 text-white border-sky-500 shadow-sm'
                      : 'border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  {pt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Discipline Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
              {t.posts.filterDiscipline}
            </label>
            <select
              value={discipline}
              onChange={(e) => setDiscipline(e.target.value as EngineeringDiscipline)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:border-sky-500"
            >
              {Object.entries(t.disciplines).map(([k, name]) => (
                <option key={k} value={k}>
                  {name}
                </option>
              ))}
            </select>
          </div>

          {/* Title Input */}
          <div>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="عنوان الموضوع الهندسي أو السؤال التقني بوضوح..."
              className="w-full px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-sm font-semibold text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-sky-500"
              required
            />
          </div>

          {/* Content Body */}
          <div>
            <textarea
              rows={6}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="اكتب تفاصيل الفكرة، المعادلات المستخدمة، نتائج القياسات أو الخطأ الذي تواجهه..."
              className="w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-sky-500 resize-none leading-relaxed"
              required
            />
          </div>

          {/* Tags */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
              الوسوم التقنية (اضغط Enter للإضافة)
            </label>
            <div className="flex flex-wrap items-center gap-1.5 p-2 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
              {tags.map(tag => (
                <span
                  key={tag}
                  className="px-2 py-0.5 rounded-lg bg-sky-500/10 text-sky-500 text-xs font-medium flex items-center gap-1"
                >
                  #{tag}
                  <button type="button" onClick={() => removeTag(tag)} className="hover:text-rose-500">
                    &times;
                  </button>
                </span>
              ))}
              <input
                type="text"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={handleAddTag}
                placeholder="أضف وسماً: #Arduino, #PLC..."
                className="bg-transparent border-none text-xs text-slate-800 dark:text-slate-200 focus:outline-none p-1 flex-1 min-w-[120px]"
              />
            </div>
          </div>

          {/* Attachments Toggle */}
          <div className="pt-2">
            <button
              type="button"
              onClick={() => setShowAttachOptions(!showAttachOptions)}
              className="text-xs text-sky-500 hover:underline font-semibold flex items-center gap-1.5"
            >
              <Image className="w-4 h-4" />
              <span>إرفاق مخطط بياني أو ملف PDF توضيحي</span>
            </button>

            {showAttachOptions && (
              <div className="mt-3 p-3.5 rounded-2xl bg-slate-100/80 dark:bg-slate-800/50 space-y-3 border border-slate-200 dark:border-slate-700/60">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                    رابط صورة المخطط / الدارة الكهربائية
                  </label>
                  <input
                    type="url"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    placeholder="https://example.com/schematic-circuit.png"
                    className="w-full px-3 py-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
                    عنوان ملف PDF المرفق (ورقة بيضاء / كود)
                  </label>
                  <input
                    type="text"
                    value={pdfTitle}
                    onChange={(e) => setPdfTitle(e.target.value)}
                    placeholder="مخطط التوصيل الكامل.pdf"
                    className="w-full px-3 py-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Moderation safety note */}
          <div className="flex items-start gap-2 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-500 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <p className="leading-tight">
              تخضع المنشورات الجديدة لنظام الإشراف الهجين لضمان جودة المحتوى التعليمي ومنع نشر أي بيانات اتصال شخصية أو أرقام هواتف.
            </p>
          </div>

          {/* Form Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            >
              {t.common.cancel}
            </button>
            <button
              type="submit"
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-500 hover:to-blue-500 text-white text-xs font-bold shadow-lg shadow-sky-600/30 transition hover:scale-[1.02] cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>نشر في المنتدى</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
