import React, { useState } from 'react';
import { 
  X, 
  Download, 
  Bookmark, 
  Printer, 
  ZoomIn, 
  ZoomOut, 
  FileText, 
  ShieldCheck, 
  ChevronLeft, 
  ChevronRight,
  Share2
} from 'lucide-react';
import { LibraryResource } from '../../types';
import { useLanguage } from '../../i18n/LanguageContext';
import { useData } from '../../context/DataContext';

interface PdfViewerModalProps {
  resource: LibraryResource | null;
  isOpen: boolean;
  onClose: () => void;
}

export const PdfViewerModal: React.FC<PdfViewerModalProps> = ({ resource, isOpen, onClose }) => {
  const { t } = useLanguage();
  const { savedResourceIds, toggleSaveResource, incrementResourceDownload } = useData();

  const [zoomLevel, setZoomLevel] = useState(100);
  const [currentPage, setCurrentPage] = useState(1);
  const totalSimulatedPages = 18;

  if (!isOpen || !resource) return null;

  const isSaved = savedResourceIds.includes(resource.id);

  const handleDownload = () => {
    incrementResourceDownload(resource.id);
    // Simulate real file download
    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(`[مرجع هندسي مصادق]: ${resource.title}\nالمؤلف: ${resource.authorOrSource}\nالتخصص: ${resource.discipline}`));
    element.setAttribute('download', `${resource.title.slice(0, 30)}.txt`);
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-5xl h-[92vh] rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl overflow-hidden flex flex-col text-slate-100">
        
        {/* Top Control Bar */}
        <div className="px-5 py-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="w-9 h-9 rounded-xl bg-sky-500/10 text-sky-400 flex items-center justify-center shrink-0">
              <FileText className="w-5 h-5" />
            </div>
            <div className="truncate">
              <h2 className="text-sm font-bold text-white truncate">{resource.title}</h2>
              <p className="text-[11px] text-slate-400 font-mono truncate">
                {resource.authorOrSource} • {resource.fileSize}
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Zoom Controls */}
            <div className="hidden sm:flex items-center bg-slate-800/80 rounded-xl p-1 border border-slate-700/60">
              <button 
                onClick={() => setZoomLevel(z => Math.max(z - 15, 70))}
                className="p-1.5 hover:text-sky-400 transition" 
                title="تصغير"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="text-[10px] font-mono px-2 text-slate-300">{zoomLevel}%</span>
              <button 
                onClick={() => setZoomLevel(z => Math.min(z + 15, 150))}
                className="p-1.5 hover:text-sky-400 transition" 
                title="تكبير"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
            </div>

            {/* Bookmark button */}
            <button
              onClick={() => toggleSaveResource(resource.id)}
              className={`p-2 rounded-xl border transition ${
                isSaved 
                  ? 'bg-amber-400/20 text-amber-400 border-amber-400/40' 
                  : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:text-white'
              }`}
              title="حفظ في المفضلة"
            >
              <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
            </button>

            {/* Download button */}
            <button
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold shadow-md shadow-sky-600/30 transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">تحميل ({resource.downloadsCount})</span>
            </button>

            {/* Close modal */}
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800/80 border border-slate-700 text-slate-400 hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Reader Document Area */}
        <div className="flex-1 bg-slate-950 p-4 sm:p-6 overflow-auto flex justify-center items-start">
          <div 
            className="w-full max-w-3xl bg-white text-slate-900 rounded-2xl shadow-2xl p-8 sm:p-12 transition-transform duration-200 border border-slate-300 min-h-[700px] leading-relaxed select-text"
            style={{ transform: `scale(${zoomLevel / 100})`, transformOrigin: 'top center' }}
          >
            {/* Scientific Document Header */}
            <div className="border-b-2 border-slate-800 pb-6 mb-6">
              <div className="flex items-center justify-between text-xs font-mono text-slate-500 mb-2">
                <span>REPUBLIQUE ALGERIENNE / ENGINEERING FORUM</span>
                <span>DOC-ID: {resource.id.toUpperCase()}</span>
              </div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-950 mb-2">
                {resource.title}
              </h1>
              <p className="text-xs text-slate-600 font-semibold">
                إعداد: {resource.authorOrSource} • التخصص: {t.disciplines[resource.discipline]}
              </p>
            </div>

            {/* Document Abstract & Technical Synopsis */}
            <div className="bg-slate-50 border-r-4 border-sky-600 p-4 rounded-xl mb-6">
              <h3 className="text-xs font-bold text-sky-800 uppercase tracking-wider mb-1">
                ملخص المرجع العلمي (Abstract)
              </h3>
              <p className="text-xs text-slate-700 leading-relaxed">
                {resource.description}
              </p>
            </div>

            {/* Technical Diagram Simulation */}
            <div className="my-6 p-6 rounded-2xl bg-slate-900 text-white font-mono text-xs border border-slate-800">
              <div className="flex items-center justify-between pb-2 mb-4 border-b border-slate-800 text-[11px] text-sky-400">
                <span>[FIGURE 1.1: ARCHITECTURE & CIRCUIT SCHEMATIC]</span>
                <span>STATUS: VERIFIED</span>
              </div>
              <pre className="overflow-x-auto text-sky-300 text-[11px] leading-relaxed">
{`+----------------+       +-------------------+       +-----------------+
| Power Supply   | ----> | Inverter / Driver | ----> | Induction Motor |
| 400V 50Hz 3-Ph |       | IGBT Bridge PWM   |       | Squirrel Cage   |
+----------------+       +-------------------+       +-----------------+
        |                          |                          |
        v                          v                          v
  Current Sensor             Snubber R-C-D              Encoder Feedback
  (ACS712-30A)              (dI/dt & dV/dt)             (1024 Pulses/Rev)`}
              </pre>
            </div>

            {/* Sample Section Content */}
            <div className="space-y-4 text-xs sm:text-sm text-slate-800 text-justify">
              <h2 className="text-base font-bold text-slate-900 border-b pb-1">
                1. المبادئ النظرية والمعادلات الرياضية
              </h2>
              <p>
                تعتمد كفاءة النظم الكهربائية على تقليل مفاقيد الجول ومفاقيد النواة الحديدية (Hysteresis & Eddy currents). يتم حساب عامل القدرة وفق العلاقة:
              </p>
              <div className="text-center font-mono py-2 bg-slate-100 rounded-lg text-slate-900 font-bold">
                cos(φ) = P / S = P / √(P² + Q²)
              </div>
              <p>
                حيث تمثل P القدرة الفعالة بالواط، وQ القدرة الارتكاسية بالفار، وS القدرة الظاهرية بالفولت-أمبير. يُوصى بتركيب مكثفات تحسين معامل القدرة لتقليل التيار المار في الكابلات وتقليل الفواقد في الشبكة الوطنية.
              </p>
            </div>

            {/* Educational Copyright Note */}
            <div className="mt-12 pt-4 border-t border-slate-200 text-center text-[10px] text-slate-400 flex items-center justify-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
              <span>متاح لأغراض التعلم والبحث العلمي داخل منتدى تلاميذ وطلاب الهندسة. يمنع الاستخدام التجاري دون إذن المؤلف.</span>
            </div>
          </div>
        </div>

        {/* Bottom Pager */}
        <div className="px-6 py-3 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setCurrentPage(p => Math.max(p - 1, 1))}
              disabled={currentPage <= 1}
              className="p-1.5 rounded-lg bg-slate-800 disabled:opacity-30 hover:text-white"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <span>صفحة {currentPage} من {totalSimulatedPages}</span>
            <button 
              onClick={() => setCurrentPage(p => Math.min(p + 1, totalSimulatedPages))}
              disabled={currentPage >= totalSimulatedPages}
              className="p-1.5 rounded-lg bg-slate-800 disabled:opacity-30 hover:text-white"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>

          <span className="font-mono text-[11px] text-slate-500 hidden sm:inline">
            ENGINEERING OPEN EDUCATIONAL REPOSITORY
          </span>
        </div>
      </div>
    </div>
  );
};
