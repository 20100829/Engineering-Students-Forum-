import React, { useState } from 'react';
import { X, ShieldAlert, Send, CheckCircle2 } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetId: string;
  targetType: 'post' | 'comment' | 'user' | 'resource' | 'message';
  targetTitle?: string;
}

export const ReportModal: React.FC<ReportModalProps> = ({
  isOpen,
  onClose,
  targetId,
  targetType,
  targetTitle
}) => {
  const { t } = useLanguage();
  const { currentUser } = useAuth();
  const { reportItem } = useData();

  const [reasonCategory, setReasonCategory] = useState('minor_privacy');
  const [details, setDetails] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    reportItem({
      targetId,
      targetType,
      reporterId: currentUser.id,
      reporterName: currentUser.displayName,
      reason: `[${reasonCategory}] ${details.trim()}`
    });

    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      onClose();
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-lg rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden p-6">
        
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2 text-rose-500 font-bold">
            <ShieldAlert className="w-5 h-5" />
            <span>{t.privacySafety.reportContent}</span>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="py-10 text-center space-y-3">
            <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto animate-bounce" />
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              تم استلام البلاغ بنجاح
            </h3>
            <p className="text-xs text-slate-400">
              {t.privacySafety.reportSubmitted}
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="mt-4 space-y-4">
            {targetTitle && (
              <p className="text-xs text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 p-2.5 rounded-xl truncate">
                المحتوى المبلغ عنه: <strong className="text-slate-800 dark:text-slate-200">{targetTitle}</strong>
              </p>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                سبب البلاغ
              </label>
              <select
                value={reasonCategory}
                onChange={(e) => setReasonCategory(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-800 dark:text-slate-100"
              >
                <option value="minor_privacy">نشر معلومات شخصية حساسة أو رقم هاتف لقاصر</option>
                <option value="copyright">انتهاك حقوق الملكية الفكرية أو نسخ بدون إذن</option>
                <option value="spam">محتوى مضلل، إعلاني، أو غير متعلق بالهندسة</option>
                <option value="harassment">سلوك غير لائق أو تنمر في المناقشات</option>
                <option value="dangerous_schematic">مخطط خطر قد يسبب صدمات كهربائية غير آمنة</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                توضيح إضافي لفريق الإشراف
              </label>
              <textarea
                rows={3}
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                placeholder="اذكر تفاصيل المخالفة ليقوم المشرف باتخاذ الإجراء المناسب..."
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-100 resize-none focus:outline-none focus:border-rose-500"
                required
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-slate-200"
              >
                {t.common.cancel}
              </button>
              <button
                type="submit"
                className="flex items-center gap-2 px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition shadow-lg shadow-rose-600/30"
              >
                <Send className="w-3.5 h-3.5" />
                <span>إرسال البلاغ للإدارة</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
