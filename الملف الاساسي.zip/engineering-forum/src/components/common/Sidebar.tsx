import React from 'react';
import { 
  Home, 
  Compass, 
  MessageSquare, 
  Users, 
  BookOpen, 
  GraduationCap, 
  HelpCircle, 
  Cpu, 
  Mail, 
  FileText, 
  ShieldCheck, 
  Sliders, 
  User, 
  ShieldAlert, 
  Zap, 
  CheckCircle2, 
  HelpCircle as QuestionIcon,
  Download,
  Crown
} from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { EngineeringDiscipline } from '../../types';

interface SidebarProps {
  currentPage: string;
  onNavigate: (page: string, params?: any) => void;
  isOpen?: boolean;
  onClose?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPage,
  onNavigate,
  isOpen,
  onClose
}) => {
  const { t, isRTL } = useLanguage();
  const { currentUser, isAdmin, canModerate } = useAuth();
  const { reports } = useData();

  const pendingReports = reports.filter(r => r.status === 'pending');

  interface NavItem {
    id: string;
    label: string;
    icon: any;
    badge?: string;
    count?: number;
  }

  const navSections: { title: string; items: NavItem[] }[] = [
    {
      title: 'المنصة والمجتمع',
      items: [
        { id: 'home', label: t.nav.home, icon: Home },
        { id: 'explore', label: t.nav.explore, icon: Compass },
        { id: 'posts', label: t.nav.posts, icon: MessageSquare },
        { id: 'groups', label: t.nav.groups, icon: Users },
        { id: 'leadership', label: t.nav.leadership, icon: Crown, badge: 'الإدارة' },
      ]
    },
    {
      title: 'الابتكار والتعليم الهندسي',
      items: [
        { id: 'projects', label: t.nav.projects, icon: Cpu, badge: 'ابتكار' },
        { id: 'library', label: t.nav.library, icon: BookOpen },
        { id: 'courses', label: t.nav.courses, icon: GraduationCap },
        { id: 'quizzes', label: t.nav.quizzes, icon: QuestionIcon, badge: 'تحدي' },
      ]
    },
    {
      title: 'الأدوات والتواصل',
      items: [
        { id: 'messages', label: t.nav.messages, icon: Mail },
        { id: 'cv', label: t.nav.cv, icon: FileText, badge: 'PDF' },
        { id: 'profile', label: t.nav.profile, icon: User },
        { id: 'settings', label: t.nav.settings, icon: Sliders },
      ]
    }
  ];

  if (isAdmin || canModerate) {
    navSections.push({
      title: 'الإدارة والأمان',
      items: [
        ...(isAdmin ? [{ id: 'admin', label: t.nav.admin, icon: ShieldCheck, badge: 'مدير' }] : []),
        { 
          id: 'moderation', 
          label: t.nav.moderation, 
          icon: ShieldAlert, 
          count: pendingReports.length > 0 ? pendingReports.length : undefined 
        },
      ]
    });
  }

  const disciplinesList: { key: EngineeringDiscipline; label: string; icon: string }[] = [
    { key: 'electrical', label: t.disciplines.electrical, icon: '⚡' },
    { key: 'electronics', label: t.disciplines.electronics, icon: '🔌' },
    { key: 'automation', label: t.disciplines.automation, icon: '⚙️' },
    { key: 'robotics_ai', label: t.disciplines.robotics_ai, icon: '🤖' },
    { key: 'renewable_energy', label: t.disciplines.renewable_energy, icon: '☀️' },
    { key: 'mechanical', label: t.disciplines.mechanical, icon: '🔩' },
    { key: 'civil', label: t.disciplines.civil, icon: '🏗️' },
    { key: 'computer_sci', label: t.disciplines.computer_sci, icon: '💻' },
    { key: 'telecom', label: t.disciplines.telecom, icon: '📡' },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div 
          onClick={onClose}
          className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm z-40 lg:hidden transition-opacity"
        />
      )}

      <aside
        className={`fixed lg:sticky top-16 h-[calc(100vh-4rem)] w-72 shrink-0 bg-slate-50/90 dark:bg-[#070b14]/90 backdrop-blur-xl border-l lg:border-l-0 ${
          isRTL ? 'lg:border-l' : 'lg:border-r'
        } border-slate-200 dark:border-slate-800/80 p-4 overflow-y-auto transition-transform duration-300 z-50 lg:z-10 ${
          isOpen 
            ? 'translate-x-0' 
            : isRTL 
              ? 'translate-x-full lg:translate-x-0' 
              : '-translate-x-full lg:translate-x-0'
        } ${isRTL ? 'right-0' : 'left-0'}`}
      >
        {/* Navigation Sections */}
        <div className="space-y-6">
          {navSections.map((section, idx) => (
            <div key={idx}>
              <h3 className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2 px-3">
                {section.title}
              </h3>
              <div className="space-y-1">
                {section.items.map(item => {
                  const Icon = item.icon;
                  const isActive = currentPage === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        onNavigate(item.id);
                        if (onClose) onClose();
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                        isActive
                          ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 border border-sky-500/30 shadow-sm'
                          : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-slate-800/50 hover:text-slate-900 dark:hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Icon className={`w-4 h-4 ${isActive ? 'text-sky-500' : 'text-slate-400'}`} />
                        <span>{item.label}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {item.badge && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-400/20 text-amber-500 border border-amber-400/30">
                            {item.badge}
                          </span>
                        )}
                        {item.count && (
                          <span className="w-5 h-5 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center">
                            {item.count}
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}

          {/* Quick Engineering Discipline Shortcuts */}
          <div>
            <h3 className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2 px-3 flex items-center justify-between">
              <span>التخصصات الهندسية</span>
              <Zap className="w-3 h-3 text-sky-400" />
            </h3>
            <div className="space-y-1">
              {disciplinesList.slice(0, 5).map(d => (
                <button
                  key={d.key}
                  onClick={() => {
                    onNavigate('posts', { discipline: d.key });
                    if (onClose) onClose();
                  }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs text-slate-600 dark:text-slate-400 hover:text-sky-500 dark:hover:text-sky-300 hover:bg-slate-200/50 dark:hover:bg-slate-800/40 transition text-right"
                >
                  <span className="text-sm">{d.icon}</span>
                  <span className="truncate">{d.label}</span>
                </button>
              ))}
              <button
                onClick={() => {
                  onNavigate('explore');
                  if (onClose) onClose();
                }}
                className="w-full text-center py-1.5 text-[11px] text-sky-500 hover:underline font-semibold cursor-pointer"
              >
                + عرض جميع التخصصات العشرة
              </button>
            </div>
          </div>

          {/* Minor Safety & Terms Banner */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-br from-slate-900 to-sky-950/60 border border-sky-500/20 text-slate-300 text-xs shadow-md">
            <div className="flex items-center gap-2 text-sky-400 font-bold mb-1">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>بيئة هندسية آمنة</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              حماية معلومات القاصرين والطلبة مفعلة تلقائياً. يُمنع تداول البيانات الشخصية أو أرقام الهواتف.
            </p>
            <button
              onClick={() => {
                onNavigate('terms');
                if (onClose) onClose();
              }}
              className="mt-2 text-[10px] text-sky-400 hover:underline font-semibold block"
            >
              سياسة الخصوصية والميثاق الهندسي ←
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
