import React from 'react';
import { useLanguage } from '../../i18n/LanguageContext';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  showMotto?: boolean;
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({
  size = 'md',
  showText = true,
  showMotto = false,
  className = '',
}) => {
  const { t, currentLang } = useLanguage();

  const sizeDimensions = {
    sm: { icon: 34, title: 'text-sm', sub: 'text-[10px]' },
    md: { icon: 44, title: 'text-base font-bold', sub: 'text-xs' },
    lg: { icon: 56, title: 'text-lg font-bold', sub: 'text-xs' },
    xl: { icon: 72, title: 'text-2xl font-black', sub: 'text-sm' },
  }[size];

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Engineered Emblem: Gear + Book + Bolt + Circuit Nodes */}
      <div 
        className="relative flex items-center justify-center shrink-0 rounded-2xl bg-gradient-to-br from-slate-900 via-[#0b172a] to-blue-950 p-2 shadow-lg border border-sky-500/30 group transition-all duration-300 hover:border-sky-400 hover:shadow-sky-500/20"
        style={{ width: sizeDimensions.icon, height: sizeDimensions.icon }}
      >
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full transform transition-transform duration-500 group-hover:scale-105"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient id="engBlueGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#38bdf8" />
              <stop offset="50%" stopColor="#0284c7" />
              <stop offset="100%" stopColor="#1d4ed8" />
            </linearGradient>
            <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fbbf24" />
              <stop offset="100%" stopColor="#d97706" />
            </linearGradient>
            <filter id="glowEffect" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* 1. Engineering Gear Outer Profile with 8 teeth */}
          <path
            d="M50 14 L54 14 L55 20 A30 30 0 0 1 65 24 L70 20 L73 23 L70 28 A30 30 0 0 1 74 38 L80 40 L80 44 L74 46 A30 30 0 0 1 70 56 L73 61 L70 64 L65 60 A30 30 0 0 1 55 64 L54 70 L46 70 L45 64 A30 30 0 0 1 35 60 L30 64 L27 61 L30 56 A30 30 0 0 1 26 46 L20 44 L20 40 L26 38 A30 30 0 0 1 30 28 L27 23 L30 20 L35 24 A30 30 0 0 1 45 20 L46 14 Z"
            stroke="url(#engBlueGrad)"
            strokeWidth="3.5"
            strokeLinejoin="round"
            className="opacity-75 transition-all duration-700 group-hover:opacity-100"
          />

          {/* 2. Open Educational Book forming the base foundation */}
          <path
            d="M26 68 C34 64, 44 65, 50 69 C56 65, 66 64, 74 68 L74 80 C66 76, 56 77, 50 81 C44 77, 34 76, 26 80 Z"
            fill="#0f172a"
            stroke="#38bdf8"
            strokeWidth="2.5"
          />
          <path
            d="M50 69 L50 81"
            stroke="#38bdf8"
            strokeWidth="2"
            strokeLinecap="round"
          />

          {/* 3. Circuit Pathways & Microchip Nodes */}
          <line x1="32" y1="42" x2="42" y2="42" stroke="#38bdf8" strokeWidth="2" strokeDasharray="2 2" />
          <line x1="58" y1="42" x2="68" y2="42" stroke="#38bdf8" strokeWidth="2" strokeDasharray="2 2" />
          <circle cx="32" cy="42" r="2.5" fill="#38bdf8" />
          <circle cx="68" cy="42" r="2.5" fill="#38bdf8" />

          {/* 4. Central Electric Lightning Bolt - Energy & Innovation */}
          <path
            d="M53 23 L41 46 L49 46 L45 65 L60 41 L51 41 Z"
            fill="url(#goldGrad)"
            stroke="#ffffff"
            strokeWidth="1.2"
            filter="url(#glowEffect)"
          />
        </svg>

        {/* Ambient Pulsing Aura */}
        <div className="absolute inset-0 rounded-2xl bg-sky-500/10 blur-sm pointer-events-none group-hover:bg-sky-400/20 transition-all duration-300" />
      </div>

      {/* Dual Language & Motto Typography */}
      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center gap-2">
            <span className={`tracking-tight text-slate-900 dark:text-white leading-tight ${sizeDimensions.title}`}>
              {currentLang === 'ar' ? 'منتدى تلاميذ وطلاب الهندسة' : 'Engineering Students Forum'}
            </span>
          </div>
          <div className="flex items-center gap-1.5 text-sky-600 dark:text-sky-400 font-mono tracking-wider text-[11px] font-semibold">
            <span>{currentLang === 'ar' ? 'ENGINEERING STUDENTS FORUM' : 'منتدى تلاميذ وطلاب الهندسة'}</span>
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 inline-block animate-pulse" />
          </div>
          {showMotto && (
            <p className="mt-1 text-slate-500 dark:text-slate-400 text-xs italic font-medium">
              {t.app.motto}
            </p>
          )}
        </div>
      )}
    </div>
  );
};
