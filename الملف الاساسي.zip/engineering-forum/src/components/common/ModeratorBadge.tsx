import React from 'react';
import { ShieldCheck, Award, Sparkles } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';

interface ModeratorBadgeProps {
  authorId?: string;
  authorName?: string;
  isModerator?: boolean;
  moderatorTitle?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg';
  variant?: 'pill' | 'detailed' | 'subtle';
  className?: string;
}

export const isSpaceManager = (authorId?: string, authorName?: string, isModerator?: boolean): boolean => {
  if (isModerator) return true;
  if (!authorId && !authorName) return false;

  const id = (authorId || '').toLowerCase();
  const name = (authorName || '').toLowerCase();

  // Explicit IDs of the space managers
  if (id === 'usr_fedili' || id === 'usr_abaidi') return true;

  // Name matches for Fadhili Fatih & Abidi Salah Eddine
  if (name.includes('فضيلي') || name.includes('فاتح') || name.includes('fedili') || name.includes('fadhili')) return true;
  if (name.includes('عبيدي') || name.includes('صلاح الدين') || name.includes('abaidi') || name.includes('abidi')) return true;

  // General moderator keywords
  if (name.includes('مشرف') || name.includes('moderator') || name.includes('modérateur')) return true;

  return false;
};

export const getModeratorDetails = (authorId?: string, authorName?: string, customTitle?: string) => {
  if (customTitle) {
    return {
      title: customTitle,
      domain: customTitle,
      shortDomain: customTitle.replace('مشرف', '').trim()
    };
  }

  const id = (authorId || '').toLowerCase();
  const name = (authorName || '').toLowerCase();

  if (id === 'usr_fedili' || name.includes('فضيلي') || name.includes('fedili') || name.includes('fadhili')) {
    return {
      title: 'مشرف البرمجة والهندسة البرمجية',
      titleEn: 'Supervisor of Programming & Software Engineering',
      titleFr: 'Modérateur Génie Logiciel & Programmation',
      domain: 'البرمجة وهندسة البرمجيات',
      shortDomain: 'برمجة وأنظمة'
    };
  }

  if (id === 'usr_abaidi' || name.includes('عبيدي') || name.includes('abaidi') || name.includes('abidi')) {
    return {
      title: 'مشرف المخططات والهندسات',
      titleEn: 'Supervisor of Schematics & Engineering Designs',
      titleFr: 'Modérateur Schémas & Ingénierie',
      domain: 'المخططات الهندسية والدارات',
      shortDomain: 'مخططات و PCB'
    };
  }

  return {
    title: 'مشرف فضاء معتمد',
    titleEn: 'Verified Space Moderator',
    titleFr: 'Modérateur d\'espace certifié',
    domain: 'إشراف الفضاءات الهندسية',
    shortDomain: 'مشرف فضاء'
  };
};

export const ModeratorBadge: React.FC<ModeratorBadgeProps> = ({
  authorId,
  authorName,
  isModerator,
  moderatorTitle,
  size = 'sm',
  variant = 'pill',
  className = ''
}) => {
  const { t, currentLang } = useLanguage();

  if (!isSpaceManager(authorId, authorName, isModerator)) {
    return null;
  }

  const details = getModeratorDetails(authorId, authorName, moderatorTitle);

  const tooltipTitle = currentLang === 'en' 
    ? (details.titleEn || 'Verified Space Moderator')
    : currentLang === 'fr' 
      ? (details.titleFr || 'Modérateur d\'espace certifié')
      : details.title;

  const sizeClasses = {
    xs: 'text-[9px] px-1.5 py-0.5 gap-1',
    sm: 'text-[10px] sm:text-[11px] px-2 py-0.5 gap-1.5',
    md: 'text-xs px-2.5 py-1 gap-1.5',
    lg: 'text-xs sm:text-sm px-3.5 py-1.5 gap-2'
  }[size];

  const iconSizes = {
    xs: 'w-3 h-3',
    sm: 'w-3.5 h-3.5',
    md: 'w-4 h-4',
    lg: 'w-4 h-4'
  }[size];

  // Detailed variant shows domain or full title
  if (variant === 'detailed') {
    return (
      <span
        title={tooltipTitle}
        className={`inline-flex items-center ${sizeClasses} rounded-lg font-bold bg-gradient-to-r from-emerald-500/15 via-teal-500/15 to-emerald-500/15 dark:from-emerald-500/20 dark:via-teal-500/20 dark:to-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 dark:border-emerald-400/40 shadow-sm backdrop-blur-sm select-none ${className}`}
      >
        <ShieldCheck className={`${iconSizes} text-emerald-600 dark:text-emerald-400 shrink-0`} />
        <span className="font-extrabold uppercase tracking-wider">{t.common.moderator}</span>
        <span className="opacity-40">•</span>
        <span className="text-[10px] opacity-90 hidden sm:inline">{details.shortDomain}</span>
      </span>
    );
  }

  // Subtle variant
  if (variant === 'subtle') {
    return (
      <span
        title={tooltipTitle}
        className={`inline-flex items-center ${sizeClasses} rounded-md font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 select-none ${className}`}
      >
        <ShieldCheck className={`${iconSizes} shrink-0`} />
        <span>{t.common.moderator}</span>
      </span>
    );
  }

  // Standard Pill variant: High visibility, glowing, eye-catching
  return (
    <span
      title={tooltipTitle}
      className={`inline-flex items-center ${sizeClasses} rounded-full font-bold bg-gradient-to-r from-emerald-500/20 via-teal-500/20 to-emerald-500/20 hover:from-emerald-500/30 hover:to-teal-500/30 text-emerald-700 dark:text-emerald-300 border border-emerald-500/40 dark:border-emerald-400/50 shadow-sm shadow-emerald-500/10 select-none cursor-help transition-all ${className}`}
    >
      <ShieldCheck className={`${iconSizes} text-emerald-600 dark:text-emerald-400 shrink-0 animate-pulse`} />
      <span className="font-black tracking-wide">{t.common.moderator}</span>
      <Sparkles className="w-2.5 h-2.5 text-amber-500 dark:text-amber-400 shrink-0 hidden sm:inline" />
    </span>
  );
};
