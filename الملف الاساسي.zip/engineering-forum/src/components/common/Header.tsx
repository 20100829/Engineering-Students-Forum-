import React, { useState } from 'react';
import { 
  Search, 
  Bell, 
  PlusCircle, 
  Globe, 
  Sun, 
  Moon, 
  User, 
  Shield, 
  FileText, 
  LogOut, 
  Check, 
  ChevronDown,
  Layers,
  Menu,
  X,
  Crown
} from 'lucide-react';
import { Logo } from './Logo';
import { useLanguage } from '../../i18n/LanguageContext';
import { useTheme } from '../../context/ThemeContext';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { Language, UserRole } from '../../types';
import { ModeratorBadge } from './ModeratorBadge';

interface HeaderProps {
  onOpenCreatePost: () => void;
  onNavigate: (page: string, params?: any) => void;
  currentPage: string;
  onToggleSidebar?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenCreatePost,
  onNavigate,
  currentPage,
  onToggleSidebar
}) => {
  const { currentLang, setLanguage, t, isRTL } = useLanguage();
  const { theme, toggleTheme, isDark } = useTheme();
  const { currentUser, logout, isAdmin, canModerate } = useAuth();
  const { notifications, markAllNotificationsAsRead, posts, projects, libraryResources } = useData();

  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchDropdown, setShowSearchDropdown] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showLangMenu, setShowLangMenu] = useState(false);

  const unreadNotifs = notifications.filter(n => !n.isRead);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onNavigate('explore', { query: searchQuery });
      setShowSearchDropdown(false);
    }
  };

  const roleColors: Record<UserRole, string> = {
    high_school_student: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    university_student: 'bg-sky-500/10 text-sky-400 border-sky-500/30',
    teacher: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
    expert_engineer: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    admin: 'bg-rose-500/10 text-rose-400 border-rose-500/30',
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200/80 dark:border-slate-800/80 bg-white/90 dark:bg-[#070b14]/90 backdrop-blur-xl transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        
        {/* Left Section: Mobile Menu Button & Brand Logo */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleSidebar}
            className="lg:hidden p-2 rounded-xl text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60 transition"
            aria-label="القائمة الجانبية"
          >
            <Menu className="w-5 h-5" />
          </button>
          
          <div 
            onClick={() => onNavigate('home')} 
            className="cursor-pointer transition-opacity hover:opacity-95"
          >
            <Logo size="sm" showText={true} />
          </div>
        </div>

        {/* Center: Search Bar with Live Suggestions */}
        <div className="relative flex-1 max-w-xl hidden md:block">
          <form onSubmit={handleSearchSubmit} className="relative">
            <Search className={`absolute top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 ${isRTL ? 'right-3.5' : 'left-3.5'}`} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setShowSearchDropdown(e.target.value.length > 1);
              }}
              onFocus={() => searchQuery.length > 1 && setShowSearchDropdown(true)}
              placeholder={t.nav.searchPlaceholder}
              className={`w-full h-10 rounded-xl bg-slate-100/90 dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 focus:border-sky-500 dark:focus:border-sky-400 focus:outline-none focus:ring-2 focus:ring-sky-500/20 text-xs sm:text-sm text-slate-800 dark:text-slate-100 placeholder-slate-400 transition-all ${
                isRTL ? 'pr-10 pl-4' : 'pl-10 pr-4'
              }`}
            />
          </form>

          {/* Search Autocomplete preview */}
          {showSearchDropdown && (
            <div className="absolute top-12 left-0 right-0 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-3 z-50 animate-in fade-in zoom-in-95">
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 dark:border-slate-800 text-xs font-semibold text-slate-400">
                <span>نتائج مقترحة سريعة</span>
                <button onClick={() => setShowSearchDropdown(false)} className="hover:text-slate-200">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="space-y-1 max-h-64 overflow-y-auto text-xs">
                {posts.filter(p => p.title.toLowerCase().includes(searchQuery.toLowerCase())).slice(0, 2).map(p => (
                  <div 
                    key={p.id} 
                    onClick={() => { onNavigate('post_detail', p.id); setShowSearchDropdown(false); }}
                    className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer flex items-center justify-between"
                  >
                    <span className="font-medium text-slate-800 dark:text-slate-200 truncate">{p.title}</span>
                    <span className="text-[10px] text-sky-400 bg-sky-500/10 px-1.5 py-0.5 rounded">نقاش</span>
                  </div>
                ))}
                {projects.filter(p => p.title.toLowerCase().includes(searchQuery.toLowerCase())).slice(0, 2).map(p => (
                  <div 
                    key={p.id} 
                    onClick={() => { onNavigate('project_detail', p.id); setShowSearchDropdown(false); }}
                    className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer flex items-center justify-between"
                  >
                    <span className="font-medium text-slate-800 dark:text-slate-200 truncate">{p.title}</span>
                    <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded">مشروع</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Section: Actions & Profile */}
        <div className="flex items-center gap-2 sm:gap-3">
          
          {/* Quick Create Post CTA */}
          <button
            onClick={onOpenCreatePost}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-500 hover:to-blue-500 text-white font-medium text-xs sm:text-sm shadow-md shadow-sky-600/20 transition-all hover:scale-[1.02] active:scale-95 cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span className="hidden sm:inline">{t.nav.newPost}</span>
          </button>

          {/* Language Switcher */}
          <div className="relative">
            <button
              onClick={() => setShowLangMenu(!showLangMenu)}
              className="flex items-center gap-1.5 p-2 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-300 transition text-xs font-semibold cursor-pointer"
              title="تغيير اللغة / Change Language"
            >
              <Globe className="w-4 h-4 text-sky-500" />
              <span className="uppercase">{currentLang}</span>
            </button>

            {showLangMenu && (
              <div className={`absolute top-12 ${isRTL ? 'left-0' : 'right-0'} w-40 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl py-2 z-50`}>
                <button
                  onClick={() => { setLanguage('ar'); setShowLangMenu(false); }}
                  className={`w-full px-4 py-2 text-xs flex items-center justify-between hover:bg-slate-100 dark:hover:bg-slate-800 transition ${currentLang === 'ar' ? 'text-sky-500 font-bold' : 'text-slate-700 dark:text-slate-300'}`}
                >
                  <span>العربية (RTL)</span>
                  {currentLang === 'ar' && <Check className="w-3.5 h-3.5" />}
                </button>
                <button
                  onClick={() => { setLanguage('en'); setShowLangMenu(false); }}
                  className={`w-full px-4 py-2 text-xs flex items-center justify-between hover:bg-slate-100 dark:hover:bg-slate-800 transition ${currentLang === 'en' ? 'text-sky-500 font-bold' : 'text-slate-700 dark:text-slate-300'}`}
                >
                  <span>English (LTR)</span>
                  {currentLang === 'en' && <Check className="w-3.5 h-3.5" />}
                </button>
                <button
                  onClick={() => { setLanguage('fr'); setShowLangMenu(false); }}
                  className={`w-full px-4 py-2 text-xs flex items-center justify-between hover:bg-slate-100 dark:hover:bg-slate-800 transition ${currentLang === 'fr' ? 'text-sky-500 font-bold' : 'text-slate-700 dark:text-slate-300'}`}
                >
                  <span>Français (LTR)</span>
                  {currentLang === 'fr' && <Check className="w-3.5 h-3.5" />}
                </button>
              </div>
            )}
          </div>

          {/* Theme Toggle (Dark / Light) */}
          <button
            onClick={toggleTheme}
            className="p-2 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-300 transition cursor-pointer"
            title={isDark ? t.nav.lightMode : t.nav.darkMode}
          >
            {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
          </button>

          {/* Notifications Popover */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative p-2 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-300 transition cursor-pointer"
            >
              <Bell className="w-4 h-4" />
              {unreadNotifs.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center animate-pulse">
                  {unreadNotifs.length}
                </span>
              )}
            </button>

            {showNotifications && (
              <div className={`absolute top-12 ${isRTL ? 'left-0' : 'right-0'} w-80 sm:w-96 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-4 z-50 animate-in fade-in zoom-in-95`}>
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-slate-900 dark:text-white">{t.nav.notifications}</span>
                    <span className="px-2 py-0.5 rounded-full bg-sky-500/10 text-sky-400 text-xs font-semibold">
                      {unreadNotifs.length}
                    </span>
                  </div>
                  {unreadNotifs.length > 0 && (
                    <button
                      onClick={markAllNotificationsAsRead}
                      className="text-xs text-sky-500 hover:underline cursor-pointer"
                    >
                      تحديد الكل كمقروء
                    </button>
                  )}
                </div>

                <div className="divide-y divide-slate-100 dark:divide-slate-800/60 max-h-72 overflow-y-auto mt-2">
                  {notifications.map(item => (
                    <div 
                      key={item.id} 
                      className={`py-3 px-2 rounded-xl transition ${item.isRead ? 'opacity-70' : 'bg-sky-500/5'}`}
                    >
                      <p className="text-xs font-bold text-slate-900 dark:text-slate-100">{item.title}</p>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">{item.body}</p>
                      <span className="text-[10px] text-slate-400 font-mono mt-1 inline-block">{item.createdAt}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* User Account / Role Switcher Menu */}
          {currentUser ? (
            <div className="relative">
              <button
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="flex items-center gap-2 p-1.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800/60 transition cursor-pointer"
              >
                <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-sky-600 to-indigo-600 text-white font-bold text-xs flex items-center justify-center">
                  {currentUser.displayName.charAt(0)}
                </div>
                <div className="hidden xl:flex flex-col text-right">
                  <span className="text-xs font-bold text-slate-900 dark:text-slate-100 leading-tight">
                    {currentUser.displayName}
                  </span>
                  <span className="text-[10px] text-sky-500 font-medium">
                    {t.roles[currentUser.role]}
                  </span>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {showUserMenu && (
                <div className={`absolute top-12 ${isRTL ? 'left-0' : 'right-0'} w-64 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-3 z-50`}>
                  {/* Active user header */}
                  <div className="p-2 border-b border-slate-100 dark:border-slate-800 mb-2">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <p className="text-xs font-bold text-slate-900 dark:text-white">{currentUser.displayName}</p>
                      <ModeratorBadge 
                        authorId={currentUser.id} 
                        authorName={currentUser.displayName} 
                        isModerator={currentUser.isModerator} 
                        moderatorTitle={currentUser.moderatorTitle} 
                        size="xs" 
                      />
                    </div>
                    <p className="text-[11px] text-slate-400 font-mono">{currentUser.email}</p>
                    <span className={`inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-semibold border ${roleColors[currentUser.role]}`}>
                      {t.roles[currentUser.role]}
                    </span>
                  </div>

                  {/* Navigation Links */}
                  <div className="space-y-1 text-xs">
                    <button
                      onClick={() => { onNavigate('profile'); setShowUserMenu(false); }}
                      className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                    >
                      <User className="w-4 h-4 text-sky-500" />
                      <span>{t.nav.profile}</span>
                    </button>
                    <button
                      onClick={() => { onNavigate('cv'); setShowUserMenu(false); }}
                      className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                    >
                      <FileText className="w-4 h-4 text-emerald-500" />
                      <span>{t.nav.cv}</span>
                    </button>
                    <button
                      onClick={() => { onNavigate('leadership'); setShowUserMenu(false); }}
                      className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition font-medium"
                    >
                      <Crown className="w-4 h-4 text-amber-500" />
                      <span>{t.nav.leadership}</span>
                    </button>
                    {isAdmin && (
                      <button
                        onClick={() => { onNavigate('admin'); setShowUserMenu(false); }}
                        className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-rose-500 hover:bg-rose-500/10 transition font-bold"
                      >
                        <Shield className="w-4 h-4" />
                        <span>{t.nav.admin}</span>
                      </button>
                    )}
                  </div>

                  <div className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <button
                      onClick={() => { logout(); setShowUserMenu(false); }}
                      className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-rose-500 hover:bg-rose-500/10 text-xs font-semibold transition"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>{t.nav.logout}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={() => onNavigate('login')}
              className="px-4 py-2 rounded-xl bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white text-xs sm:text-sm font-semibold transition"
            >
              {t.nav.login}
            </button>
          )}

        </div>
      </div>
    </header>
  );
};
