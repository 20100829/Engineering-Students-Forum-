import React from 'react';
import { Home, MessageSquare, Cpu, BookOpen, User, PlusCircle } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';

interface MobileNavProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  onOpenCreatePost: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  currentPage,
  onNavigate,
  onOpenCreatePost
}) => {
  const { t } = useLanguage();

  const items = [
    { id: 'home', label: t.nav.home, icon: Home },
    { id: 'posts', label: t.nav.posts, icon: MessageSquare },
    { id: 'create', label: '', icon: PlusCircle, isCta: true },
    { id: 'projects', label: t.nav.projects.split(' ')[0], icon: Cpu },
    { id: 'profile', label: t.nav.profile, icon: User },
  ];

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-[#070b14]/95 backdrop-blur-xl border-t border-slate-200 dark:border-slate-800/80 px-2 py-1.5 shadow-2xl safe-area-bottom">
      <div className="flex items-center justify-around">
        {items.map((item, idx) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;

          if (item.isCta) {
            return (
              <button
                key={idx}
                onClick={onOpenCreatePost}
                className="relative -top-4 w-12 h-12 rounded-2xl bg-gradient-to-tr from-sky-600 to-blue-600 text-white flex items-center justify-center shadow-lg shadow-sky-600/40 border-2 border-white dark:border-[#070b14] active:scale-95 transition-transform"
                aria-label="نشر جديد"
              >
                <PlusCircle className="w-6 h-6" />
              </button>
            );
          }

          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-3 rounded-xl transition ${
                isActive 
                  ? 'text-sky-500 font-bold' 
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Icon className="w-5 h-5 mb-0.5" />
              <span className="text-[10px] leading-tight">{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
